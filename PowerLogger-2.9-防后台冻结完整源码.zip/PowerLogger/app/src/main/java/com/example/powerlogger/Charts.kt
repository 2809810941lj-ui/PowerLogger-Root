package com.example.powerlogger

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.max

val Ink = Color(0xFF17171A)
val InkSoft = Color(0xFF8E8E93)
val PageBg = Color(0xFFF2F2F7)
val AccentBlue = Color(0xFF2F7CF6)
val AccentOrange = Color(0xFFF2A03D)
val AccentCyan = Color(0xFF32C5D2)
val AccentPink = Color(0xFFE86A9A)
val AccentGreen = Color(0xFF34C77B)
val AccentYellow = Color(0xFFFFD60A)
val GridLine = Color(0xFFE6E6EA)

/** 一条曲线。Points 的 x 为 0f..1f，y 为原始数值。 */
data class ChartSeries(
    val name: String,
    val color: Color,
    val points: List<Pair<Float, Float>>,
    val axis: Int = 0
)

@Composable
fun ChartCard(
    title: String,
    trailing: String,
    series: List<ChartSeries>,
    xLabels: List<String>,
    yLeftMax: Float,
    modifier: Modifier = Modifier,
    yRightMax: Float? = null,
    yLeftMin: Float = 0f,
    yRightMin: Float = 0f,
    fill: Boolean = false,
    chartHeight: Dp = 168.dp
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color.White,
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 13.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Ink,
                    modifier = Modifier.weight(1f)
                )
                if (trailing.isNotEmpty()) {
                    Text(text = trailing, fontSize = 10.sp, color = InkSoft)
                }
            }
            Spacer(Modifier.height(8.dp))
            LineChart(
                series = series,
                xLabels = xLabels,
                yLeftMax = yLeftMax,
                yRightMax = yRightMax,
                yLeftMin = yLeftMin,
                yRightMin = yRightMin,
                fill = fill,
                modifier = Modifier.fillMaxWidth().height(chartHeight)
            )
            Spacer(Modifier.height(8.dp))
            ChartLegend(series)
        }
    }
}

@Composable
fun LineChart(
    series: List<ChartSeries>,
    xLabels: List<String>,
    yLeftMax: Float,
    modifier: Modifier = Modifier,
    yRightMax: Float? = null,
    yLeftMin: Float = 0f,
    yRightMin: Float = 0f,
    fill: Boolean = false
) {
    Canvas(modifier = modifier) {
        val left = 33.dp.toPx()
        val right = if (yRightMax != null) 28.dp.toPx() else 8.dp.toPx()
        val top = 6.dp.toPx()
        val bottom = 17.dp.toPx()
        val plotWidth = size.width - left - right
        val plotHeight = size.height - top - bottom
        if (plotWidth <= 1f || plotHeight <= 1f) return@Canvas

        val labelPaint = android.graphics.Paint().apply {
            isAntiAlias = true
            color = 0xFF8E8E93.toInt()
            textSize = 9.sp.toPx()
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        }

        val grid = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 4.dp.toPx()), 0f)
        for (i in 0..4) {
            val y = top + plotHeight * i / 4f
            drawLine(
                color = GridLine,
                start = Offset(left, y),
                end = Offset(left + plotWidth, y),
                strokeWidth = 1.dp.toPx(),
                pathEffect = grid
            )
            val leftValue = yLeftMin + (yLeftMax - yLeftMin) * (4 - i) / 4f
            labelPaint.textAlign = android.graphics.Paint.Align.RIGHT
            drawContext.canvas.nativeCanvas.drawText(
                axisText(leftValue),
                left - 5.dp.toPx(),
                y + 3.dp.toPx(),
                labelPaint
            )
            if (yRightMax != null) {
                val rightValue = yRightMin + (yRightMax - yRightMin) * (4 - i) / 4f
                labelPaint.textAlign = android.graphics.Paint.Align.LEFT
                drawContext.canvas.nativeCanvas.drawText(
                    axisText(rightValue),
                    left + plotWidth + 5.dp.toPx(),
                    y + 3.dp.toPx(),
                    labelPaint
                )
            }
        }

        if (xLabels.isNotEmpty()) {
            labelPaint.textAlign = android.graphics.Paint.Align.CENTER
            xLabels.forEachIndexed { index, label ->
                val x = if (xLabels.size == 1) left + plotWidth / 2f
                else left + plotWidth * index / (xLabels.size - 1).toFloat()
                labelPaint.textAlign = when {
                    xLabels.size == 1 -> android.graphics.Paint.Align.CENTER
                    index == 0 -> android.graphics.Paint.Align.LEFT
                    index == xLabels.size - 1 -> android.graphics.Paint.Align.RIGHT
                    else -> android.graphics.Paint.Align.CENTER
                }
                drawContext.canvas.nativeCanvas.drawText(
                    label,
                    x,
                    size.height - 3.dp.toPx(),
                    labelPaint
                )
            }
        }

        val safeLeftMax = if (yLeftMax <= 0f) 1f else yLeftMax
        val safeRightMax = if (yRightMax == null || yRightMax <= 0f) 1f else yRightMax
        series.forEach lineLoop@ { line ->
            val maxValue = if (line.axis == 1) safeRightMax else safeLeftMax
            val minValue = if (line.axis == 1) yRightMin else yLeftMin
            val span = maxValue - minValue
            if (line.points.size < 2 || span <= 0f) return@lineLoop

            val path = Path()
            val fillPath = Path()
            var started = false
            var lastPoint: Offset? = null
            line.points.forEach pointLoop@ { (fx, raw) ->
                if (raw <= 0f) {
                    started = false
                    return@pointLoop
                }
                val x = left + plotWidth * fx.coerceIn(0f, 1f)
                val y = top + plotHeight * (1f - ((raw - minValue) / span).coerceIn(0f, 1.02f))
                if (!started) {
                    path.moveTo(x, y)
                    fillPath.moveTo(x, top + plotHeight)
                    fillPath.lineTo(x, y)
                    started = true
                } else {
                    path.lineTo(x, y)
                    fillPath.lineTo(x, y)
                }
                lastPoint = Offset(x, y)
            }
            val fillEnd = lastPoint
            if (fill && fillEnd != null) {
                fillPath.lineTo(fillEnd.x, top + plotHeight)
                fillPath.close()
                drawPath(path = fillPath, color = line.color.copy(alpha = 0.18f))
            }
            drawPath(
                path = path,
                color = line.color,
                style = Stroke(
                    width = 1.8.dp.toPx(),
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
            lastPoint?.let {
                drawCircle(color = Color.White, radius = 3.4.dp.toPx(), center = it)
                drawCircle(color = line.color, radius = 2.2.dp.toPx(), center = it)
            }
        }
    }
}

private fun axisText(value: Float): String {
    return when {
        value >= 1000f -> String.format(Locale.US, "%.0fk", value / 1000f)
        value >= 100f -> String.format(Locale.US, "%.0f", value)
        value >= 10f -> String.format(Locale.US, "%.0f", value)
        else -> String.format(Locale.US, "%.1f", value)
    }
}

@Composable
fun ChartLegend(series: List<ChartSeries>) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        series.forEach { line ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .background(line.color, CircleShape)
                )
                Spacer(Modifier.width(4.dp))
                Text(text = line.name, fontSize = 10.sp, color = InkSoft)
            }
        }
    }
}

/** 把一串值转成 0f..1f 的 x 坐标。 */
fun valuesToPoints(values: List<Float>): List<Pair<Float, Float>> {
    if (values.isEmpty()) return emptyList()
    if (values.size == 1) return listOf(1f to values[0])
    val step = 1f / (values.size - 1).toFloat()
    return values.mapIndexed { index, value -> index * step to value }
}

fun niceMaxOr(value: Float, floor: Float): Float = max(value, floor)
