package com.example.powerlogger

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import org.json.JSONObject

/**
 * 单次应用帧率与功耗记录的 Room 实体表。
 * curveJson 字段保存完整 AppSession JSON（包含所有采样点曲线数据），
 * 详情页可通过 toAppSession() 直接还原全部曲线并渲染图表。
 */
@Entity(tableName = "session_records")
data class SessionRecordEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0L,

    @ColumnInfo(name = "package_name")
    val packageName: String,

    @ColumnInfo(name = "app_name")
    val appName: String,

    @ColumnInfo(name = "activity_name")
    val activityName: String,

    @ColumnInfo(name = "start_time")
    val startTime: Long,

    @ColumnInfo(name = "end_time")
    val endTime: Long,

    @ColumnInfo(name = "duration_ms")
    val durationMs: Long,

    @ColumnInfo(name = "avg_fps")
    val avgFps: Double,

    @ColumnInfo(name = "max_fps")
    val maxFps: Double,

    @ColumnInfo(name = "min_fps")
    val minFps: Double,

    @ColumnInfo(name = "avg_temp")
    val avgTemp: Double,

    @ColumnInfo(name = "max_temp")
    val maxTemp: Double,

    @ColumnInfo(name = "avg_power_w")
    val avgPowerW: Double,

    @ColumnInfo(name = "max_power_w")
    val maxPowerW: Double,

    @ColumnInfo(name = "model")
    val model: String,

    @ColumnInfo(name = "soc")
    val soc: String,

    @ColumnInfo(name = "os_version")
    val osVersion: String,

    @ColumnInfo(name = "note")
    val note: String = "",

    @ColumnInfo(name = "curve_json")
    val curveJson: String
) {
    /**
     * 将数据库实体还原为 AppSession，供详情页渲染 FPS / FrameTime / CPU / GPU / 功耗 / 温度曲线。
     */
    fun toAppSession(): AppSession {
        return try {
            val parsed = AppSession.fromJson(JSONObject(curveJson))
            parsed.copy(
                id = id,
                packageName = packageName.ifBlank { parsed.packageName },
                label = appName.ifBlank { parsed.label },
                activity = activityName.ifBlank { parsed.activity },
                startTime = if (startTime > 0L) startTime else parsed.startTime,
                endTime = if (endTime > 0L) endTime else parsed.endTime,
                model = model.ifBlank { parsed.model },
                soc = soc.ifBlank { parsed.soc },
                os = osVersion.ifBlank { parsed.os },
                note = note.ifBlank { parsed.note }
            )
        } catch (_: Exception) {
            AppSession(
                id = id,
                packageName = packageName,
                label = appName.ifBlank { packageName },
                activity = activityName,
                startTime = startTime,
                endTime = endTime,
                model = model,
                soc = soc,
                os = osVersion,
                note = note,
                samples = mutableListOf()
            )
        }
    }

    companion object {
        /**
         * 从采集完成的 AppSession 构建数据库实体。
         */
        fun fromAppSession(session: AppSession): SessionRecordEntity {
            val stats = session.buildStats()
            return SessionRecordEntity(
                id = session.id,
                packageName = session.packageName,
                appName = session.label.ifBlank { session.packageName },
                activityName = session.activity,
                startTime = session.startTime,
                endTime = session.endTime,
                durationMs = session.durationMs,
                avgFps = stats.fpsAvg,
                maxFps = stats.fpsMax,
                minFps = stats.fpsMin,
                avgTemp = stats.avgBatteryTemp,
                maxTemp = stats.maxBatteryTemp,
                avgPowerW = stats.avgPower,
                maxPowerW = stats.maxPower,
                model = session.model,
                soc = session.soc,
                osVersion = session.os,
                note = session.note,
                curveJson = session.toJson().toString()
            )
        }
    }
}
