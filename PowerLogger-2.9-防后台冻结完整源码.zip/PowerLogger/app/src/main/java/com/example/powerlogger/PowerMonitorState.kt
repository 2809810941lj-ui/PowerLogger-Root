package com.example.powerlogger

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

/** Immutable UI state shared by the Compose home screen and recording service. */
data class PowerMonitorUiState(
    val isRunning: Boolean = false,
    val powerMw: Double = 0.0,
    val voltageMv: Int = 0,
    val currentMa: Double = 0.0,
    val tempC: Double = 0.0,
    val batteryLevel: Int = 0,
    val charging: Boolean = false,
    val lastSampleTime: Long = 0L,
    val message: String = "前台自动记录已就绪",
    /** 仅保存纯放电状态（!charging）下的功耗采样点（单位 mW，负值代表放电），充电期间绝不混入！ */
    val historyPowerMw: List<Double> = emptyList(),
    val source: String = "",
    val csvPath: String? = null
)

object PowerMonitorState {
    private val mutableState = MutableStateFlow(PowerMonitorUiState())
    val state: StateFlow<PowerMonitorUiState> = mutableState.asStateFlow()

    fun markStarting() {
        mutableState.value = mutableState.value.copy(
            isRunning = false,
            message = "正在启动功耗监测…",
            lastSampleTime = 0L,
            csvPath = null,
            source = ""
        )
    }

    fun markSessionStarted(path: String) {
        mutableState.value = mutableState.value.copy(
            isRunning = true,
            message = "功耗监测运行中",
            csvPath = path
        )
    }

    fun updateSample(sample: PowerSample, tempC: Double, level: Int, path: String?) {
        val old = mutableState.value
        // 关键规则：充电期间（sample.charging == true）不记录放电功耗，保持原有放电曲线不被充电功率污染
        val updatedDischargeHistory = if (!sample.charging && sample.powerMw != 0.0) {
            (old.historyPowerMw + (-abs(sample.powerMw))).takeLast(MAX_HISTORY_POINTS)
        } else {
            old.historyPowerMw
        }
        mutableState.value = old.copy(
            isRunning = true,
            powerMw = sample.powerMw,
            voltageMv = sample.voltageMv,
            currentMa = sample.currentMa,
            tempC = tempC,
            batteryLevel = level,
            charging = sample.charging,
            lastSampleTime = sample.timestamp,
            message = if (sample.charging) {
                "正在充电 (+，不计入放电功耗)"
            } else {
                "正在放电 (-，实时统计放电功耗)"
            },
            historyPowerMw = updatedDischargeHistory,
            source = sample.source,
            csvPath = path ?: old.csvPath
        )
    }

    fun markSampleUnavailable() {
        val old = mutableState.value
        mutableState.value = old.copy(
            message = if (old.isRunning) "监测中 · 本次采样不可用" else old.message
        )
    }

    fun markStopped(message: String) {
        mutableState.value = mutableState.value.copy(
            isRunning = false,
            message = message
        )
    }

    fun trimMemory() {
        val old = mutableState.value
        if (old.historyPowerMw.size > 30) {
            mutableState.value = old.copy(
                historyPowerMw = old.historyPowerMw.takeLast(30)
            )
        }
    }

    private const val MAX_HISTORY_POINTS = 90
}
