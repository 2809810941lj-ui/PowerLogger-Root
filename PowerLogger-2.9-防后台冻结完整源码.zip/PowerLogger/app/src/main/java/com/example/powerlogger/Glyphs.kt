package com.example.powerlogger

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun BackGlyph(iconSize: Dp = 22.dp, tint: Color = Ink) {
    Canvas(Modifier.size(iconSize)) {
        val stroke = Stroke(
            width = 2.dp.toPx(),
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
        val path = Path().apply {
            moveTo(size.width * 0.66f, size.height * 0.16f)
            lineTo(size.width * 0.30f, size.height * 0.5f)
            lineTo(size.width * 0.66f, size.height * 0.84f)
        }
        drawPath(path = path, color = tint, style = stroke)
    }
}

@Composable
fun ChevronGlyph(iconSize: Dp = 18.dp, tint: Color = Color(0xFFC7C7CC)) {
    Canvas(Modifier.size(iconSize)) {
        val stroke = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        val path = Path().apply {
            moveTo(size.width * 0.36f, size.height * 0.22f)
            lineTo(size.width * 0.64f, size.height * 0.5f)
            lineTo(size.width * 0.36f, size.height * 0.78f)
        }
        drawPath(path = path, color = tint, style = stroke)
    }
}

@Composable
fun HistoryGlyph(iconSize: Dp = 21.dp, tint: Color = Ink) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        val stroke = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round)
        drawCircle(
            color = tint,
            radius = width * 0.36f,
            center = Offset(width * 0.5f, height * 0.5f),
            style = stroke
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.5f, height * 0.5f),
            end = Offset(width * 0.5f, height * 0.28f),
            strokeWidth = 1.8.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.5f, height * 0.5f),
            end = Offset(width * 0.68f, height * 0.58f),
            strokeWidth = 1.8.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.14f, height * 0.5f),
            end = Offset(width * 0.14f, height * 0.32f),
            strokeWidth = 1.6.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun TrashGlyph(iconSize: Dp = 21.dp, tint: Color = Ink) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        val stroke = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round)
        drawLine(
            color = tint,
            start = Offset(width * 0.18f, height * 0.28f),
            end = Offset(width * 0.82f, height * 0.28f),
            strokeWidth = 1.8.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.4f, height * 0.2f),
            end = Offset(width * 0.6f, height * 0.2f),
            strokeWidth = 1.8.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawRoundRect(
            color = tint,
            topLeft = Offset(width * 0.28f, height * 0.34f),
            size = Size(width * 0.44f, height * 0.5f),
            cornerRadius = CornerRadius(width * 0.08f),
            style = stroke
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.42f, height * 0.44f),
            end = Offset(width * 0.42f, height * 0.74f),
            strokeWidth = 1.5.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.58f, height * 0.44f),
            end = Offset(width * 0.58f, height * 0.74f),
            strokeWidth = 1.5.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun HelpDot(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(20.dp)
            .background(Color(0xFFEDEDF0), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text = "?", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF8E8E93))
    }
}

@Composable
fun BatteryGlyph(iconSize: Dp = 17.dp, tint: Color = InkSoft) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        val stroke = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
        drawRoundRect(
            color = tint,
            topLeft = Offset(width * 0.06f, height * 0.24f),
            size = Size(width * 0.76f, height * 0.52f),
            cornerRadius = CornerRadius(width * 0.12f),
            style = stroke
        )
        drawRoundRect(
            color = tint,
            topLeft = Offset(width * 0.85f, height * 0.4f),
            size = Size(width * 0.09f, height * 0.2f),
            cornerRadius = CornerRadius(width * 0.03f)
        )
        drawRect(
            color = tint.copy(alpha = 0.3f),
            topLeft = Offset(width * 0.14f, height * 0.32f),
            size = Size(width * 0.3f, height * 0.36f)
        )
    }
}

@Composable
fun TempGlyph(iconSize: Dp = 17.dp, tint: Color = InkSoft) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        drawLine(
            color = tint,
            start = Offset(width * 0.5f, height * 0.18f),
            end = Offset(width * 0.5f, height * 0.62f),
            strokeWidth = 2.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawCircle(
            color = tint,
            radius = width * 0.17f,
            center = Offset(width * 0.5f, height * 0.72f),
            style = Stroke(width = 1.6.dp.toPx())
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.68f, height * 0.28f),
            end = Offset(width * 0.8f, height * 0.28f),
            strokeWidth = 1.4.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.68f, height * 0.42f),
            end = Offset(width * 0.8f, height * 0.42f),
            strokeWidth = 1.4.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun BoltGlyph(iconSize: Dp = 17.dp, tint: Color = InkSoft) {
    Canvas(Modifier.size(iconSize)) {
        val path = Path().apply {
            moveTo(size.width * 0.56f, size.height * 0.08f)
            lineTo(size.width * 0.24f, size.height * 0.56f)
            lineTo(size.width * 0.48f, size.height * 0.56f)
            lineTo(size.width * 0.42f, size.height * 0.92f)
            lineTo(size.width * 0.78f, size.height * 0.42f)
            lineTo(size.width * 0.54f, size.height * 0.42f)
            close()
        }
        drawPath(path = path, color = tint, style = Stroke(width = 1.5.dp.toPx(), join = StrokeJoin.Round))
    }
}

@Composable
fun PlugGlyph(iconSize: Dp = 17.dp, tint: Color = InkSoft) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        drawLine(
            color = tint,
            start = Offset(width * 0.35f, height * 0.08f),
            end = Offset(width * 0.35f, height * 0.3f),
            strokeWidth = 2.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.65f, height * 0.08f),
            end = Offset(width * 0.65f, height * 0.3f),
            strokeWidth = 2.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawRoundRect(
            color = tint,
            topLeft = Offset(width * 0.22f, height * 0.3f),
            size = Size(width * 0.56f, height * 0.4f),
            cornerRadius = CornerRadius(width * 0.2f),
            style = Stroke(width = 1.5.dp.toPx())
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.5f, height * 0.7f),
            end = Offset(width * 0.5f, height * 0.94f),
            strokeWidth = 1.6.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun ChartGlyph(iconSize: Dp = 18.dp, tint: Color = InkSoft) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        val stroke = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
        drawLine(
            color = tint,
            start = Offset(width * 0.12f, height * 0.12f),
            end = Offset(width * 0.12f, height * 0.88f),
            strokeWidth = 1.5.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.12f, height * 0.88f),
            end = Offset(width * 0.9f, height * 0.88f),
            strokeWidth = 1.5.dp.toPx(),
            cap = StrokeCap.Round
        )
        val bars = listOf(0.3f, 0.55f, 0.8f)
        bars.forEachIndexed { index, fraction ->
            val x = width * (0.28f + index * 0.2f)
            drawRoundRect(
                color = tint.copy(alpha = 0.65f),
                topLeft = Offset(x, height * (0.88f - fraction * 0.6f)),
                size = Size(width * 0.1f, height * fraction * 0.6f),
                cornerRadius = CornerRadius(width * 0.03f)
            )
        }
    }
}

@Composable
fun PeopleGlyph(iconSize: Dp = 18.dp, tint: Color = InkSoft) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        val stroke = Stroke(width = 1.4.dp.toPx(), cap = StrokeCap.Round)
        drawCircle(
            color = tint,
            radius = width * 0.14f,
            center = Offset(width * 0.36f, height * 0.34f),
            style = stroke
        )
        drawArc(
            color = tint,
            startAngle = 205f,
            sweepAngle = 130f,
            useCenter = false,
            topLeft = Offset(width * 0.14f, height * 0.46f),
            size = Size(width * 0.44f, height * 0.4f),
            style = stroke
        )
        drawCircle(
            color = tint,
            radius = width * 0.11f,
            center = Offset(width * 0.7f, height * 0.4f),
            style = stroke
        )
        drawArc(
            color = tint,
            startAngle = 215f,
            sweepAngle = 115f,
            useCenter = false,
            topLeft = Offset(width * 0.52f, height * 0.52f),
            size = Size(width * 0.36f, height * 0.32f),
            style = stroke
        )
    }
}

@Composable
fun ListGlyph(iconSize: Dp = 18.dp, tint: Color = InkSoft) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        for (index in 0..2) {
            val y = height * (0.26f + index * 0.24f)
            drawCircle(color = tint, radius = 1.6.dp.toPx(), center = Offset(width * 0.16f, y))
            drawLine(
                color = tint,
                start = Offset(width * 0.3f, y),
                end = Offset(width * 0.88f, y),
                strokeWidth = 1.5.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun FilterGlyph(iconSize: Dp = 19.dp, tint: Color = Ink) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        val path = Path().apply {
            moveTo(width * 0.12f, height * 0.2f)
            lineTo(width * 0.88f, height * 0.2f)
            lineTo(width * 0.6f, height * 0.52f)
            lineTo(width * 0.6f, height * 0.82f)
            lineTo(width * 0.42f, height * 0.72f)
            lineTo(width * 0.42f, height * 0.52f)
            close()
        }
        drawPath(path = path, color = tint, style = Stroke(width = 1.6.dp.toPx(), join = StrokeJoin.Round))
    }
}

@Composable
fun ShareGlyph(iconSize: Dp = 19.dp, tint: Color = Ink) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        val stroke = Stroke(width = 1.5.dp.toPx())
        drawCircle(color = tint, radius = width * 0.09f, center = Offset(width * 0.24f, height * 0.5f), style = stroke)
        drawCircle(color = tint, radius = width * 0.09f, center = Offset(width * 0.76f, height * 0.26f), style = stroke)
        drawCircle(color = tint, radius = width * 0.09f, center = Offset(width * 0.76f, height * 0.74f), style = stroke)
        drawLine(color = tint, start = Offset(width * 0.32f, height * 0.46f), end = Offset(width * 0.68f, height * 0.3f), strokeWidth = 1.4.dp.toPx())
        drawLine(color = tint, start = Offset(width * 0.32f, height * 0.54f), end = Offset(width * 0.68f, height * 0.7f), strokeWidth = 1.4.dp.toPx())
    }
}

@Composable
fun ExportGlyph(iconSize: Dp = 19.dp, tint: Color = Ink) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        drawLine(
            color = tint,
            start = Offset(width * 0.5f, height * 0.12f),
            end = Offset(width * 0.5f, height * 0.62f),
            strokeWidth = 1.6.dp.toPx(),
            cap = StrokeCap.Round
        )
        val path = Path().apply {
            moveTo(width * 0.32f, height * 0.46f)
            lineTo(width * 0.5f, height * 0.64f)
            lineTo(width * 0.68f, height * 0.46f)
        }
        drawPath(path = path, color = tint, style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round))
        drawArc(
            color = tint,
            startAngle = 0f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(width * 0.18f, height * 0.56f),
            size = Size(width * 0.64f, height * 0.32f),
            style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}

@Composable
fun ChipGlyph(iconSize: Dp = 22.dp, tint: Color = Ink) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        drawRoundRect(
            color = tint,
            topLeft = Offset(width * 0.28f, height * 0.28f),
            size = Size(width * 0.44f, height * 0.44f),
            cornerRadius = CornerRadius(width * 0.08f),
            style = Stroke(width = 1.4.dp.toPx())
        )
        val pins = listOf(0.38f, 0.5f, 0.62f)
        pins.forEach { fraction ->
            drawLine(color = tint, start = Offset(width * fraction, height * 0.1f), end = Offset(width * fraction, height * 0.28f), strokeWidth = 1.2.dp.toPx())
            drawLine(color = tint, start = Offset(width * fraction, height * 0.72f), end = Offset(width * fraction, height * 0.9f), strokeWidth = 1.2.dp.toPx())
            drawLine(color = tint, start = Offset(width * 0.1f, height * fraction), end = Offset(width * 0.28f, height * fraction), strokeWidth = 1.2.dp.toPx())
            drawLine(color = tint, start = Offset(width * 0.72f, height * fraction), end = Offset(width * 0.9f, height * fraction), strokeWidth = 1.2.dp.toPx())
        }
    }
}

@Composable
fun PhoneGlyph(iconSize: Dp = 22.dp, tint: Color = Ink) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        drawRoundRect(
            color = tint,
            topLeft = Offset(width * 0.28f, height * 0.08f),
            size = Size(width * 0.44f, height * 0.84f),
            cornerRadius = CornerRadius(width * 0.1f),
            style = Stroke(width = 1.4.dp.toPx())
        )
        drawLine(
            color = tint,
            start = Offset(width * 0.42f, height * 0.78f),
            end = Offset(width * 0.58f, height * 0.78f),
            strokeWidth = 1.4.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun AndroidGlyph(iconSize: Dp = 22.dp, tint: Color = Ink) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        drawArc(
            color = tint,
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = true,
            topLeft = Offset(width * 0.22f, height * 0.28f),
            size = Size(width * 0.56f, height * 0.5f),
            style = Stroke(width = 1.4.dp.toPx())
        )
        drawLine(color = tint, start = Offset(width * 0.32f, height * 0.24f), end = Offset(width * 0.24f, height * 0.12f), strokeWidth = 1.4.dp.toPx(), cap = StrokeCap.Round)
        drawLine(color = tint, start = Offset(width * 0.68f, height * 0.24f), end = Offset(width * 0.76f, height * 0.12f), strokeWidth = 1.4.dp.toPx(), cap = StrokeCap.Round)
        drawCircle(color = tint, radius = 1.4.dp.toPx(), center = Offset(width * 0.38f, height * 0.48f))
        drawCircle(color = tint, radius = 1.4.dp.toPx(), center = Offset(width * 0.62f, height * 0.48f))
    }
}

@Composable
fun ProfileGlyph(iconSize: Dp = 22.dp, tint: Color = Ink) {
    Canvas(Modifier.size(iconSize)) {
        val width = size.width
        val height = size.height
        drawCircle(
            color = tint,
            radius = width * 0.18f,
            center = Offset(width * 0.5f, height * 0.34f),
            style = Stroke(width = 1.4.dp.toPx())
        )
        drawArc(
            color = tint,
            startAngle = 200f,
            sweepAngle = 140f,
            useCenter = false,
            topLeft = Offset(width * 0.2f, height * 0.5f),
            size = Size(width * 0.6f, height * 0.44f),
            style = Stroke(width = 1.4.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}
