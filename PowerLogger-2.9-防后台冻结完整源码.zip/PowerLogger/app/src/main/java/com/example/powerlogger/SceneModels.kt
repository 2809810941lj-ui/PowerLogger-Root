package com.example.powerlogger

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.round
import kotlin.math.sqrt

/**
 * 场景记录的一次采样。
 */
data class SceneSample(
    val time: Long,
    val fps: Double = 0.0,
    val frameMs: Double = 0.0,
    val jitter: Double = 0.0,
    val cpuTotal: Double = 0.0,
    val cpuLittle: Double = 0.0,
    val cpuBig: Double = 0.0,
    val freqLittle: Double = 0.0,
    val freqBig: Double = 0.0,
    val gpuUsage: Double = 0.0,
    val gpuFreq: Double = 0.0,
    val powerW: Double = 0.0,
    val capacity: Int = 0,
    val cpuTemp: Double = 0.0,
    val gpuTemp: Double = 0.0,
    val batteryTemp: Double = 0.0,
    val voltageMv: Int = 0,
    val charging: Boolean = false
)

/** 一次连续的应用场景记录。 */
data class AppSession(
    val id: Long,
    val packageName: String,
    val label: String,
    val activity: String,
    val startTime: Long,
    var endTime: Long,
    val model: String,
    val soc: String,
    val os: String,
    var note: String = "",
    val samples: MutableList<SceneSample> = mutableListOf()
) {
    val durationMs: Long
        get() {
            val end = if (endTime > startTime) endTime else (samples.lastOrNull()?.time ?: startTime)
            return (end - startTime).coerceAtLeast(0L)
        }

    /** 生成线程安全的深拷贝快照，用于异步落盘。 */
    fun snapshotCopy(): AppSession {
        val copiedSamples = synchronized(samples) { ArrayList(samples) }
        return copy(samples = copiedSamples)
    }

    fun toJson(): JSONObject {
        val safeSamples = synchronized(samples) { ArrayList(samples) }
        val root = JSONObject()
        root.put("id", id)
        root.put("package", packageName)
        root.put("label", label)
        root.put("activity", activity)
        root.put("start", startTime)
        root.put("end", endTime)
        root.put("model", model)
        root.put("soc", soc)
        root.put("os", os)
        root.put("note", note)
        val array = JSONArray()
        safeSamples.forEach { s ->
            val row = JSONArray()
            row.put(s.time)
            row.put(round2(s.fps))
            row.put(round2(s.frameMs))
            row.put(round2(s.jitter))
            row.put(round2(s.cpuTotal))
            row.put(round2(s.cpuLittle))
            row.put(round2(s.cpuBig))
            row.put(round2(s.freqLittle))
            row.put(round2(s.freqBig))
            row.put(round2(s.gpuUsage))
            row.put(round2(s.gpuFreq))
            row.put(round2(s.powerW))
            row.put(s.capacity)
            row.put(round2(s.cpuTemp))
            row.put(round2(s.gpuTemp))
            row.put(round2(s.batteryTemp))
            row.put(s.voltageMv)
            row.put(if (s.charging) 1 else 0)
            array.put(row)
        }
        root.put("samples", array)
        return root
    }

    companion object {
        fun fromJson(root: JSONObject): AppSession {
            val samples = ArrayList<SceneSample>()
            val array = root.optJSONArray("samples")
            if (array != null) {
                for (i in 0 until array.length()) {
                    val row = array.optJSONArray(i) ?: continue
                    if (row.length() < 12) continue
                    samples.add(
                        SceneSample(
                            time = row.optLong(0),
                            fps = row.optDouble(1, 0.0),
                            frameMs = row.optDouble(2, 0.0),
                            jitter = row.optDouble(3, 0.0),
                            cpuTotal = row.optDouble(4, 0.0),
                            cpuLittle = row.optDouble(5, 0.0),
                            cpuBig = row.optDouble(6, 0.0),
                            freqLittle = row.optDouble(7, 0.0),
                            freqBig = row.optDouble(8, 0.0),
                            gpuUsage = row.optDouble(9, 0.0),
                            gpuFreq = row.optDouble(10, 0.0),
                            powerW = row.optDouble(11, 0.0),
                            capacity = row.optInt(12, 0),
                            cpuTemp = row.optDouble(13, 0.0),
                            gpuTemp = row.optDouble(14, 0.0),
                            batteryTemp = row.optDouble(15, 0.0),
                            voltageMv = row.optInt(16, 0),
                            charging = row.optInt(17, 0) == 1
                        )
                    )
                }
            }
            return AppSession(
                id = root.optLong("id"),
                packageName = root.optString("package"),
                label = root.optString("label"),
                activity = root.optString("activity"),
                startTime = root.optLong("start"),
                endTime = root.optLong("end"),
                model = root.optString("model"),
                soc = root.optString("soc"),
                os = root.optString("os"),
                note = root.optString("note"),
                samples = samples
            )
        }
    }
}

data class SessionStats(
    val fpsMax: Double,
    val fpsMin: Double,
    val fpsAvg: Double,
    val jitterPercent: Double,
    val low5: Double,
    val avgSoc: Double,
    val maxBatteryTemp: Double,
    val avgBatteryTemp: Double,
    val avgPower: Double,
    val maxPower: Double,
    val minPower: Double,
    val avgCpu: Double,
    val avgGpu: Double
)

fun AppSession.buildStats(): SessionStats {
    val safeSamples = synchronized(samples) { ArrayList(samples) }
    val fpsValues = safeSamples.map { it.fps }.filter { it > 0.1 }
    val cpuValues = safeSamples.map { it.cpuTotal }.filter { it > 0.0 }
    val gpuValues = safeSamples.map { it.gpuUsage }.filter { it > 0.0 }
    val socValues = safeSamples.map { it.capacity.toDouble() }.filter { it > 0.0 }
    val batteryTemps = safeSamples.map { it.batteryTemp }.filter { it > 0.0 }

    // 修复 P1-6：优先统计放电状态下的功率，避免充电功率混入放电统计
    val dischargePowerValues = safeSamples.filter { !it.charging && it.powerW > 0.0 }.map { it.powerW }
    val allPowerValues = safeSamples.filter { it.powerW > 0.0 }.map { it.powerW }
    val powerValues = if (dischargePowerValues.isNotEmpty()) dischargePowerValues else allPowerValues

    val jitterValues = safeSamples.map { it.jitter }.filter { it > 0.0 }

    val fpsAvg = if (fpsValues.isEmpty()) 0.0 else fpsValues.average()
    val frameMs = if (fpsAvg > 0.0) 1000.0 / fpsAvg else 0.0
    val jitterAvg = if (jitterValues.isEmpty()) 0.0 else jitterValues.average()
    val sortedFps = fpsValues.sorted()
    val lowIndex = (sortedFps.size * 0.05).toInt().coerceIn(0, max(0, sortedFps.size - 1))

    // 时间加权计算场景平均功率
    var weightedPowerSum = 0.0
    var weightedTimeSum = 0L
    for (i in 1 until safeSamples.size) {
        val prev = safeSamples[i - 1]
        val curr = safeSamples[i]
        val dt = curr.time - prev.time
        if (dt in 1..30_000L && !curr.charging && curr.powerW > 0.0 && prev.powerW > 0.0) {
            weightedPowerSum += 0.5 * (prev.powerW + curr.powerW) * dt
            weightedTimeSum += dt
        }
    }
    val computedAvgPower = when {
        weightedTimeSum > 0L -> weightedPowerSum / weightedTimeSum.toDouble()
        powerValues.isNotEmpty() -> powerValues.average()
        else -> 0.0
    }

    return SessionStats(
        fpsMax = fpsValues.maxOrNull() ?: 0.0,
        fpsMin = fpsValues.minOrNull() ?: 0.0,
        fpsAvg = fpsAvg,
        jitterPercent = if (frameMs > 0.0) jitterAvg / frameMs * 100.0 else 0.0,
        low5 = if (sortedFps.isEmpty()) 0.0 else sortedFps[lowIndex],
        avgSoc = if (socValues.isEmpty()) 0.0 else socValues.average(),
        maxBatteryTemp = batteryTemps.maxOrNull() ?: 0.0,
        avgBatteryTemp = if (batteryTemps.isEmpty()) 0.0 else batteryTemps.average(),
        avgPower = computedAvgPower,
        maxPower = powerValues.maxOrNull() ?: 0.0,
        minPower = powerValues.minOrNull() ?: 0.0,
        avgCpu = if (cpuValues.isEmpty()) 0.0 else cpuValues.average(),
        avgGpu = if (gpuValues.isEmpty()) 0.0 else gpuValues.average()
    )
}

/** 曲线抽稀，避免采样点过多导致 UI 绘制卡顿。 */
fun <T> List<T>.downsample(maxPoints: Int): List<T> {
    if (size <= maxPoints || maxPoints < 2) return this
    val step = size.toDouble() / maxPoints.toDouble()
    val result = ArrayList<T>(maxPoints)
    var index = 0.0
    while (index < size) {
        result.add(this[index.toInt().coerceIn(0, size - 1)])
        index += step
    }
    val last = this[size - 1]
    if (result.lastOrNull() != last) result.add(last)
    return result
}

private fun round2(value: Double): Double = round(value * 100.0) / 100.0

internal fun stdDev(values: List<Double>): Double {
    if (values.size < 2) return 0.0
    val mean = values.average()
    var sum = 0.0
    values.forEach { v ->
        val d = v - mean
        sum += d * d
    }
    return sqrt(sum / values.size)
}
