package com.example.powerlogger

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.File
import java.io.FileFilter
import java.io.FileWriter
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.Locale
import kotlin.math.abs

/** 电池的一次快照，包含实际测算或读取到的电池总能量（Wh）。 */
data class BatterySnapshot(
    val level: Int,
    val tempC: Double,
    val voltageMv: Int,
    val charging: Boolean,
    val currentMa: Double,
    val capacityWh: Double
)

fun readBatterySnapshot(context: Context): BatterySnapshot {
    val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val rawLevel = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val level = if (rawLevel >= 0 && scale > 0) rawLevel * 100 / scale else 0
    val tempRaw = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
    val voltage = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
    val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL ||
        (status == BatteryManager.BATTERY_STATUS_UNKNOWN && plugged != 0)

    val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val rawCurrent = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
    val usable = if (rawCurrent == Int.MIN_VALUE || rawCurrent == Int.MAX_VALUE) 0 else rawCurrent
    val absVal = abs(usable.toDouble())
    // 修复 P1-3：Android BatteryManager.BATTERY_PROPERTY_CURRENT_NOW 标准单位为微安(µA)。
    // 正常待机/工作电流在 5,000 µA (5mA) ~ 15,000,000 µA (15A) 之间，仅极少数老旧定制内核直接返回 < 1500 的 mA 整数。
    val currentMa = when {
        absVal == 0.0 -> 0.0
        absVal >= 1_500.0 -> absVal / 1000.0
        else -> absVal
    }
    // 严格统一符号：充电为正（+），放电为负（-）
    val signedCurrent = if (charging) currentMa else -currentMa

    // 修复 P1-5：优先通过 BATTERY_PROPERTY_CHARGE_COUNTER (µAh) 与当前电量百分比推算真实电池总容量，或通过 PowerProfile 读取设计容量
    val capacityMah = resolveDeviceBatteryMah(context, batteryManager, level)
    val nominalVoltageV = if (voltage in 3_000..4_600) 3.85 else 3.85
    val capacityWh = (capacityMah * nominalVoltageV / 1000.0).coerceIn(10.0, 60.0)

    return BatterySnapshot(
        level = level,
        tempC = tempRaw / 10.0,
        voltageMv = voltage,
        charging = charging,
        currentMa = signedCurrent,
        capacityWh = capacityWh
    )
}

private fun resolveDeviceBatteryMah(
    context: Context,
    batteryManager: BatteryManager,
    level: Int
): Double {
    // 1. 尝试从 PowerProfile 反射获取电池设计容量 (mAh)
    try {
        val powerProfileClass = Class.forName("com.android.internal.os.PowerProfile")
        val instance = powerProfileClass.getConstructor(Context::class.java).newInstance(context)
        val cap = powerProfileClass.getMethod("getBatteryCapacity").invoke(instance) as? Double
        if (cap != null && cap in 1_500.0..15_000.0) {
            return cap
        }
    } catch (_: Throwable) {
    }

    // 2. 尝试通过 CHARGE_COUNTER (µAh) 与当前电量百分比反推总容量
    try {
        val chargeCounterUah = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        if (chargeCounterUah > 100_000 && level in 15..100) {
            val currentMah = chargeCounterUah / 1000.0
            val estimatedFullMah = currentMah * 100.0 / level.toDouble()
            if (estimatedFullMah in 1_800.0..15_000.0) {
                return estimatedFullMah
            }
        }
    } catch (_: Throwable) {
    }

    return 4_800.0
}

data class BatteryPoint(
    val time: Long,
    val level: Int,
    val powerW: Double,
    val tempC: Double,
    val voltageMv: Int,
    val screenOn: Boolean,
    val charging: Boolean
)

/**
 * 整机电池历史，供“Power Stats”页绘制 2 小时曲线。
 * 修复 P1-10：设定文件大小上限与 6 小时滑动保留窗口，自动清理过期历史行，避免 CSV 无限膨胀。
 */
object BatteryHistory {
    private const val FILE_NAME = "battery_history.csv"
    private const val MAX_FILE_BYTES = 384 * 1024L
    private const val RETENTION_WINDOW_MS = 6L * 60L * 60L * 1000L

    private val lock = Any()
    private var writer: BufferedWriter? = null
    private var file: File? = null
    private var pending = 0
    private var lastTime = 0L

    fun append(context: Context, point: BatteryPoint) {
        synchronized(lock) {
            if (point.time - lastTime < 700L) return@synchronized
            lastTime = point.time
            try {
                val target = file ?: File(context.filesDir, FILE_NAME).also { file = it }
                if (target.exists() && target.length() > MAX_FILE_BYTES) {
                    compactFileLocked(target)
                }
                val out = writer ?: run {
                    val isNew = !target.exists() || target.length() == 0L
                    BufferedWriter(FileWriter(target, true)).also {
                        writer = it
                        if (isNew) {
                            it.write("time,level,power_w,temp_c,voltage_mv,screen_on,charging\n")
                            it.flush()
                        }
                    }
                }
                out.write(
                    String.format(
                        Locale.US,
                        "%d,%d,%.3f,%.1f,%d,%d,%d\n",
                        point.time,
                        point.level,
                        point.powerW,
                        point.tempC,
                        point.voltageMv,
                        if (point.screenOn) 1 else 0,
                        if (point.charging) 1 else 0
                    )
                )
                pending++
                if (pending >= 4) {
                    out.flush()
                    pending = 0
                }
            } catch (_: Throwable) {
                writer = null
                pending = 0
            }
        }
    }

    private fun compactFileLocked(target: File) {
        try {
            writer?.flush()
            writer?.close()
        } catch (_: Throwable) {
        }
        writer = null

        try {
            val cutoff = System.currentTimeMillis() - RETENTION_WINDOW_MS
            val keptLines = ArrayList<String>(2048)
            keptLines.add("time,level,power_w,temp_c,voltage_mv,screen_on,charging")
            target.forEachLine { line ->
                if (line.isBlank() || line.startsWith("time")) return@forEachLine
                val t = line.substringBefore(',').toLongOrNull() ?: return@forEachLine
                if (t >= cutoff) {
                    keptLines.add(line)
                }
            }
            val tmp = File(target.parentFile, "$FILE_NAME.tmp")
            tmp.writeText(keptLines.joinToString("\n") + "\n")
            replaceFileAtomically(tmp, target)
        } catch (_: Throwable) {
        }
    }

    fun flush() {
        synchronized(lock) {
            try {
                writer?.flush()
            } catch (_: Throwable) {
            }
            pending = 0
        }
    }

    fun load(context: Context, windowMs: Long = 2L * 60L * 60L * 1000L): List<BatteryPoint> {
        val target = File(context.filesDir, FILE_NAME)
        if (!target.exists()) return emptyList()
        val cutoff = System.currentTimeMillis() - windowMs
        val result = ArrayList<BatteryPoint>()
        synchronized(lock) {
            try {
                writer?.flush()
                target.forEachLine { line ->
                    if (line.isBlank() || line.startsWith("time")) return@forEachLine
                    val parts = line.split(',')
                    if (parts.size < 7) return@forEachLine
                    val time = parts[0].toLongOrNull() ?: return@forEachLine
                    if (time < cutoff) return@forEachLine
                    val level = parts[1].toIntOrNull() ?: return@forEachLine
                    val power = parts[2].toDoubleOrNull() ?: 0.0
                    val temp = parts[3].toDoubleOrNull() ?: 0.0
                    val voltage = parts[4].toIntOrNull() ?: 0
                    val screen = parts[5].toIntOrNull() == 1
                    val charging = parts[6].toIntOrNull() == 1
                    result.add(BatteryPoint(time, level, power, temp, voltage, screen, charging))
                }
            } catch (_: Throwable) {
                return emptyList()
            }
        }
        val sorted = result.sortedBy { it.time }.toMutableList()
        if (sorted.size == 1) {
            val single = sorted.first()
            sorted.add(0, single.copy(time = single.time - 60_000L))
        }
        return sorted
    }

    fun clear(context: Context) {
        synchronized(lock) {
            try {
                writer?.close()
            } catch (_: Throwable) {
            }
            writer = null
            file = null
            pending = 0
            lastTime = 0L
            try {
                File(context.filesDir, FILE_NAME).delete()
            } catch (_: Throwable) {
            }
        }
    }
}

private fun replaceFileAtomically(tmp: File, target: File) {
    try {
        Files.move(
            tmp.toPath(),
            target.toPath(),
            StandardCopyOption.REPLACE_EXISTING,
            StandardCopyOption.ATOMIC_MOVE
        )
        return
    } catch (_: Throwable) {
    }
    try {
        Files.move(
            tmp.toPath(),
            target.toPath(),
            StandardCopyOption.REPLACE_EXISTING
        )
        return
    } catch (_: Throwable) {
    }
    try {
        target.writeText(tmp.readText())
        tmp.delete()
    } catch (_: Throwable) {
    }
}

object SessionStore {
    private const val DIR_NAME = "sessions"
    private const val MAX_STORED_SESSIONS = 60
    private val storeLock = Any()

    private fun dir(context: Context): File {
        val d = File(context.filesDir, DIR_NAME)
        if (!d.exists()) d.mkdirs()
        return d
    }

    /**
     * 修复 P1-7：使用原子替换（Files.move REPLACE_EXISTING），避免先 delete 再 rename 期间中断导致文件丢失。
     */
    fun save(context: Context, session: AppSession) {
        synchronized(storeLock) {
            try {
                val snapshot = session.snapshotCopy()
                val jsonText = snapshot.toJson().toString()
                val d = dir(context)
                val target = File(d, "session_${snapshot.id}.json")
                val tmp = File(d, "session_${snapshot.id}.tmp")
                tmp.writeText(jsonText)
                replaceFileAtomically(tmp, target)
                pruneOldSessionsLocked(d)
            } catch (_: Throwable) {
            }
        }
    }

    private fun pruneOldSessionsLocked(directory: File) {
        try {
            val files = directory.listFiles(FileFilter { it.isFile && it.name.endsWith(".json") }) ?: return
            if (files.size <= MAX_STORED_SESSIONS) return
            files.sortByDescending { it.lastModified() }
            for (i in MAX_STORED_SESSIONS until files.size) {
                files[i].delete()
            }
        } catch (_: Throwable) {
        }
    }

    fun load(context: Context, id: Long): AppSession? {
        synchronized(storeLock) {
            return try {
                val f = File(dir(context), "session_$id.json")
                if (!f.exists()) null else AppSession.fromJson(JSONObject(f.readText()))
            } catch (_: Throwable) {
                null
            }
        }
    }

    fun sessions(context: Context): List<AppSession> {
        synchronized(storeLock) {
            val files = dir(context).listFiles(FileFilter { f -> f.isFile && f.name.endsWith(".json") })
                ?: return emptyList()
            val list = ArrayList<AppSession>(files.size)
            files.forEach { f ->
                try {
                    list.add(AppSession.fromJson(JSONObject(f.readText())))
                } catch (_: Throwable) {
                }
            }
            return list.sortedByDescending { it.startTime }
        }
    }

    fun delete(context: Context, id: Long) {
        synchronized(storeLock) {
            try {
                File(dir(context), "session_$id.json").delete()
            } catch (_: Throwable) {
            }
        }
    }

    fun clear(context: Context) {
        synchronized(storeLock) {
            try {
                dir(context).listFiles()?.forEach { it.delete() }
            } catch (_: Throwable) {
            }
        }
    }
}

data class PowerStatsData(
    val points: List<BatteryPoint>,
    val level: Int,
    val tempC: Double,
    val voltageMv: Int,
    val charging: Boolean,
    val whUsed: Double,
    val avgW: Double,
    val usedMs: Long,
    val expectedMs: Long,
    val standbyPctPerHour: Double?,
    val sessions: List<AppSession>
)

/**
 * 聚合整机功耗统计与 App scenes 列表（应在 Dispatchers.IO 中调用）。
 * 修复项：
 * - P0-1：使用非 suspend 的 getAllSync()，消除编译错误；
 * - P1-4：采用相邻采样点时间差加权（梯形积分）计算平均功率与累计消耗 Wh；
 * - P1-5：使用设备真实电池容量（snapshot.capacityWh）估算剩余续航。
 */
fun loadPowerStats(context: Context): PowerStatsData {
    val points = BatteryHistory.load(context)
    val snapshot = readBatterySnapshot(context)
    val sessions = try {
        val fileSessions = SessionStore.sessions(context)
        val roomSessions = try {
            AppDatabase.getInstance(context).sessionRecordDao().getAllSync().map { it.toAppSession() }
        } catch (_: Throwable) {
            emptyList()
        }
        (fileSessions + roomSessions)
            .distinctBy { "${it.packageName}_${it.startTime / 5000L}" }
            .sortedByDescending { it.endTime.coerceAtLeast(it.startTime) }
    } catch (_: Throwable) {
        emptyList()
    }

    val level = points.lastOrNull()?.level ?: snapshot.level
    val temp = points.lastOrNull()?.tempC?.takeIf { it > 0.0 } ?: snapshot.tempC
    val voltage = points.lastOrNull()?.voltageMv?.takeIf { it > 0 } ?: snapshot.voltageMv
    val charging = points.lastOrNull()?.charging ?: snapshot.charging

    // 修复 P1-4：按相邻放电采样点时间间隔加权（梯形积分）计算 whUsed 与时间加权平均功率 avgW
    var whUsed = 0.0
    var weightedPowerTimeSum = 0.0
    var totalDischargeTimeMs = 0L

    for (i in 1 until points.size) {
        val prev = points[i - 1]
        val curr = points[i]
        val dt = curr.time - prev.time
        if (dt in 1..60_000L && !curr.charging && !prev.charging && curr.powerW > 0.0 && prev.powerW > 0.0) {
            val avgSegmentW = 0.5 * (prev.powerW + curr.powerW)
            whUsed += avgSegmentW * dt / 3_600_000.0
            weightedPowerTimeSum += avgSegmentW * dt
            totalDischargeTimeMs += dt
        }
    }

    val fallbackDischargeSamples = points.filter { !it.charging && it.powerW > 0.0 }
    val fallbackInstantW = if (!snapshot.charging) {
        (snapshot.voltageMv * abs(snapshot.currentMa) / 1_000_000.0).coerceAtLeast(0.0)
    } else {
        0.0
    }

    val avgW = when {
        totalDischargeTimeMs > 0L -> weightedPowerTimeSum / totalDischargeTimeMs.toDouble()
        fallbackDischargeSamples.isNotEmpty() -> fallbackDischargeSamples.map { it.powerW }.average()
        else -> fallbackInstantW
    }

    val usedMs = when {
        totalDischargeTimeMs > 0L -> totalDischargeTimeMs
        points.size >= 2 -> (points.last().time - points.first().time).coerceAtLeast(0L)
        else -> 0L
    }

    // 修复 P1-5：优先基于真实放电斜率计算预计续航，斜率尚不足时基于设备实测/设计电池容量（snapshot.capacityWh）估算
    var expectedMs = 0L
    if (points.size >= 2 && usedMs > 120_000L) {
        val first = points.first()
        val last = points.last()
        val hours = usedMs / 3_600_000.0
        val drop = first.level - last.level
        val rate = if (hours > 0.03 && drop >= 1) drop / hours else 0.0
        if (rate > 0.1) {
            expectedMs = (level / rate * 3_600_000.0).toLong()
        }
    }
    if (expectedMs <= 0L && avgW > 0.15 && level > 0) {
        val remainingWh = snapshot.capacityWh * (level / 100.0)
        expectedMs = (remainingWh / avgW * 3_600_000.0).toLong()
    }

    var standby: Double? = null
    val off = points.filter { !it.screenOn && !it.charging }
    if (off.size >= 2) {
        val hours = (off.last().time - off.first().time) / 3_600_000.0
        val drop = off.first().level - off.last().level
        if (hours >= 0.10 && drop > 0) {
            standby = drop / hours
        }
    }

    return PowerStatsData(
        points = points,
        level = level,
        tempC = temp,
        voltageMv = voltage,
        charging = charging,
        whUsed = whUsed,
        avgW = avgW,
        usedMs = usedMs,
        expectedMs = expectedMs,
        standbyPctPerHour = standby,
        sessions = sessions
    )
}
