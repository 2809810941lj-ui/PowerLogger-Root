package com.example.powerlogger

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : ComponentActivity() {

    private var pendingSessionId by mutableStateOf<Long?>(null)
    private var launchedFromHistory by mutableStateOf(false)
    private var pendingNotificationAction: (() -> Unit)? = null

    // 模块一状态：免责协议与 Root 检测均通过 SharedPreferences 持久化，仅首次安装打开时检测一次！
    private var disclaimerAccepted by mutableStateOf(false)
    private var rootVerified by mutableStateOf(false)
    private var showAutoStartRecommendDialog by mutableStateOf(false)

    // 模块四状态：由 Activity 生命周期直接驱动
    private var isInForeground by mutableStateOf(false)

    // 修复 P1-17：权限回调与具体业务动作解耦，无论通知权限是否授予均执行调用方原本请求的动作，不错误替换为其他服务
    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val action = pendingNotificationAction
            pendingNotificationAction = null
            if (!granted) {
                Toast.makeText(this, "未授予通知权限，通知栏状态可能无法显示", Toast.LENGTH_SHORT).show()
            }
            action?.invoke()
        }

    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) {
                startOverlayServiceInternal()
            } else {
                Toast.makeText(this, "未授予悬浮窗权限，FPS 悬浮胶囊无法显示", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLogManager.init(applicationContext)

        val prefs = getSharedPreferences(PREFS_ONBOARDING, Context.MODE_PRIVATE)
        disclaimerAccepted = prefs.getBoolean(KEY_DISCLAIMER_ACCEPTED, false)
        // Root 检测结果持久化在本地，首次检测通过后后续打开直接进主界面，不再每次检测
        rootVerified = prefs.getBoolean(KEY_ROOT_VERIFIED_ONCE, false)

        pendingSessionId = intent.getLongExtra(EXTRA_SESSION_ID, -1L).takeIf { it > 0L }
        launchedFromHistory = intent.getBooleanExtra(EXTRA_FROM_HISTORY, false)

        setContent {
            MaterialTheme(colorScheme = AppColorScheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    when {
                        !disclaimerAccepted -> {
                            DisclaimerScreen(
                                onAgree = {
                                    prefs.edit().putBoolean(KEY_DISCLAIMER_ACCEPTED, true).apply()
                                    disclaimerAccepted = true
                                    AppLogManager.i("Onboarding", "用户已同意免责协议")
                                },
                                onDecline = {
                                    AppLogManager.w("Onboarding", "用户拒绝免责协议，退出应用")
                                    finishAffinity()
                                }
                            )
                        }
                        !rootVerified -> {
                            RootCheckScreen(
                                onRootPassed = {
                                    prefs.edit().putBoolean(KEY_ROOT_VERIFIED_ONCE, true).apply()
                                    rootVerified = true
                                    AppLogManager.i("Onboarding", "首次 Root 权限检测通过，已持久化记录状态")
                                    if (!prefs.getBoolean(KEY_AUTOSTART_PROMPTED, false)) {
                                        prefs.edit().putBoolean(KEY_AUTOSTART_PROMPTED, true).apply()
                                        showAutoStartRecommendDialog = true
                                    }
                                    triggerAutoStartRecording()
                                },
                                onExitApp = {
                                    finishAffinity()
                                }
                            )
                        }
                        else -> {
                            PowerLoggerApp(
                                isInForeground = isInForeground,
                                pendingSessionId = pendingSessionId,
                                launchedFromHistory = launchedFromHistory,
                                showAutoStartDialog = showAutoStartRecommendDialog,
                                onDismissAutoStartDialog = { showAutoStartRecommendDialog = false },
                                onRequestAutoStartDialog = { showAutoStartRecommendDialog = true },
                                onPendingConsumed = { pendingSessionId = null },
                                onFinishActivity = { finish() },
                                onToggleOverlay = { enabled ->
                                    if (enabled) {
                                        requestOverlayStart()
                                    } else {
                                        stopOverlayService()
                                    }
                                },
                                onOpenHistoryList = {
                                    startActivity(Intent(this, HistoryListActivity::class.java))
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val id = intent.getLongExtra(EXTRA_SESSION_ID, -1L)
        launchedFromHistory = intent.getBooleanExtra(EXTRA_FROM_HISTORY, false)
        if (id > 0L) pendingSessionId = id
    }

    /**
     * 模块四：进入前台（onResume）时自动开始记录。
     */
    override fun onResume() {
        super.onResume()
        isInForeground = true
        if (disclaimerAccepted && rootVerified) {
            triggerAutoStartRecording()
            notifyPowerServiceUiState(foreground = true)
        }
    }

    /**
     * 退出到后台（onStop）时：
     * 通知 PowerMonitorService 切换为 2.5s 轻量后台采样模式，持续记录 Power Stats 电池曲线与 App scenes 应用功耗，
     * 同时停止主界面 UI 轮询并裁剪内存缓冲，兼顾“Power Stats 一直有数据”与“后台极低功耗”。
     */
    override fun onStop() {
        isInForeground = false
        super.onStop()
        if (!isChangingConfigurations) {
            if (disclaimerAccepted && rootVerified) {
                notifyPowerServiceUiState(foreground = false)
            }
            PowerMonitorState.trimMemory()
        }
    }

    private fun notifyPowerServiceUiState(foreground: Boolean) {
        try {
            val action = if (foreground) {
                PowerMonitorService.ACTION_UI_FOREGROUND
            } else {
                PowerMonitorService.ACTION_UI_BACKGROUND
            }
            startService(Intent(this, PowerMonitorService::class.java).setAction(action))
        } catch (_: Throwable) {
        }
    }

    private fun triggerAutoStartRecording() {
        if (PowerMonitorState.state.value.isRunning) return
        withNotificationPermission {
            startPowerService()
        }
    }

    private fun withNotificationPermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingNotificationAction = action
            try {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } catch (t: Throwable) {
                AppLogManager.w("Permission", "通知权限请求异常，直接启动服务", t)
                action()
            }
        } else {
            action()
        }
    }

    private fun requestOverlayStart() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请允许 PowerLogger 显示在其他应用上层", Toast.LENGTH_LONG).show()
            try {
                overlayPermissionLauncher.launch(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (t: Throwable) {
                AppLogManager.e("Overlay", "跳转悬浮窗权限设置异常", t)
            }
            return
        }
        startOverlayServiceInternal()
    }

    private fun startOverlayServiceInternal() {
        withNotificationPermission {
            try {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, FloatingFpsService::class.java)
                        .setAction(FloatingFpsService.ACTION_START)
                )
                AppLogManager.i("Overlay", "已请求启动 FPS 悬浮窗服务")
            } catch (error: Throwable) {
                AppLogManager.e("Overlay", "启动悬浮窗服务失败", error)
                Toast.makeText(
                    this,
                    "启动悬浮窗失败：${error.message ?: "未知错误"}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun stopOverlayService() {
        try {
            startService(
                Intent(this, FloatingFpsService::class.java)
                    .setAction(FloatingFpsService.ACTION_STOP)
            )
            AppLogManager.i("Overlay", "已请求停止 FPS 悬浮窗服务")
        } catch (t: Throwable) {
            AppLogManager.w("Overlay", "停止悬浮窗服务异常", t)
        }
    }

    private fun startPowerService() {
        try {
            val intent = Intent(this, PowerMonitorService::class.java)
                .setAction(PowerMonitorService.ACTION_START)
            ContextCompat.startForegroundService(this, intent)
        } catch (error: Throwable) {
            AppLogManager.e("PowerService", "自动开始记录失败", error)
        }
    }

    private fun stopPowerService() {
        try {
            startService(
                Intent(this, PowerMonitorService::class.java)
                    .setAction(PowerMonitorService.ACTION_STOP)
            )
        } catch (t: Throwable) {
            AppLogManager.w("PowerService", "停止整机记录服务异常", t)
        }
    }

    companion object {
        const val EXTRA_SESSION_ID = "extra_session_id"
        const val EXTRA_FROM_HISTORY = "extra_from_history"
        private const val PREFS_ONBOARDING = "power_logger_onboarding"
        private const val KEY_DISCLAIMER_ACCEPTED = "disclaimer_accepted"
        private const val KEY_ROOT_VERIFIED_ONCE = "root_verified_once"
        private const val KEY_AUTOSTART_PROMPTED = "autostart_prompted_once"
    }
}

private val PageBackground = Color(0xFFF2F4F8)
private val CardSurface = Color.White
private val PrimaryAccent = Color(0xFF3B5998)
private val TextPrimary = Color(0xFF1B1C1E)
private val TextSecondary = Color(0xFF6E7178)
private val DividerLight = Color(0xFFE9ECF2)

private val AppColorScheme = lightColorScheme(
    primary = PrimaryAccent,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE4F5),
    onPrimaryContainer = Color(0xFF162747),
    secondary = Color(0xFF535F70),
    onSecondary = Color.White,
    background = PageBackground,
    onBackground = TextPrimary,
    surface = CardSurface,
    onSurface = TextPrimary,
    surfaceVariant = Color(0xFFE7EAF0),
    onSurfaceVariant = TextSecondary
)

/**
 * 纯 Compose 树内嵌模态对话框（不创建额外 Window / DialogWrapper，彻底杜绝子窗口 LifecycleOwner 崩溃）。
 */
@Composable
private fun AppModalDialog(
    title: String,
    onDismiss: () -> Unit,
    confirmText: String,
    confirmColor: Color = PrimaryAccent,
    onConfirm: () -> Unit,
    dismissText: String? = null,
    onDismissButton: (() -> Unit)? = null,
    neutralText: String? = null,
    onNeutralButton: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    BackHandler {
        onDismiss()
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            )
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                ),
            shape = RoundedCornerShape(22.dp),
            color = CardSurface,
            shadowElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                content()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (neutralText != null && onNeutralButton != null) {
                        TextButton(onClick = onNeutralButton) {
                            Text(neutralText, color = PrimaryAccent, fontSize = 13.sp)
                        }
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    if (dismissText != null) {
                        TextButton(onClick = { onDismissButton?.invoke() ?: onDismiss() }) {
                            Text(dismissText, color = TextSecondary, fontSize = 14.sp)
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    TextButton(onClick = onConfirm) {
                        Text(
                            text = confirmText,
                            color = confirmColor,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// =========================================================================
// 模块一：首次启动免责协议与 Root 强制检测拦截页（仅首次安装打开时执行）
// =========================================================================

@Composable
private fun DisclaimerScreen(
    onAgree: () -> Unit,
    onDecline: () -> Unit
) {
    BackHandler {
        onDecline()
    }

    val disclaimerText = (
        "欢迎使用 PowerLogger。在使用本软件前，请仔细阅读以下条款：\n\n" +
            "1. Root 风险提示：本软件需要获取设备的 Root 权限以实现更精准的性能监控与进程管理。获取 Root 权限可能会带来系统安全风险、数据丢失风险，甚至导致设备无法开机。您确认已知晓相关风险，并自愿承担因使用 Root 权限而导致的一切后果。\n\n" +
            "2. 数据隐私：本软件记录的性能数据仅保存在您的设备本地，绝不会上传至任何服务器。\n\n" +
            "3. 强制停止应用：使用本软件强制停止其他应用可能会导致该应用数据丢失或异常，本软件不承担责任。\n\n" +
            "4. 责任免除：本软件仅供性能分析与交流学习使用。开发者不对使用本软件造成的任何直接或间接设备损坏、数据丢失负责。\n\n" +
            "用户必须点击“同意”才能继续，拒绝则退出 App。"
        )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PageBackground)
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = CardSurface,
            shadowElevation = 2.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(PrimaryAccent.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        BoltGlyph(iconSize = 22.dp, tint = PrimaryAccent)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "免责协议与风险提示",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "首次使用请阅读并确认以下条款",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 240.dp, max = 380.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = PageBackground
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        Text(
                            text = disclaimerText,
                            fontSize = 14.sp,
                            lineHeight = 22.sp,
                            color = TextPrimary
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDecline,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = CircleShape
                    ) {
                        Text("拒绝", fontSize = 14.sp, color = Color(0xFFE5484D))
                    }
                    Button(
                        onClick = onAgree,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryAccent)
                    ) {
                        Text("同意", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun RootCheckScreen(
    onRootPassed: () -> Unit,
    onExitApp: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var showFailDialog by remember { mutableStateOf(false) }
    var statusHint by remember {
        mutableStateOf("首次打开需验证一次 Root 权限，验证通过后后续启动无需重复检测")
    }

    BackHandler {
        if (showFailDialog) {
            showFailDialog = false
        } else {
            onExitApp()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PageBackground)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = CardSurface,
                shadowElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(PrimaryAccent.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        ChipGlyph(iconSize = 36.dp, tint = PrimaryAccent)
                    }

                    Text(
                        text = "Root 权限检测",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Text(
                        text = statusHint,
                        fontSize = 14.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp
                    )

                    Button(
                        onClick = {
                            if (checking) return@Button
                            checking = true
                            statusHint = "正在执行 su 命令申请并检测 Root 权限…"
                            scope.launch {
                                val granted = withContext(Dispatchers.IO) {
                                    ProcessManager.checkRootAccess()
                                }
                                checking = false
                                if (granted) {
                                    statusHint = "Root 权限验证通过，正在进入主界面…"
                                    onRootPassed()
                                } else {
                                    AppLogManager.w("RootCheck", "首次 Root 检测未通过")
                                    statusHint = "未检测到 Root 权限，请在 Magisk / KernelSU / APatch 中授权后重试"
                                    showFailDialog = true
                                }
                            }
                        },
                        enabled = !checking,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PrimaryAccent,
                            disabledContainerColor = PrimaryAccent.copy(alpha = 0.6f),
                            contentColor = Color.White,
                            disabledContentColor = Color.White
                        )
                    ) {
                        Text(
                            text = if (checking) "正在检测 Root 权限…" else "自动检测",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        if (showFailDialog) {
            AppModalDialog(
                title = "权限受限",
                onDismiss = { showFailDialog = false },
                confirmText = "我知道了",
                onConfirm = { showFailDialog = false }
            ) {
                Text(
                    text = "必须获得 Root 权限才能使用",
                    fontSize = 15.sp,
                    color = TextPrimary,
                    lineHeight = 22.sp
                )
            }
        }
    }
}

// =========================================================================
// 模块二 & 模块三 & 模块四：主界面多页架构（修复二级页面返回保持当前 Tab & 进程管理页侧滑防退）
// =========================================================================

private sealed class Screen {
    object Home : Screen()
    object Stats : Screen()
    object Logs : Screen()
    data class Detail(
        val id: Long,
        val fromStats: Boolean,
        val finishOnBack: Boolean
    ) : Screen()
}

@Composable
private fun PowerLoggerApp(
    isInForeground: Boolean,
    pendingSessionId: Long?,
    launchedFromHistory: Boolean,
    showAutoStartDialog: Boolean,
    onDismissAutoStartDialog: () -> Unit,
    onRequestAutoStartDialog: () -> Unit,
    onPendingConsumed: () -> Unit,
    onFinishActivity: () -> Unit,
    onToggleOverlay: (Boolean) -> Unit,
    onOpenHistoryList: () -> Unit
) {
    // 持久化记住用户在主界面所处的 Tab 索引（0: 曲线概览, 1: 数据统计, 2: 进程管理）
    // 确保从“数据统计”页点击任何方块进入二级界面再返回时，精准回到“数据统计”页！
    var savedHomeTab by rememberSaveable { mutableIntStateOf(0) }

    var screen by remember {
        val initialId = pendingSessionId
        mutableStateOf<Screen>(
            if (initialId != null && initialId > 0L) {
                Screen.Detail(
                    id = initialId,
                    fromStats = false,
                    finishOnBack = launchedFromHistory
                )
            } else {
                Screen.Home
            }
        )
    }

    LaunchedEffect(pendingSessionId, launchedFromHistory) {
        val id = pendingSessionId
        if (id != null && id > 0L) {
            screen = Screen.Detail(
                id = id,
                fromStats = false,
                finishOnBack = launchedFromHistory
            )
            onPendingConsumed()
        }
    }

    BackHandler(enabled = screen !is Screen.Home) {
        when (val current = screen) {
            is Screen.Detail -> {
                if (current.finishOnBack) {
                    onFinishActivity()
                } else if (current.fromStats) {
                    screen = Screen.Stats
                } else {
                    screen = Screen.Home
                }
            }
            is Screen.Stats -> {
                screen = Screen.Home
            }
            is Screen.Logs -> {
                screen = Screen.Home
            }
            else -> screen = Screen.Home
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (val current = screen) {
            is Screen.Home -> MainPagerScreen(
                isInForeground = isInForeground,
                currentTab = savedHomeTab,
                onTabChanged = { newTab -> savedHomeTab = newTab },
                onToggleOverlay = onToggleOverlay,
                onOpenHistoryList = {
                    savedHomeTab = 1
                    onOpenHistoryList()
                },
                onOpenStats = {
                    savedHomeTab = 1
                    screen = Screen.Stats
                },
                onOpenLogs = {
                    screen = Screen.Logs
                },
                onOpenAutoStartGuide = onRequestAutoStartDialog
            )
            is Screen.Stats -> PowerStatsScreen(
                onBack = { screen = Screen.Home },
                onOpenSession = { id ->
                    screen = Screen.Detail(
                        id = id,
                        fromStats = true,
                        finishOnBack = false
                    )
                }
            )
            is Screen.Logs -> AppLogScreen(
                onBack = { screen = Screen.Home }
            )
            is Screen.Detail -> SessionDetailScreen(
                sessionId = current.id,
                onBack = {
                    if (current.finishOnBack) {
                        onFinishActivity()
                    } else if (current.fromStats) {
                        screen = Screen.Stats
                    } else {
                        screen = Screen.Home
                    }
                }
            )
        }

        // 推荐开启自启动弹窗
        if (showAutoStartDialog) {
            val context = LocalContext.current
            val scope = rememberCoroutineScope()
            AppModalDialog(
                title = "推荐开启自启动与后台保活",
                onDismiss = onDismissAutoStartDialog,
                confirmText = "一键优化并去设置",
                onConfirm = {
                    onDismissAutoStartDialog()
                    scope.launch {
                        val msg = withContext(Dispatchers.IO) {
                            AppLogManager.applyRootAutoStartOptimization(context)
                        }
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        AppLogManager.openAutoStartSettings(context)
                    }
                },
                dismissText = "稍后设置",
                onDismissButton = onDismissAutoStartDialog
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "为确保 FPS 悬浮窗在游戏与应用切换期间不被系统强行回收，建议开启 PowerLogger 的【自启动】权限并关闭省电限制。",
                        fontSize = 14.sp,
                        color = TextPrimary,
                        lineHeight = 20.sp
                    )
                    Text(
                        text = "点击“一键优化并去设置”将自动通过 Root 将本应用加入系统省电白名单，并打开系统的自启动管理页面。",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

/**
 * 主界面容器：顶部栏 + TabRow + HorizontalPager
 * - 修复在“进程管理”（Tab 2）或“数据统计”（Tab 1）侧滑返回时直接退出应用的 Bug；
 * - 记住当前所处 Tab，从二级界面返回时自动保持在原 Tab。
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MainPagerScreen(
    isInForeground: Boolean,
    currentTab: Int,
    onTabChanged: (Int) -> Unit,
    onToggleOverlay: (Boolean) -> Unit,
    onOpenHistoryList: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenLogs: () -> Unit,
    onOpenAutoStartGuide: () -> Unit
) {
    val state by PowerMonitorState.state.collectAsState()
    val overlayRunning by OverlayState.running.collectAsState()
    val overlayFps by OverlayState.fps.collectAsState()
    val logs by AppLogManager.logs.collectAsState()
    val errorLogCount = remember(logs) { logs.count { it.level == "ERROR" || it.level == "CRASH" } }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showDirectoryDialog by remember { mutableStateOf(false) }
    var showSelfTest by remember { mutableStateOf(false) }
    var selfTestText by remember { mutableStateOf("") }
    var selfTestLoading by remember { mutableStateOf(false) }

    // 修复 P1-12：彻底移除在组合阶段基于高频 lastSampleTime 的主线程同步文件/数据库读取，
    // 改为在 IO 协程中按 4 秒周期异步更新快照与统计数据，消除主线程卡顿与重复 I/O。
    var roomRecordCount by remember { mutableIntStateOf(0) }
    var batterySnapshot by remember {
        mutableStateOf(
            BatterySnapshot(level = 0, tempC = 0.0, voltageMv = 0, charging = false, currentMa = 0.0, capacityWh = 18.5)
        )
    }
    var powerStats by remember { mutableStateOf<PowerStatsData?>(null) }

    LaunchedEffect(isInForeground) {
        if (!isInForeground) return@LaunchedEffect
        launch(Dispatchers.IO) {
            try {
                AppDatabase.getInstance(context).sessionRecordDao().observeAll().collectLatest { list ->
                    roomRecordCount = list.size
                }
            } catch (t: Throwable) {
                AppLogManager.w("RoomObserve", "监听历史记录数量异常", t)
            }
        }
        while (isInForeground) {
            val (snap, stats) = withContext(Dispatchers.IO) {
                val s = try {
                    readBatterySnapshot(context)
                } catch (_: Throwable) {
                    BatterySnapshot(level = 0, tempC = 0.0, voltageMv = 0, charging = false, currentMa = 0.0, capacityWh = 18.5)
                }
                val p = try {
                    loadPowerStats(context)
                } catch (_: Throwable) {
                    null
                }
                s to p
            }
            batterySnapshot = snap
            powerStats = stats
            delay(4000L)
        }
    }

    val csvDirectory = context.getExternalFilesDir(null)
        ?.let { File(it, "logs").absolutePath }
        ?: "外部存储目录不可用"

    val pagerState = rememberPagerState(
        initialPage = currentTab.coerceIn(0, 2),
        pageCount = { 3 }
    )

    // 同步 Pager 页码到父级 rememberSaveable 状态
    LaunchedEffect(pagerState.currentPage) {
        onTabChanged(pagerState.currentPage)
    }

    // 关键修复：当处于“数据统计”(Page 1) 或“进程管理”(Page 2) 时，侧滑返回手势平滑退回上一页，而不是直接退出 Activity！
    BackHandler(enabled = pagerState.currentPage > 0) {
        scope.launch {
            val targetPage = (pagerState.currentPage - 1).coerceAtLeast(0)
            pagerState.animateScrollToPage(targetPage)
        }
    }

    val tabTitles = remember { listOf("曲线概览", "数据统计", "进程管理") }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(PageBackground)
        ) {
            // 顶部应用栏（含日志诊断入口、环境自检、CSV目录）
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = CardSurface,
                shadowElevation = 1.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 18.dp, end = 8.dp, top = 12.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "PowerLogger",
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = state.message,
                            fontSize = 11.sp,
                            color = if (state.isRunning) PrimaryAccent else TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    StatusPill(running = state.isRunning)
                    // 日志诊断按钮（若有 ERROR/CRASH 显示红点提示）
                    IconButton(onClick = onOpenLogs) {
                        Box(contentAlignment = Alignment.TopEnd) {
                            BugLogGlyph(
                                iconSize = 20.dp,
                                tint = if (errorLogCount > 0) Color(0xFFE5484D) else TextSecondary
                            )
                            if (errorLogCount > 0) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFE5484D))
                                )
                            }
                        }
                    }
                    IconButton(
                        onClick = {
                            selfTestLoading = true
                            selfTestText = "正在读取 Root 与 SurfaceFlinger 数据…"
                            showSelfTest = true
                            scope.launch {
                                val result = withContext(Dispatchers.IO) {
                                    try {
                                        SceneSampler(context).diagnose()
                                    } catch (t: Throwable) {
                                        AppLogManager.e("SelfTest", "环境自检失败", t)
                                        "自检异常：${t.message ?: "未知错误"}"
                                    }
                                }
                                selfTestText = result
                                selfTestLoading = false
                            }
                        }
                    ) {
                        SettingsGlyph(iconSize = 20.dp, tint = TextSecondary)
                    }
                    IconButton(onClick = { showDirectoryDialog = true }) {
                        MoreVertGlyph(iconSize = 20.dp, tint = TextSecondary)
                    }
                }
            }

            // 顶部 TabLayout 导航栏
            TabRow(
                selectedTabIndex = pagerState.currentPage,
                containerColor = CardSurface,
                contentColor = PrimaryAccent,
                indicator = { tabPositions ->
                    if (pagerState.currentPage < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[pagerState.currentPage]),
                            height = 3.dp,
                            color = PrimaryAccent
                        )
                    }
                },
                divider = {
                    HorizontalDivider(thickness = 0.8.dp, color = DividerLight)
                }
            ) {
                tabTitles.forEachIndexed { index, title ->
                    val selected = pagerState.currentPage == index
                    Tab(
                        selected = selected,
                        onClick = {
                            scope.launch {
                                pagerState.animateScrollToPage(index)
                            }
                        },
                        text = {
                            Text(
                                text = title,
                                fontSize = 14.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = if (selected) PrimaryAccent else TextSecondary
                            )
                        }
                    )
                }
            }

            // 多页滑动容器（移除 beyondBoundsPageCount 预加载冲突，滑动流畅且不卡顿）
            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                beyondBoundsPageCount = 0
            ) { page ->
                val pageOffset = (
                    (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
                    ).let { abs(it).coerceIn(0f, 1f) }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            val scale = 1f - pageOffset * 0.03f
                            scaleX = scale
                            scaleY = scale
                            alpha = 1f - pageOffset * 0.2f
                        }
                ) {
                    when (page) {
                        0 -> OverviewCurvePage(
                            state = state,
                            batterySnapshot = batterySnapshot,
                            powerStats = powerStats
                        )
                        1 -> StatsGridPage(
                            state = state,
                            batterySnapshot = batterySnapshot,
                            powerStats = powerStats,
                            overlayRunning = overlayRunning,
                            overlayFps = overlayFps,
                            roomRecordCount = roomRecordCount,
                            errorLogCount = errorLogCount,
                            onToggleOverlay = onToggleOverlay,
                            onOpenHistoryList = onOpenHistoryList,
                            onOpenStats = onOpenStats,
                            onOpenLogs = onOpenLogs,
                            onOpenAutoStartGuide = onOpenAutoStartGuide,
                            onSwitchToProcessTab = {
                                scope.launch {
                                    pagerState.animateScrollToPage(2)
                                }
                            }
                        )
                        else -> ProcessManagerPage()
                    }
                }
            }
        }

        if (showDirectoryDialog) {
            val clipboard = LocalClipboardManager.current
            AppModalDialog(
                title = "CSV 保存目录",
                onDismiss = { showDirectoryDialog = false },
                confirmText = "复制路径",
                onConfirm = {
                    clipboard.setText(AnnotatedString(csvDirectory))
                    Toast.makeText(context, "目录路径已复制", Toast.LENGTH_SHORT).show()
                    showDirectoryDialog = false
                },
                dismissText = "关闭",
                onDismissButton = { showDirectoryDialog = false }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(csvDirectory, fontSize = 13.sp, color = TextPrimary)
                    Text(
                        text = "记录文件名格式：power_时间戳.csv",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        if (showSelfTest) {
            AppModalDialog(
                title = if (selfTestLoading) "环境自检（读取中…）" else "环境自检",
                onDismiss = { showSelfTest = false },
                confirmText = "关闭",
                onConfirm = { showSelfTest = false }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp, max = 380.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = selfTestText,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = TextPrimary
                    )
                }
            }
        }
    }
}

// =========================================================================
// 第一页（Tab 1）：曲线概览 —— 上方显示实时电压、电流、功耗、温度；下方放大曲线占据屏幕主要部分
// =========================================================================

@Composable
private fun OverviewCurvePage(
    state: PowerMonitorUiState,
    batterySnapshot: BatterySnapshot,
    powerStats: PowerStatsData?
) {
    val effectiveVoltageMv = if (state.lastSampleTime > 0L && state.voltageMv > 0) {
        state.voltageMv
    } else {
        batterySnapshot.voltageMv
    }
    val voltageText = if (effectiveVoltageMv > 0) {
        String.format(Locale.US, "%.3f V", effectiveVoltageMv / 1000.0)
    } else {
        "--"
    }

    val isChargingNow = if (state.lastSampleTime > 0L) state.charging else batterySnapshot.charging
    val signPrefix = if (isChargingNow) "+" else "-"

    val effectiveCurrentAbsMa = if (state.lastSampleTime > 0L) {
        abs(state.currentMa)
    } else {
        abs(batterySnapshot.currentMa)
    }
    val currentText = if (effectiveVoltageMv > 0 && effectiveCurrentAbsMa > 0.0) {
        String.format(Locale.US, "%s%.1f mA", signPrefix, effectiveCurrentAbsMa)
    } else {
        "--"
    }

    val instantAbsWatts = when {
        state.lastSampleTime > 0L -> abs(state.powerMw) / 1000.0
        effectiveVoltageMv > 0 && effectiveCurrentAbsMa > 0.0 ->
            effectiveVoltageMv * effectiveCurrentAbsMa / 1_000_000.0
        else -> 0.0
    }
    val powerText = if (instantAbsWatts > 0.0) {
        String.format(Locale.US, "%s%.2f W", signPrefix, instantAbsWatts)
    } else {
        "-- W"
    }

    val effectiveTempC = if (state.tempC > 0.0) state.tempC else batterySnapshot.tempC
    val tempText = if (effectiveTempC > 0.0) {
        String.format(Locale.US, "%.1f °C", effectiveTempC)
    } else {
        "--"
    }

    // 严格只使用纯放电样本（!charging）绘制放电功耗曲线与计算放电平均/峰值/最低功耗，充电期间绝不混入！
    val chartPointsMw = remember(state.historyPowerMw, powerStats) {
        if (state.historyPowerMw.size >= 2) {
            state.historyPowerMw.map { abs(it) }
        } else {
            powerStats?.points
                ?.filter { !it.charging && it.powerW > 0.0 }
                ?.takeLast(60)
                ?.map { it.powerW * 1000.0 }
                .orEmpty()
        }
    }

    val fallbackDischargeW = if (!isChargingNow) instantAbsWatts else 0.0
    val avgW = if (chartPointsMw.isNotEmpty()) chartPointsMw.average() / 1000.0 else fallbackDischargeW
    val maxW = if (chartPointsMw.isNotEmpty()) (chartPointsMw.maxOrNull() ?: 0.0) / 1000.0 else fallbackDischargeW
    val minW = if (chartPointsMw.isNotEmpty()) (chartPointsMw.minOrNull() ?: 0.0) / 1000.0 else fallbackDischargeW

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PageBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            RealtimeHeaderTile(
                label = "实时功耗",
                value = powerText,
                sub = if (state.charging || batterySnapshot.charging) "充电状态" else "放电状态",
                accent = PrimaryAccent,
                modifier = Modifier.weight(1f)
            )
            RealtimeHeaderTile(
                label = "电池温度",
                value = tempText,
                sub = "当前电量 ${batterySnapshot.level}%",
                accent = Color(0xFFE67E22),
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            RealtimeHeaderTile(
                label = "实时电压",
                value = voltageText,
                sub = "${effectiveVoltageMv} mV",
                accent = Color(0xFF2E86DE),
                modifier = Modifier.weight(1f)
            )
            RealtimeHeaderTile(
                label = "实时电流",
                value = currentText,
                sub = "数据源 ${state.source.ifBlank { "SYSFS" }.uppercase(Locale.US)}",
                accent = Color(0xFF27AE60),
                modifier = Modifier.weight(1f)
            )
        }

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            shape = RoundedCornerShape(22.dp),
            color = CardSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "实时功耗监控曲线",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "全天候智能监测中 · 切出应用亦持续记录电池曲线与 App scenes",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                    Surface(
                        color = PageBackground,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "${chartPointsMw.size} 采样点",
                            fontSize = 11.sp,
                            color = PrimaryAccent,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(vertical = 4.dp)
                ) {
                    ExpandedPowerChart(
                        valuesMw = chartPointsMw,
                        lineColor = PrimaryAccent
                    )
                }

                HorizontalDivider(thickness = 0.8.dp, color = DividerLight)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    CurveStatItem(
                        label = "放电平均",
                        value = if (avgW > 0.0) String.format(Locale.US, "-%.2f W", avgW) else "-- W"
                    )
                    CurveStatItem(
                        label = "放电峰值",
                        value = if (maxW > 0.0) String.format(Locale.US, "-%.2f W", maxW) else "-- W"
                    )
                    CurveStatItem(
                        label = "放电最低",
                        value = if (minW > 0.0) String.format(Locale.US, "-%.2f W", minW) else "-- W"
                    )
                }
            }
        }
    }
}

@Composable
private fun RealtimeHeaderTile(
    label: String,
    value: String,
    sub: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = CardSurface
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(accent)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = label,
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }
            Text(
                text = value,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1
            )
            Text(
                text = sub,
                fontSize = 11.sp,
                color = TextSecondary,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun CurveStatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 11.sp, color = TextSecondary)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
    }
}

@Composable
private fun ExpandedPowerChart(
    valuesMw: List<Double>,
    lineColor: Color
) {
    val displayWatts = if (valuesMw.size >= 2) {
        valuesMw.map { it / 1000.0 }
    } else {
        listOf(1.2, 1.35, 1.28, 1.42, 1.30, 1.25)
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val leftAxisWidth = 38.dp.toPx()
        val rightPad = 10.dp.toPx()
        val topPad = 10.dp.toPx()
        val bottomPad = 14.dp.toPx()

        val plotWidth = (size.width - leftAxisWidth - rightPad).coerceAtLeast(1f)
        val plotHeight = (size.height - topPad - bottomPad).coerceAtLeast(1f)

        val rawMin = displayWatts.minOrNull() ?: 0.0
        val rawMax = displayWatts.maxOrNull() ?: 5.0
        val span = (rawMax - rawMin).coerceAtLeast(1.0)
        val yMin = (rawMin - span * 0.2).coerceAtLeast(0.0)
        val yMax = rawMax + span * 0.2
        val yRange = (yMax - yMin).coerceAtLeast(0.5)

        val textPaint = android.graphics.Paint().apply {
            isAntiAlias = true
            color = 0xFF8E929B.toInt()
            textSize = 10.sp.toPx()
            textAlign = android.graphics.Paint.Align.RIGHT
        }

        val dashEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 4.dp.toPx()), 0f)
        for (i in 0..4) {
            val fraction = i / 4f
            val y = topPad + plotHeight * fraction
            drawLine(
                color = Color(0xFFE6E9F0),
                start = Offset(leftAxisWidth, y),
                end = Offset(leftAxisWidth + plotWidth, y),
                strokeWidth = 1.dp.toPx(),
                pathEffect = dashEffect
            )
            val labelVal = yMax - yRange * fraction
            drawContext.canvas.nativeCanvas.drawText(
                String.format(Locale.US, "%.1fW", labelVal),
                leftAxisWidth - 6.dp.toPx(),
                y + 3.5.dp.toPx(),
                textPaint
            )
        }

        val points = displayWatts.mapIndexed { idx, w ->
            val x = leftAxisWidth + plotWidth * idx / (displayWatts.size - 1).toFloat()
            val norm = ((w - yMin) / yRange).toFloat().coerceIn(0f, 1f)
            val y = topPad + plotHeight * (1f - norm)
            Offset(x, y)
        }

        if (points.size < 2) return@Canvas

        val linePath = Path().apply {
            moveTo(points.first().x, points.first().y)
            for (i in 0 until points.size - 1) {
                val p0 = points[i]
                val p1 = points[i + 1]
                val cx = (p0.x + p1.x) / 2f
                cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
            }
        }

        val fillPath = Path().apply {
            addPath(linePath)
            lineTo(points.last().x, topPad + plotHeight)
            lineTo(points.first().x, topPad + plotHeight)
            close()
        }

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    lineColor.copy(alpha = 0.26f),
                    lineColor.copy(alpha = 0.02f)
                ),
                startY = topPad,
                endY = topPad + plotHeight
            )
        )

        drawPath(
            path = linePath,
            color = lineColor,
            style = Stroke(
                width = 2.8.dp.toPx(),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )

        val lastPt = points.last()
        drawCircle(
            color = lineColor.copy(alpha = 0.30f),
            radius = 7.dp.toPx(),
            center = lastPt
        )
        drawCircle(
            color = Color.White,
            radius = 4.2.dp.toPx(),
            center = lastPt
        )
        drawCircle(
            color = lineColor,
            radius = 3.dp.toPx(),
            center = lastPt
        )
    }
}

// =========================================================================
// 第二页（Tab 2）：数据统计 —— 方块卡片（Grid Layout）展示 + 自启动推荐卡片 + Bug日志卡片
// =========================================================================

@Composable
private fun StatsGridPage(
    state: PowerMonitorUiState,
    batterySnapshot: BatterySnapshot,
    powerStats: PowerStatsData?,
    overlayRunning: Boolean,
    overlayFps: Int,
    roomRecordCount: Int,
    errorLogCount: Int,
    onToggleOverlay: (Boolean) -> Unit,
    onOpenHistoryList: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenLogs: () -> Unit,
    onOpenAutoStartGuide: () -> Unit,
    onSwitchToProcessTab: () -> Unit
) {
    val dischargePoints = powerStats?.points?.filter { !it.charging && it.powerW > 0.0 }.orEmpty()
    val chargePoints = powerStats?.points?.filter { it.charging && it.powerW > 0.0 }.orEmpty()

    val avgDischargeW = when {
        dischargePoints.isNotEmpty() -> dischargePoints.map { it.powerW }.average()
        state.historyPowerMw.isNotEmpty() -> state.historyPowerMw.map { abs(it) / 1000.0 }.average()
        else -> 0.0
    }
    val avgChargeW = if (chargePoints.isNotEmpty()) chargePoints.map { it.powerW }.average() else 0.0
    val usedTimeText = if ((powerStats?.usedMs ?: 0L) > 0L) {
        formatDurationShort(powerStats?.usedMs ?: 0L)
    } else {
        "0m"
    }
    val expectedText = when {
        (powerStats?.expectedMs ?: 0L) > 0L -> formatExpected(powerStats?.expectedMs ?: 0L)
        avgDischargeW > 0.15 && batterySnapshot.level > 0 -> {
            val estMs = (18.5 * (batterySnapshot.level / 100.0) / avgDischargeW * 3_600_000.0).toLong()
            formatExpected(estMs)
        }
        else -> "--"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PageBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "核心统计与功能（方块网格）",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextSecondary,
            modifier = Modifier.padding(horizontal = 4.dp)
        )

        // 第 1 行方块：放电总结 & 充电总结
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val liveChargeW = if (state.charging && abs(state.powerMw) > 0.0) abs(state.powerMw) / 1000.0 else avgChargeW
            AnimatedGridSquareCard(
                title = "放电总结",
                primaryValue = if (avgDischargeW > 0.0) String.format(Locale.US, "-%.2f W", avgDischargeW) else "暂无数据",
                subtitle = if (state.charging || batterySnapshot.charging) "充电中暂停计入放电功耗" else "亮屏放电时长 $usedTimeText",
                badgeText = "放电 (-)",
                accentColor = PrimaryAccent,
                onClick = onOpenStats,
                modifier = Modifier.weight(1f)
            )
            AnimatedGridSquareCard(
                title = "充电总结",
                primaryValue = if (liveChargeW > 0.0) String.format(Locale.US, "+%.2f W", liveChargeW) else "暂无数据",
                subtitle = if (state.charging || batterySnapshot.charging) "当前正在充电 (+)" else "当前未接电源",
                badgeText = "充电 (+)",
                accentColor = Color(0xFF27AE60),
                onClick = onOpenStats,
                modifier = Modifier.weight(1f)
            )
        }

        // 第 2 行方块：续航预测 & 电池统计曲线
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AnimatedGridSquareCard(
                title = "续航预测",
                primaryValue = expectedText,
                subtitle = String.format(Locale.US, "累计消耗 %.2f Wh", powerStats?.whUsed ?: 0.0),
                badgeText = "${batterySnapshot.level}%",
                accentColor = Color(0xFF8E44AD),
                onClick = onOpenStats,
                modifier = Modifier.weight(1f)
            )
            AnimatedGridSquareCard(
                title = "电池统计曲线",
                primaryValue = "${powerStats?.points?.size ?: 0} 点",
                subtitle = "点击查看 2 小时完整放电曲线",
                badgeText = "详情 ›",
                accentColor = Color(0xFF2980B9),
                onClick = onOpenStats,
                modifier = Modifier.weight(1f)
            )
        }

        // 第 3 行方块：FPS 悬浮窗 & 历史记录列表
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AnimatedGridSquareCard(
                title = "FPS 悬浮窗",
                primaryValue = if (overlayRunning) "$overlayFps FPS" else "已关闭",
                subtitle = if (overlayRunning) "点击关闭悬浮胶囊" else "点击开启 18dp 帧率胶囊",
                badgeText = if (overlayRunning) "ON" else "OFF",
                accentColor = if (overlayRunning) Color(0xFF16A085) else TextSecondary,
                onClick = { onToggleOverlay(!overlayRunning) },
                modifier = Modifier.weight(1f)
            )
            AnimatedGridSquareCard(
                title = "历史记录列表",
                primaryValue = "$roomRecordCount 条",
                subtitle = "点击查看单应用 FPS/温度/功耗曲线",
                badgeText = "Room ›",
                accentColor = Color(0xFFD35400),
                onClick = onOpenHistoryList,
                modifier = Modifier.weight(1f)
            )
        }

        // 第 4 行方块：推荐开启自启动 & 运行/崩溃日志（检测 Bug）
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AnimatedGridSquareCard(
                title = "自启动与保活",
                primaryValue = "推荐开启",
                subtitle = "Root 加入省电白名单并跳转系统自启动管理",
                badgeText = "推荐 ›",
                accentColor = Color(0xFF0F766E),
                onClick = onOpenAutoStartGuide,
                modifier = Modifier.weight(1f)
            )
            AnimatedGridSquareCard(
                title = "运行与Bug日志",
                primaryValue = if (errorLogCount > 0) "$errorLogCount 异常" else "运行正常",
                subtitle = "查看闪退堆栈、抓取系统 Logcat 排查问题",
                badgeText = "诊断 ›",
                accentColor = if (errorLogCount > 0) Color(0xFFE5484D) else Color(0xFF34495E),
                onClick = onOpenLogs,
                modifier = Modifier.weight(1f)
            )
        }

        // 第 5 行方块：后台进程管理快捷入口
        AnimatedGridSquareCard(
            title = "Root 后台进程内存监控与强杀",
            primaryValue = "进程管理",
            subtitle = "解析 dumpsys meminfo 内存占用（MB/%），支持过滤系统应用与长按 am force-stop 强杀",
            badgeText = "进入 ›",
            accentColor = Color(0xFFC0392B),
            onClick = onSwitchToProcessTab,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun AnimatedGridSquareCard(
    title: String,
    primaryValue: String,
    subtitle: String,
    badgeText: String,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1f,
        animationSpec = tween(durationMillis = 140),
        label = "gridCardScale"
    )

    Surface(
        modifier = modifier
            .heightIn(min = 124.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(RoundedCornerShape(20.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = LocalIndication.current,
                onClick = onClick
            ),
        shape = RoundedCornerShape(20.dp),
        color = CardSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Surface(
                    color = accentColor.copy(alpha = 0.12f),
                    shape = CircleShape
                ) {
                    Text(
                        text = badgeText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = accentColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = primaryValue,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = accentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = TextSecondary,
                maxLines = 2,
                lineHeight = 15.sp,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// =========================================================================
// 模块三（Tab 3）：后台进程监控（修复滑动/侧滑手势冲突，支持长按与右侧按钮强杀）
// =========================================================================

@Composable
private fun ProcessManagerPage() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showSystemApps by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var overview by remember {
        mutableStateOf(MemoryOverview(totalRamMb = 0.0, usedRamMb = 0.0, processes = emptyList()))
    }
    var targetKillApp by remember { mutableStateOf<AppProcessMemoryInfo?>(null) }

    fun reloadProcesses(delayBeforeMs: Long = 0L) {
        loading = true
        scope.launch {
            if (delayBeforeMs > 0L) delay(delayBeforeMs)
            val result = withContext(Dispatchers.IO) {
                ProcessManager.queryRunningProcesses(context)
            }
            overview = result
            loading = false
            AppLogManager.i("ProcessManager", "已刷新进程列表：共 ${result.processes.size} 个应用进程")
        }
    }

    LaunchedEffect(Unit) {
        reloadProcesses()
    }

    val filteredProcesses = remember(overview.processes, showSystemApps) {
        if (showSystemApps) {
            overview.processes
        } else {
            overview.processes.filter { !it.isSystemApp }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(PageBackground)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = CardSurface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "后台进程内存监控 (dumpsys meminfo)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            val ramText = if (overview.totalRamMb > 0.0) {
                                String.format(
                                    Locale.US,
                                    "已用 %.0f MB / 总计 %.0f MB · 共 %d 个应用",
                                    overview.usedRamMb,
                                    overview.totalRamMb,
                                    filteredProcesses.size
                                )
                            } else {
                                "正在通过 Root 解析内存占用…"
                            }
                            Text(
                                text = ramText,
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                        TextButton(
                            onClick = { reloadProcesses() },
                            enabled = !loading
                        ) {
                            Text(if (loading) "刷新中…" else "刷新")
                        }
                    }

                    HorizontalDivider(thickness = 0.8.dp, color = DividerLight)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showSystemApps = !showSystemApps },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "显示系统应用",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextPrimary
                            )
                            Text(
                                text = "长按卡片或点击右侧按钮可执行 Root 强制停止 (am force-stop)",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                        Switch(
                            checked = showSystemApps,
                            onCheckedChange = { showSystemApps = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = PrimaryAccent
                            )
                        )
                    }
                }
            }

            if (loading && filteredProcesses.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "正在执行 su -c \"dumpsys meminfo\" 解析进程…",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                }
            } else if (filteredProcesses.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (showSystemApps) "未读取到后台进程" else "当前无第三方后台进程（可开启“显示系统应用”查看）",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 20.dp)
                ) {
                    items(
                        items = filteredProcesses,
                        key = { it.packageName }
                    ) { proc ->
                        // 使用稳定的 pointerInput(detectTapGestures) 避免与 HorizontalPager 侧滑手势发生冲突崩溃
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .pointerInput(proc.packageName) {
                                    detectTapGestures(
                                        onTap = {
                                            targetKillApp = proc
                                        },
                                        onLongPress = {
                                            targetKillApp = proc
                                        }
                                    )
                                },
                            shape = RoundedCornerShape(16.dp),
                            color = CardSurface
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AppIcon(packageName = proc.packageName, size = 40.dp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = proc.appName,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = TextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        if (proc.isSystemApp) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                color = Color(0xFFEDEEF2),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = "系统",
                                                    fontSize = 9.sp,
                                                    color = TextSecondary,
                                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${proc.packageName} · ${proc.pidCount} 个进程",
                                        fontSize = 11.sp,
                                        color = TextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = String.format(Locale.US, "%.1f MB", proc.memoryMb),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryAccent
                                    )
                                    Text(
                                        text = String.format(Locale.US, "占比 %.2f%%", proc.memoryPercent),
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        targetKillApp?.let { appToKill ->
            AppModalDialog(
                title = "强制停止应用",
                onDismiss = { targetKillApp = null },
                confirmText = "确定",
                confirmColor = Color(0xFFE5484D),
                onConfirm = {
                    val pkg = appToKill.packageName
                    val name = appToKill.appName
                    targetKillApp = null
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) {
                            ProcessManager.forceStopPackage(pkg)
                        }
                        if (ok) {
                            AppLogManager.i("ForceStop", "已通过 Root 强杀应用: $name ($pkg)")
                        } else {
                            AppLogManager.w("ForceStop", "强杀应用失败: $name ($pkg)")
                        }
                        Toast.makeText(
                            context,
                            if (ok) "已强制停止：$name" else "强制停止命令执行失败",
                            Toast.LENGTH_SHORT
                        ).show()
                        reloadProcesses(delayBeforeMs = 250L)
                    }
                },
                dismissText = "取消",
                onDismissButton = { targetKillApp = null }
            ) {
                Text(
                    text = "是否强制停止当前应用？\n\n应用：${appToKill.appName}\n包名：${appToKill.packageName}",
                    fontSize = 14.sp,
                    color = TextPrimary,
                    lineHeight = 20.sp
                )
            }
        }
    }
}

// =========================================================================
// 新增模块：运行与崩溃日志诊断中心（支持检测 Bug、查看 Crash 堆栈、抓取系统 Logcat、一键复制）
// =========================================================================

@Composable
private fun AppLogScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val allLogs by AppLogManager.logs.collectAsState()

    var filterErrorOnly by remember { mutableStateOf(false) }
    var logcatSnapshot by remember { mutableStateOf<String?>(null) }
    var capturingLogcat by remember { mutableStateOf(false) }

    val displayedLogs = remember(allLogs, filterErrorOnly) {
        val source = if (filterErrorOnly) {
            allLogs.filter { it.level == "ERROR" || it.level == "CRASH" || it.level == "WARN" }
        } else {
            allLogs
        }
        source.asReversed()
    }

    val sdf = remember { SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(PageBackground)
        ) {
            // 顶部导航栏
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = CardSurface,
                shadowElevation = 1.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 6.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        BackGlyph(iconSize = 23.dp, tint = TextPrimary)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "运行与Bug诊断日志",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "自动捕获 Crash 堆栈 · 共 ${allLogs.size} 条记录",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                    TextButton(
                        onClick = {
                            val text = AppLogManager.exportAllText(context)
                            clipboard.setText(AnnotatedString(text))
                            Toast.makeText(context, "全部诊断日志已复制到剪贴板", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Text("复制全部", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    TextButton(
                        onClick = {
                            AppLogManager.clearLogs(context)
                            Toast.makeText(context, "日志已清空", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Text("清空", fontSize = 13.sp, color = Color(0xFFE5484D))
                    }
                }
            }

            // 工具操作栏：仅看异常过滤 + 抓取系统 Logcat
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                shape = RoundedCornerShape(16.dp),
                color = CardSurface
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { filterErrorOnly = !filterErrorOnly },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = filterErrorOnly,
                                onCheckedChange = { filterErrorOnly = it }
                            )
                            Text(
                                text = "仅显示警告与崩溃异常 (WARN / ERROR / CRASH)",
                                fontSize = 13.sp,
                                color = TextPrimary
                            )
                        }
                        FilledTonalButton(
                            onClick = {
                                if (capturingLogcat) return@FilledTonalButton
                                capturingLogcat = true
                                scope.launch {
                                    val out = withContext(Dispatchers.IO) {
                                        AppLogManager.captureSystemLogcat()
                                    }
                                    capturingLogcat = false
                                    logcatSnapshot = out
                                }
                            },
                            shape = CircleShape,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (capturingLogcat) "抓取中…" else "抓取系统Logcat",
                                fontSize = 12.sp
                            )
                        }
                    }
                    Text(
                        text = "日志文件：${AppLogManager.logFilePath(context)}",
                        fontSize = 10.sp,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (displayedLogs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (filterErrorOnly) "当前没有任何警告或崩溃异常记录" else "暂无日志记录",
                        fontSize = 14.sp,
                        color = TextSecondary
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(displayedLogs) { entry ->
                        val levelColor = when (entry.level) {
                            "CRASH", "ERROR" -> Color(0xFFE5484D)
                            "WARN" -> Color(0xFFE67E22)
                            else -> PrimaryAccent
                        }
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    clipboard.setText(AnnotatedString("[${entry.level}] [${entry.tag}] ${entry.message}"))
                                    Toast.makeText(context, "已复制该条日志", Toast.LENGTH_SHORT).show()
                                },
                            shape = RoundedCornerShape(14.dp),
                            color = CardSurface
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = levelColor.copy(alpha = 0.14f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = entry.level,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = levelColor,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = entry.tag,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = sdf.format(Date(entry.time)),
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                }
                                Text(
                                    text = entry.message,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextPrimary,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        logcatSnapshot?.let { snapshotText ->
            AppModalDialog(
                title = "系统 Crash & 进程 Logcat",
                onDismiss = { logcatSnapshot = null },
                confirmText = "复制 Logcat",
                onConfirm = {
                    clipboard.setText(AnnotatedString(snapshotText))
                    Toast.makeText(context, "Logcat 已复制到剪贴板", Toast.LENGTH_SHORT).show()
                    logcatSnapshot = null
                },
                dismissText = "关闭",
                onDismissButton = { logcatSnapshot = null }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 160.dp, max = 380.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = snapshotText,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = TextPrimary,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusPill(running: Boolean) {
    val background = if (running) Color(0xFFE3ECFA) else Color(0xFFF0F2F6)
    val foreground = if (running) PrimaryAccent else TextSecondary
    Surface(
        color = background,
        shape = CircleShape
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(if (running) PrimaryAccent else Color(0xFF9CA1AC))
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = if (running) "自动记录中" else "后台已停",
                color = foreground,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun BugLogGlyph(iconSize: androidx.compose.ui.unit.Dp, tint: Color) {
    Canvas(modifier = Modifier.size(iconSize)) {
        val stroke = Stroke(width = 1.7.dp.toPx(), cap = StrokeCap.Round)
        drawRoundRect(
            color = tint,
            topLeft = Offset(size.width * 0.28f, size.height * 0.28f),
            size = androidx.compose.ui.geometry.Size(size.width * 0.44f, size.height * 0.50f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.width * 0.22f),
            style = stroke
        )
        drawLine(
            color = tint,
            start = Offset(size.width * 0.14f, size.height * 0.42f),
            end = Offset(size.width * 0.28f, size.height * 0.42f),
            strokeWidth = 1.6.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(size.width * 0.72f, size.height * 0.42f),
            end = Offset(size.width * 0.86f, size.height * 0.42f),
            strokeWidth = 1.6.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(size.width * 0.14f, size.height * 0.60f),
            end = Offset(size.width * 0.28f, size.height * 0.60f),
            strokeWidth = 1.6.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(size.width * 0.72f, size.height * 0.60f),
            end = Offset(size.width * 0.86f, size.height * 0.60f),
            strokeWidth = 1.6.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun SettingsGlyph(iconSize: androidx.compose.ui.unit.Dp, tint: Color) {
    Canvas(modifier = Modifier.size(iconSize)) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val outerR = size.width * 0.34f
        val innerR = size.width * 0.15f
        drawCircle(
            color = tint,
            radius = outerR,
            center = center,
            style = Stroke(width = 1.8.dp.toPx())
        )
        drawCircle(
            color = tint,
            radius = innerR,
            center = center,
            style = Stroke(width = 1.6.dp.toPx())
        )
    }
}

@Composable
private fun MoreVertGlyph(iconSize: androidx.compose.ui.unit.Dp, tint: Color) {
    Canvas(modifier = Modifier.size(iconSize)) {
        val r = 1.6.dp.toPx()
        val cx = size.width / 2f
        drawCircle(color = tint, radius = r, center = Offset(cx, size.height * 0.25f))
        drawCircle(color = tint, radius = r, center = Offset(cx, size.height * 0.50f))
        drawCircle(color = tint, radius = r, center = Offset(cx, size.height * 0.75f))
    }
}

private fun formatCurrent(currentMa: Double): String {
    val text = String.format(Locale.US, "%.1f", kotlin.math.abs(currentMa))
    return if (currentMa < 0.0) "−$text" else "+$text"
}
