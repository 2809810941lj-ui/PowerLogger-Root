package com.example.powerlogger

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/** 主界面用来显示悬浮窗开关和当前 FPS。 */
object OverlayState {
    private val mutableRunning = MutableStateFlow(false)
    val running: StateFlow<Boolean> = mutableRunning.asStateFlow()

    private val mutableFps = MutableStateFlow(0)
    val fps: StateFlow<Int> = mutableFps.asStateFlow()

    fun updateRunning(value: Boolean) {
        mutableRunning.value = value
    }

    fun updateFps(value: Int) {
        mutableFps.value = value
    }
}

/**
 * Scene 风格 FPS 悬浮窗服务：
 * 1. 小尺寸半透明胶囊，显示当前前台应用的实时 FPS；
 * 2. 单击开始/结束记录当前前台应用的 FPS、温度、功耗、CPU、GPU 曲线；
 * 3. 记录期间通过 Root 监听前台包名，一旦切出当前应用：
 *    【仅自动停止记录并写入数据库，恢复胶囊待机状态，不关闭 FPS 悬浮窗】；
 * 4. 只有用户在主界面关闭悬浮窗开关或在通知栏点击“关闭悬浮窗”时，才关闭悬浮窗。
 */
class FloatingFpsService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var powerManager: PowerManager
    private lateinit var workerThread: HandlerThread
    private lateinit var worker: Handler
    private lateinit var mainHandler: Handler

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var packageWatchJob: Job? = null

    private var ringView: OverlayRingView? = null
    private var params: WindowManager.LayoutParams? = null
    private var sampler: SceneSampler? = null

    @Volatile
    private var recording = false

    @Volatile
    private var stoppingRecording = false

    @Volatile
    private var session: AppSession? = null

    @Volatile
    private var lastFps = 0

    private var notificationCounter = 0
    private var monitoring = false

    @Volatile
    private var rootLeaseHeld = false

    @Volatile
    private var destroyed = false

    private var downParamsX = 0
    private var downParamsY = 0
    private var downRawX = 0f
    private var downRawY = 0f
    private var dragging = false

    private val density: Float
        get() = resources.displayMetrics.density

    private val overlayHeight: Int
        get() = (18 * density).roundToInt()

    private val sampleRunnable = object : Runnable {
        override fun run() {
            if (destroyed) return
            if (!powerManager.isInteractive) {
                if (recording) {
                    // 息屏时也只停止录制，保留悬浮窗
                    stopRecording(openDetail = false, auto = true)
                }
                if (!destroyed) worker.postDelayed(this, IDLE_SCREEN_OFF_INTERVAL_MS)
                return
            }

            try {
                doSample()
            } catch (error: Throwable) {
                Log.w(TAG, "采样失败", error)
            }
            val nextInterval = if (recording) RECORDING_SAMPLE_INTERVAL_MS else STANDBY_SAMPLE_INTERVAL_MS
            if (!destroyed) worker.postDelayed(this, nextInterval)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        mainHandler = Handler(Looper.getMainLooper())
        workerThread = HandlerThread("PowerLogger-FPS").apply { start() }
        worker = Handler(workerThread.looper)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (!enterForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("请先授予“显示在其他应用上层”权限")
            stopSelf()
            return START_NOT_STICKY
        }

        startMonitoring()
        return START_NOT_STICKY
    }

    private fun enterForeground(): Boolean {
        return try {
            val notification = buildNotification(0)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        } catch (error: Throwable) {
            Log.e(TAG, "startForeground 失败", error)
            false
        }
    }

    private fun startMonitoring() {
        if (monitoring) return
        monitoring = true
        sampler = SceneSampler(this)

        worker.post {
            if (!RootShell.acquire()) {
                mainHandler.post {
                    toast("Root 未授权，无法读取 FPS / CPU / GPU")
                    stopSelf()
                }
                return@post
            }
            rootLeaseHeld = true
            mainHandler.post {
                if (!destroyed) {
                    OverlayState.updateRunning(true)
                    addOverlay()
                }
            }
            worker.post(sampleRunnable)
        }
    }

    private fun addOverlay() {
        if (ringView != null) return
        val height = overlayHeight
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val view = OverlayRingView(this).apply {
            fpsValue = lastFps
            recording = this@FloatingFpsService.recording
            measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY)
            )
        }
        val measuredWidth = view.measuredWidth.coerceAtLeast(height)
        val preferences = getSharedPreferences(PREFS, MODE_PRIVATE)
        val defaultX = max(0, screenWidth - measuredWidth - (16 * density).toInt())
        val defaultY = max(0, screenHeight / 3)

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = preferences.getInt(KEY_X, defaultX).coerceIn(0, max(0, screenWidth - measuredWidth))
            y = preferences.getInt(KEY_Y, defaultY).coerceIn(0, max(0, screenHeight - height))
        }

        view.setOnTouchListener { touchedView, event ->
            val activeParams = params ?: return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downParamsX = activeParams.x
                    downParamsY = activeParams.y
                    downRawX = event.rawX
                    downRawY = event.rawY
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (!dragging && (abs(dx) > 6 * density || abs(dy) > 6 * density)) {
                        dragging = true
                    }
                    if (dragging) {
                        val currentWidth = max(touchedView.width, touchedView.measuredWidth).coerceAtLeast(height)
                        activeParams.x = (downParamsX + dx).coerceIn(0, max(0, screenWidth - currentWidth))
                        activeParams.y = (downParamsY + dy).coerceIn(0, max(0, screenHeight - height))
                        try {
                            windowManager.updateViewLayout(touchedView, activeParams)
                        } catch (_: Throwable) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!dragging) {
                        onRingTap()
                    }
                    saveOverlayPosition()
                    true
                }
                else -> false
            }
        }

        try {
            windowManager.addView(view, layoutParams)
            ringView = view
            params = layoutParams
        } catch (error: Throwable) {
            Log.e(TAG, "添加悬浮窗失败", error)
            toast("悬浮窗添加失败：${error.message ?: "未知错误"}")
            stopSelf()
        }
    }

    private fun clampOverlayPosition() {
        val view = ringView ?: return
        val activeParams = params ?: return
        view.post {
            if (destroyed || ringView !== view) return@post
            val screenWidth = resources.displayMetrics.widthPixels
            val screenHeight = resources.displayMetrics.heightPixels
            val maxX = max(0, screenWidth - view.width)
            val maxY = max(0, screenHeight - view.height)
            val nextX = activeParams.x.coerceIn(0, maxX)
            val nextY = activeParams.y.coerceIn(0, maxY)
            if (nextX != activeParams.x || nextY != activeParams.y) {
                activeParams.x = nextX
                activeParams.y = nextY
                try {
                    windowManager.updateViewLayout(view, activeParams)
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun removeOverlay() {
        val view = ringView ?: return
        try {
            windowManager.removeView(view)
        } catch (_: Throwable) {
        }
        ringView = null
        params = null
    }

    private fun saveOverlayPosition() {
        val activeParams = params ?: return
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putInt(KEY_X, activeParams.x)
            .putInt(KEY_Y, activeParams.y)
            .apply()
    }

    private fun onRingTap() {
        if (recording) {
            stopRecording(openDetail = true, auto = false)
        } else {
            startRecording()
        }
    }

    private fun startRecording() {
        worker.post {
            if (recording || stoppingRecording) return@post
            val foreground = queryForegroundFast() ?: sampler?.foregroundNow()
            val targetPackage = foreground?.packageName.orEmpty()
            if (targetPackage.isEmpty()) {
                toast("无法获取前台应用，请确认 Root 已授权")
                return@post
            }
            val label = resolveLabel(targetPackage)
            val now = System.currentTimeMillis()
            val created = AppSession(
                id = now,
                packageName = targetPackage,
                label = label,
                activity = foreground?.activity.orEmpty(),
                startTime = now,
                endTime = 0L,
                model = Build.MODEL ?: "",
                soc = socName(),
                os = "Android ${Build.VERSION.RELEASE}"
            )
            session = created
            recording = true
            notificationCounter = 0
            sampler?.resetLayerCache()

            startForegroundPackageWatch(targetPackage)

            mainHandler.post {
                ringView?.recording = true
                toast("开始记录帧率：$label")
                updateNotification(lastFps)
            }
        }
    }

    /**
     * 在 IO 协程中通过 Root 监听前台包名变化：
     * 一旦检测到退出被记录的应用（切到桌面或其他应用），
     * 【只退出记录功能并保存数据，恢复悬浮窗待机颜色，绝不关闭 FPS 悬浮窗】！
     */
    private fun startForegroundPackageWatch(targetPackage: String) {
        packageWatchJob?.cancel()
        packageWatchJob = serviceScope.launch(Dispatchers.IO) {
            while (isActive && recording && !destroyed) {
                delay(PACKAGE_WATCH_INTERVAL_MS)
                if (!recording || destroyed) break

                val current = queryForegroundFast()
                val currentPkg = current?.packageName.orEmpty()
                if (currentPkg.isNotEmpty() && currentPkg != targetPackage) {
                    Log.i(TAG, "检测到切出应用: $targetPackage -> $currentPkg，仅停止帧率记录，保留悬浮窗")
                    stopRecording(openDetail = false, auto = true)
                    break
                }
            }
        }
    }

    private fun queryForegroundFast(): ForegroundApp? {
        val output = RootShell.exec(
            "dumpsys window displays 2>/dev/null | grep -E 'mCurrentFocus|mFocusedApp'; " +
                "dumpsys activity activities 2>/dev/null | grep -E 'topResumedActivity|mResumedActivity' | head -6",
            4_000L
        ).orEmpty()
        return parseDumpsysWindowForeground(output)
    }

    private fun parseDumpsysWindowForeground(rawOutput: String): ForegroundApp? {
        if (rawOutput.isBlank()) return null
        val lines = rawOutput.lineSequence().map { it.trim() }.filter { it.isNotEmpty() && !it.contains("=null") }.toList()
        val componentRegex = Regex("([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+)+)/([A-Za-z0-9_.$]+)")
        for (line in lines) {
            val match = componentRegex.find(line) ?: continue
            val pkg = match.groupValues[1]
            val act = match.groupValues[2]
            if (pkg != "com.android.systemui" && pkg != "android") {
                return ForegroundApp(pkg, act)
            }
        }
        return null
    }

    /**
     * 停止当前帧率记录并保存到 Room 数据库（历史记录列表），同时同步一份到 SessionStore，
     * 保持 FPS 悬浮窗继续在屏幕上显示待机实时帧率！
     */
    private fun stopRecording(
        openDetail: Boolean,
        auto: Boolean
    ) {
        // 修复 P1-18：统一投递到采样所在的单线程 worker 中执行停止与深拷贝快照，杜绝与 doSample() 并发访问 samples 列表
        worker.post {
            if (!recording || stoppingRecording) return@post
            stoppingRecording = true
            recording = false
            packageWatchJob?.cancel()
            packageWatchJob = null

            val rawSession = session
            session = null
            val finished = rawSession?.apply {
                endTime = System.currentTimeMillis()
            }?.snapshotCopy()

            serviceScope.launch(Dispatchers.IO) {
            var savedRecordId: Long? = null
            val hasData = finished != null && finished.samples.isNotEmpty()

            if (hasData && finished != null) {
                withContext(NonCancellable) {
                    try {
                        val entity = SessionRecordEntity.fromAppSession(finished)
                        val rowId = AppDatabase.getInstance(applicationContext)
                            .sessionRecordDao()
                            .insert(entity)
                        savedRecordId = if (rowId > 0L) rowId else finished.id
                        SessionStore.save(applicationContext, finished.copy(id = savedRecordId ?: finished.id))
                        AppLogManager.i("FpsRecord", "帧率记录已保存: ${finished.label} (${finished.samples.size} 个采样点)")
                    } catch (error: Throwable) {
                        Log.e(TAG, "保存记录到 Room 数据库失败", error)
                        SessionStore.save(applicationContext, finished)
                        savedRecordId = finished.id
                    }
                }
            }

            withContext(Dispatchers.Main) {
                stoppingRecording = false
                // 仅将悬浮窗胶囊从红色录制态恢复为待机态，不移除悬浮窗、不停止服务！
                ringView?.recording = false
                updateNotification(lastFps)

                val message = when {
                    auto && hasData -> "已切出应用，帧率记录已自动停止并保存"
                    auto -> "已切出应用，帧率记录已停止"
                    hasData -> "帧率记录已保存"
                    else -> "记录时间太短，未保存"
                }
                toast(message)

                val targetId = savedRecordId
                if (openDetail && hasData && targetId != null) {
                    val intent = Intent(this@FloatingFpsService, MainActivity::class.java)
                        .putExtra(MainActivity.EXTRA_SESSION_ID, targetId)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    try {
                        startActivity(intent)
                    } catch (_: Throwable) {
                    }
                }
            }
        }
        }
    }

    private fun doSample() {
        val collectDetails = recording
        val sample = try {
            sampler?.sample(collectDetails)
        } catch (error: Throwable) {
            Log.w(TAG, "sample 异常", error)
            null
        }
        if (sample == null) {
            lastFps = 0
            OverlayState.updateFps(0)
            mainHandler.post {
                ringView?.fpsValue = 0
                clampOverlayPosition()
            }
            return
        }

        lastFps = sample.fps.roundToInt().coerceIn(0, 480)
        OverlayState.updateFps(lastFps)
        mainHandler.post {
            ringView?.fpsValue = lastFps
            clampOverlayPosition()
        }

        if (sample.capacity > 0) {
            BatteryHistory.append(
                this,
                BatteryPoint(
                    time = sample.time,
                    level = sample.capacity,
                    powerW = sample.powerW,
                    tempC = sample.batteryTemp,
                    voltageMv = sample.voltageMv,
                    screenOn = powerManager.isInteractive,
                    charging = sample.charging
                )
            )
        }

        val active = session
        if (!collectDetails || active == null) return

        active.samples.add(sample)
        if (active.samples.size > MAX_SAMPLES) {
            stopRecording(openDetail = false, auto = true)
            return
        }

        val foreground = sampler?.currentForeground()
        val away = foreground != null &&
            foreground.packageName.isNotEmpty() &&
            foreground.packageName != active.packageName
        if (away) {
            stopRecording(openDetail = false, auto = true)
            return
        }

        if (notificationCounter++ % 2 == 0) {
            updateNotification(lastFps)
        }
    }

    private fun resolveLabel(packageName: String): String {
        return try {
            val info = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (_: Throwable) {
            packageName
        }
    }

    private fun socName(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Build.SOC_MODEL ?: Build.HARDWARE
        } else {
            Build.HARDWARE
        }
    }

    private fun toast(message: String) {
        mainHandler.post {
            Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "FPS 悬浮窗",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "在前台显示 FPS 胶囊并记录场景数据"
                setShowBadge(false)
            }
            notificationManager().createNotificationChannel(channel)
        }
    }

    private fun updateNotification(fps: Int): Notification {
        val notification = buildNotification(fps)
        try {
            notificationManager().notify(NOTIFICATION_ID, notification)
        } catch (_: Throwable) {
        }
        return notification
    }

    private fun buildNotification(fps: Int): Notification {
        val text = when {
            recording -> "正在记录 ${session?.label ?: "当前应用"} · FPS $fps（切出应用将自动停止记录）"
            fps > 0 -> "FPS $fps · 点击悬浮窗开始记录"
            else -> "点击悬浮窗开始记录当前应用"
        }

        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this,
            REQUEST_OPEN,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, FloatingFpsService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this,
            REQUEST_STOP,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("PowerLogger FPS 悬浮窗")
            .setContentText(text)
            .setContentIntent(openPending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_media_pause, "关闭悬浮窗", stopPending)
            .build()
    }

    private fun notificationManager(): NotificationManager =
        getSystemService(NOTIFICATION_SERVICE) as NotificationManager

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        sampler?.resetLayerCache()
    }

    override fun onDestroy() {
        destroyed = true
        packageWatchJob?.cancel()
        packageWatchJob = null
        worker.removeCallbacks(sampleRunnable)

        if (recording) {
            recording = false
            val active = session
            session = null
            if (active != null && active.samples.isNotEmpty()) {
                active.endTime = System.currentTimeMillis()
                val appContext = applicationContext
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val entity = SessionRecordEntity.fromAppSession(active)
                        val rowId = AppDatabase.getInstance(appContext).sessionRecordDao().insert(entity)
                        val savedId = if (rowId > 0L) rowId else active.id
                        SessionStore.save(appContext, active.copy(id = savedId))
                    } catch (_: Throwable) {
                        SessionStore.save(appContext, active)
                    }
                }
            }
        }

        serviceScope.cancel()
        BatteryHistory.flush()
        removeOverlay()
        if (rootLeaseHeld) {
            rootLeaseHeld = false
            RootShell.release()
        }
        OverlayState.updateRunning(false)
        OverlayState.updateFps(0)
        try {
            workerThread.quitSafely()
        } catch (_: Throwable) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.example.powerlogger.action.FPS_START"
        const val ACTION_STOP = "com.example.powerlogger.action.FPS_STOP"

        private const val TAG = "PowerLogger-FPS"
        private const val CHANNEL_ID = "power_logger_fps_overlay"
        private const val NOTIFICATION_ID = 2411
        private const val REQUEST_OPEN = 2412
        private const val REQUEST_STOP = 2413
        private const val PREFS = "fps_overlay"
        private const val KEY_X = "x"
        private const val KEY_Y = "y"
        private const val RECORDING_SAMPLE_INTERVAL_MS = 800L
        private const val STANDBY_SAMPLE_INTERVAL_MS = 850L
        private const val IDLE_SCREEN_OFF_INTERVAL_MS = 5_000L
        private const val PACKAGE_WATCH_INTERVAL_MS = 600L
        private const val MAX_SAMPLES = 7200
    }
}
