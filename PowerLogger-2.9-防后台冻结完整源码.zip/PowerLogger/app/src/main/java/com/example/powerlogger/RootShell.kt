package com.example.powerlogger

import android.util.Log
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.UUID
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Shared, serialized su shell for read-only telemetry commands.
 *
 * A lease is held while either monitoring service is active. When no service owns
 * a lease, one-off diagnostic commands use a temporary shell that is closed on
 * completion. Commands are never injected into game processes and this class
 * does not modify application data or system properties.
 */
object RootShell {
    private const val TAG = "PowerLogger-Root"
    private const val END_PREFIX = "__POWERLOGGER_END_"
    private const val EOF_MARKER = "__POWERLOGGER_EOF__"
    private const val DEFAULT_TIMEOUT_MS = 15_000L
    private const val ROOT_CHECK_TIMEOUT_MS = 10_000L

    private val lock = Any()
    private var process: Process? = null
    private var writer: BufferedWriter? = null
    private var lineQueue: LinkedBlockingQueue<String>? = null
    private var readerThread: Thread? = null
    private var leases: Int = 0

    /** Acquire a long-lived root-shell lease for a foreground monitoring service. */
    fun acquire(): Boolean = synchronized(lock) {
        leases++
        val identity = executeLocked("id", ROOT_CHECK_TIMEOUT_MS)
        val isRoot = identity?.contains("uid=0") == true
        if (!isRoot) {
            leases = (leases - 1).coerceAtLeast(0)
            if (leases == 0) closeProcessLocked()
        }
        isRoot
    }

    /** Release only the caller's lease; another active service may still own one. */
    fun release() = synchronized(lock) {
        if (leases > 0) leases--
        if (leases == 0) closeProcessLocked()
    }

    /** One-shot Root check. If no service is active, the shell is temporary. */
    fun isRootAvailable(): Boolean {
        val result = exec("id", ROOT_CHECK_TIMEOUT_MS)
        return result?.contains("uid=0") == true
    }

    /** Execute a read-only shell command and return merged stdout/stderr. */
    fun exec(command: String, timeoutMs: Long = DEFAULT_TIMEOUT_MS): String? = synchronized(lock) {
        val temporary = leases == 0
        try {
            executeLocked(command, timeoutMs)
        } finally {
            if (temporary && leases == 0) closeProcessLocked()
        }
    }

    private fun executeLocked(command: String, timeoutMs: Long): String? {
        if (command.isBlank()) return ""
        if (!ensureProcessLocked()) return null

        val marker = END_PREFIX + UUID.randomUUID().toString().replace("-", "") + "__"
        val output = writer ?: return null
        val queue = lineQueue ?: return null
        val result = StringBuilder()

        return try {
            output.write(command)
            if (!command.endsWith("\n")) output.newLine()
            output.write("echo $marker")
            output.newLine()
            output.flush()

            val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMs)
            while (true) {
                val remaining = deadline - System.nanoTime()
                if (remaining <= 0L) throw java.util.concurrent.TimeoutException("su command timeout")
                val line = queue.poll(remaining, TimeUnit.NANOSECONDS)
                    ?: throw java.util.concurrent.TimeoutException("su command timeout")
                if (line == marker) break
                if (line == EOF_MARKER) throw IllegalStateException("su shell terminated")
                result.append(line).append('\n')
            }
            result.toString()
        } catch (error: Exception) {
            Log.w(TAG, "Root 命令执行失败", error)
            closeProcessLocked()
            null
        }
    }

    private fun ensureProcessLocked(): Boolean {
        val current = process
        if (current != null && current.isAlive && writer != null && lineQueue != null) return true
        closeProcessLocked()
        return try {
            val started = ProcessBuilder("su").redirectErrorStream(true).start()
            val queue = LinkedBlockingQueue<String>()
            val reader = BufferedReader(InputStreamReader(started.inputStream, Charsets.UTF_8))
            process = started
            writer = BufferedWriter(OutputStreamWriter(started.outputStream, Charsets.UTF_8))
            lineQueue = queue

            val thread = Thread({
                try {
                    while (true) {
                        val line = reader.readLine() ?: break
                        queue.offer(line)
                    }
                } catch (_: Exception) {
                    // Process destruction is expected when the last lease is released.
                } finally {
                    queue.offer(EOF_MARKER)
                    try { reader.close() } catch (_: Exception) { }
                }
            }, "PowerLogger-su-reader").apply {
                isDaemon = true
                start()
            }
            readerThread = thread
            true
        } catch (error: Exception) {
            Log.w(TAG, "无法启动 su shell", error)
            closeProcessLocked()
            false
        }
    }

    private fun closeProcessLocked() {
        try { writer?.flush() } catch (_: Exception) { }
        try { writer?.close() } catch (_: Exception) { }
        writer = null
        lineQueue?.offer(EOF_MARKER)
        lineQueue = null

        val old = process
        process = null
        if (old != null) {
            try {
                old.destroy()
                if (!old.waitFor(250L, TimeUnit.MILLISECONDS)) old.destroyForcibly()
            } catch (_: Exception) {
                try { old.destroyForcibly() } catch (_: Exception) { }
            }
        }
        readerThread = null
    }
}
