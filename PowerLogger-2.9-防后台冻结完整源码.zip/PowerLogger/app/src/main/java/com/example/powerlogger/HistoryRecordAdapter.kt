package com.example.powerlogger

import android.graphics.drawable.Drawable
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

/**
 * 历史记录列表 RecyclerView 适配器。
 */
class HistoryRecordAdapter(
    private val onItemClick: (SessionRecordEntity) -> Unit,
    private val onItemLongClick: (SessionRecordEntity) -> Unit
) : ListAdapter<SessionRecordEntity, HistoryRecordAdapter.RecordViewHolder>(DiffCallback) {

    private val iconCache = LruCache<String, Drawable>(40)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecordViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_history_record, parent, false)
        return RecordViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecordViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class RecordViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivAppIcon: ImageView = itemView.findViewById(R.id.ivAppIcon)
        private val tvAppName: TextView = itemView.findViewById(R.id.tvAppName)
        private val tvDuration: TextView = itemView.findViewById(R.id.tvDuration)
        private val tvPackageName: TextView = itemView.findViewById(R.id.tvPackageName)
        private val tvRecordTime: TextView = itemView.findViewById(R.id.tvRecordTime)
        private val tvAvgFps: TextView = itemView.findViewById(R.id.tvAvgFps)
        private val tvMinMaxFps: TextView = itemView.findViewById(R.id.tvMinMaxFps)
        private val tvTemp: TextView = itemView.findViewById(R.id.tvTemp)
        private val tvPower: TextView = itemView.findViewById(R.id.tvPower)

        fun bind(record: SessionRecordEntity) {
            val context = itemView.context
            tvAppName.text = record.appName.ifBlank { record.packageName }
            tvPackageName.text = record.packageName
            tvDuration.text = formatDurationShort(record.durationMs)
            tvRecordTime.text = formatDateTime(record.startTime)

            tvAvgFps.text = String.format(Locale.US, "%.1f", record.avgFps)
            tvMinMaxFps.text = String.format(
                Locale.US,
                "%.0f / %.0f",
                record.maxFps,
                record.minFps
            )
            tvTemp.text = if (record.maxTemp > 0.0) {
                String.format(Locale.US, "%.1f°C", record.maxTemp)
            } else {
                "--"
            }
            tvPower.text = String.format(Locale.US, "%.2fW", record.avgPowerW)

            val cachedIcon = iconCache.get(record.packageName)
            if (cachedIcon != null) {
                ivAppIcon.setImageDrawable(cachedIcon)
            } else {
                val loaded = try {
                    context.packageManager.getApplicationIcon(record.packageName)
                } catch (_: Exception) {
                    null
                }
                if (loaded != null) {
                    iconCache.put(record.packageName, loaded)
                    ivAppIcon.setImageDrawable(loaded)
                } else {
                    ivAppIcon.setImageResource(android.R.drawable.sym_def_app_icon)
                }
            }

            itemView.setOnClickListener {
                onItemClick(record)
            }
            itemView.setOnLongClickListener {
                onItemLongClick(record)
                true
            }
        }
    }

    private object DiffCallback : DiffUtil.ItemCallback<SessionRecordEntity>() {
        override fun areItemsTheSame(
            oldItem: SessionRecordEntity,
            newItem: SessionRecordEntity
        ): Boolean = oldItem.id == newItem.id

        override fun areContentsTheSame(
            oldItem: SessionRecordEntity,
            newItem: SessionRecordEntity
        ): Boolean = oldItem == newItem
    }
}
