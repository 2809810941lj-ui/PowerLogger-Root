package com.example.powerlogger

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * 单个后台应用进程的内存占用信息。
 */
data class AppProcessMemoryInfo(
    val packageName: String,
    val appName: String,
    val memoryMb: Double,
    val memoryPercent: Double,
    val pidCount: Int,
    val isSystemApp: Boolean
)

/**
 * 内存快照汇总。
 */
data class MemoryOverview(
    val totalRamMb: Double,
    val usedRamMb: Double,
    val processes: List<AppProcessMemoryInfo>
)

/**
 * 模块三：通过 Root 权限执行 dumpsys meminfo 解析后台进程实际内存占用，
 * 并支持通过 am force-stop 强制停止目标应用。
 */
object ProcessManager {

    private val processLineRegex = Regex(
        "^\\s*([0-9,]+)\\s*[kK][bB]?:\\s*([A-Za-z0-9_.:-]+)\\s*\\(pid\\s+\\d+"
    )
    private val totalRamRegex = Regex(
        "Total RAM:\\s*([0-9,]+)\\s*[kK]"
    )
    private val freeRamRegex = Regex(
        "Free RAM:\\s*([0-9,]+)\\s*[kK]"
    )

    /**
     * 安全检测设备是否已获得 Root 权限（捕获所有 Throwable 防止异常闪退）。
     */
    fun checkRootAccess(): Boolean {
        return try {
            if (RootShell.isRootAvailable()) {
                return true
            }
            val output = execStandaloneSu("id", 6_000L)
            output?.contains("uid=0") == true
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * 执行 su -c "dumpsys meminfo" 解析所有后台应用进程的内存占用（MB）与百分比。
     */
    fun queryRunningProcesses(context: Context): MemoryOverview {
        return try {
            var rawOutput = RootShell.exec("dumpsys meminfo --oom 2>/dev/null", 8_000L).orEmpty()
            if (!rawOutput.contains("Total PSS by process:")) {
                rawOutput = RootShell.exec(
                    "dumpsys meminfo 2>/dev/null | sed -n '/Total PSS by process:/,\$p'",
                    10_000L
                ) ?: execStandaloneSu("dumpsys meminfo --oom", 8_000L)
                ?: ""
            }

            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)

            var totalRamKb = (memInfo.totalMem / 1024L).toDouble()
            var usedRamKb = ((memInfo.totalMem - memInfo.availMem) / 1024L).toDouble()

            val pssByPackageKb = LinkedHashMap<String, Long>()
            val pidCountByPackage = HashMap<String, Int>()

            var inProcessSection = false
            for (rawLine in rawOutput.lineSequence()) {
                val line = rawLine.trim()
                if (line.isEmpty()) continue

                if (line.startsWith("Total RAM:")) {
                    val matched = totalRamRegex.find(line)?.groupValues?.getOrNull(1)
                        ?.replace(",", "")?.toDoubleOrNull()
                    if (matched != null && matched > 0.0) {
                        totalRamKb = matched
                    }
                    continue
                }
                if (line.startsWith("Free RAM:")) {
                    val freeKb = freeRamRegex.find(line)?.groupValues?.getOrNull(1)
                        ?.replace(",", "")?.toDoubleOrNull()
                    if (freeKb != null && totalRamKb > freeKb) {
                        usedRamKb = totalRamKb - freeKb
                    }
                    continue
                }

                if (line.startsWith("Total PSS by process:")) {
                    inProcessSection = true
                    continue
                }
                if (inProcessSection && (
                        line.startsWith("Total PSS by OOM") ||
                            line.startsWith("Total PSS by category")
                        )
                ) {
                    inProcessSection = false
                    continue
                }

                if (!inProcessSection && pssByPackageKb.isNotEmpty()) continue

                val match = processLineRegex.find(line) ?: continue
                val pssKb = match.groupValues[1].replace(",", "").toLongOrNull() ?: continue
                val processName = match.groupValues[2].trim()
                val basePackage = processName.substringBefore(':')
                if (!basePackage.contains('.') || basePackage == context.packageName) continue

                pssByPackageKb[basePackage] = (pssByPackageKb[basePackage] ?: 0L) + pssKb
                pidCountByPackage[basePackage] = (pidCountByPackage[basePackage] ?: 0) + 1
            }

            val safeTotalMb = (totalRamKb / 1024.0).coerceAtLeast(1024.0)
            val safeUsedMb = (usedRamKb / 1024.0).coerceIn(0.0, safeTotalMb)
            val pm = context.packageManager

            val resultList = ArrayList<AppProcessMemoryInfo>(pssByPackageKb.size)
            for ((pkg, totalKb) in pssByPackageKb) {
                val appInfo = getAppInfoOrNull(pm, pkg) ?: continue
                val label = try {
                    pm.getApplicationLabel(appInfo).toString().ifBlank { pkg }
                } catch (_: Throwable) {
                    pkg
                }
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                    (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0

                val memMb = totalKb / 1024.0
                val percent = ((memMb / safeTotalMb) * 100.0).coerceIn(0.01, 100.0)
                resultList.add(
                    AppProcessMemoryInfo(
                        packageName = pkg,
                        appName = label,
                        memoryMb = (memMb * 10.0).roundToInt() / 10.0,
                        memoryPercent = (percent * 100.0).roundToInt() / 100.0,
                        pidCount = pidCountByPackage[pkg] ?: 1,
                        isSystemApp = isSystem
                    )
                )
            }

            resultList.sortByDescending { it.memoryMb }
            MemoryOverview(
                totalRamMb = safeTotalMb,
                usedRamMb = safeUsedMb,
                processes = resultList
            )
        } catch (_: Throwable) {
            MemoryOverview(totalRamMb = 0.0, usedRamMb = 0.0, processes = emptyList())
        }
    }

    /**
     * 执行 Root 命令 su -c "am force-stop 包名" 强制停止目标应用。
     */
    fun forceStopPackage(packageName: String): Boolean {
        return try {
            val safePkg = packageName.trim()
            if (safePkg.isEmpty() || !safePkg.matches(Regex("^[A-Za-z0-9_.-]+$"))) return false
            val sharedOut = RootShell.exec("am force-stop $safePkg && echo OK", 5_000L)
            if (sharedOut?.contains("OK") == true) return true
            val standaloneOut = execStandaloneSu("am force-stop $safePkg && echo OK", 5_000L)
            standaloneOut?.contains("OK") == true
        } catch (_: Throwable) {
            false
        }
    }

    private fun getAppInfoOrNull(pm: PackageManager, packageName: String): ApplicationInfo? {
        return try {
            pm.getApplicationInfo(packageName, 0)
        } catch (_: Throwable) {
            null
        }
    }

    private fun execStandaloneSu(cmd: String, timeoutMs: Long): String? {
        var process: Process? = null
        return try {
            val started = ProcessBuilder("su", "-c", cmd)
                .redirectErrorStream(true)
                .start()
            process = started
            val buffer = StringBuilder()
            val readerThread = Thread({
                try {
                    BufferedReader(InputStreamReader(started.inputStream, Charsets.UTF_8)).use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            buffer.append(line).append('\n')
                        }
                    }
                } catch (_: Throwable) {
                }
            }, "PowerLogger-su-oneshot").apply {
                isDaemon = true
                start()
            }
            val finished = started.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
            if (!finished) {
                started.destroyForcibly()
                return null
            }
            readerThread.join(300L)
            buffer.toString()
        } catch (_: Throwable) {
            null
        } finally {
            try {
                process?.destroy()
            } catch (_: Throwable) {
            }
        }
    }
}
