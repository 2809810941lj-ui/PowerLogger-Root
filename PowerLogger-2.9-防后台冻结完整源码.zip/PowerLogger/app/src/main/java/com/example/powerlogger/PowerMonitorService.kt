package com.example.powerlogger

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.OutputStreamWriter
import java.util.Locale
import kotlin.math.abs

/**
 * 全天候整机功耗与日常应用功耗场景（App scenes）后台自动监测服务（含 N-2 反冻结保活引擎）。
 */
class PowerMonitorService : Service() {
    private lateinit var workerThread: HandlerThread
    private lateinit var workerHandler: Handler

    private lateinit var sceneThread: HandlerThread
    private lateinit var sceneHandler: Handler

    private var sampler: BatterySampler? = null
    private var csvLogger: CsvLogger? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var keepAliveOverlayView: View? = null
    private var antiFreezeRootProcess: Process? = null

    private var foregroundStarted = false
    private var checkingRoot = false
    private var screenReceiverRegistered = false

    @Volatile
    private var recording = false

    @Volatile
    private var uiInForeground = true

    @Volatile
    private var rootLeaseHeld = false

    private var serviceStartTimeMs: Long = 0L

    @Volatile
    private var latestSample: PowerSample? = null

    @Volatile
    private var latestTempC: Double = 0.0

    @Volatile
    private var latestLevel: Int = 0

    @Volatile
    private var activeSceneLabel: String = ""

    private var activeAppScene: AppSession? = null
    private var lastSceneFlushTimeMs: Long = 0L
    private var emptyFocusCount: Int = 0

    private val componentRegex = Regex("([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+)+)/([A-Za-z0-9_.$]+)")

    private val screenStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            sceneHandler.post {
                if (!recording) return@post
                if (action == Intent.ACTION_SCREEN_OFF) {
                    finishAndSaveActiveScene()
                }
            }
            workerHandler.post {
                if (!recording) return@post
                when (action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        recordScreenTransitionPoint(screenOn = false)
                        BatteryHistory.flush()
                        releaseWakeLock()
                    }
                    Intent.ACTION_SCREEN_ON -> {
                        recordScreenTransitionPoint(screenOn = true)
                        BatteryHistory.flush()
                        acquireWakeLock()
                        workerHandler.removeCallbacks(sampleRunnable)
                        workerHandler.post(sampleRunnable)
                    }
                }
            }
        }
    }

    private fun recordScreenTransitionPoint(screenOn: Boolean) {
        try {
            val snapshot = readBatterySnapshot(applicationContext)
            val dischargeWatts = if (!snapshot.charging) {
                (snapshot.voltageMv * abs(snapshot.currentMa) / 1_000_000.0).coerceAtLeast(0.0)
            } else {
                0.0
            }
            BatteryHistory.append(
                applicationContext,
                BatteryPoint(
                    time = System.currentTimeMillis(),
                    level = snapshot.level,
                    powerW = dischargeWatts,
                    tempC = snapshot.tempC,
                    voltageMv = snapshot.voltageMv,
                    screenOn = screenOn,
                    charging = snapshot.charging
                )
            )
        } catch (_: Throwable) {
        }
    }

    /**
     * 高优 1Hz 电池采样与通知栏刷新任务。
     */
    private val sampleRunnable = object : Runnable {
        override fun run() {
            if (!recording) return
            var nextDelay = SAMPLE_INTERVAL_UI_FOREGROUND_MS
            try {
                val powerManager = getSystemService(POWER_SERVICE) as PowerManager
                if (!powerManager.isInteractive) {
                    releaseWakeLock()
                    nextDelay = SAMPLE_INTERVAL_SCREEN_OFF_MS
                    return
                }

                acquireWakeLock()
                val sample = sampler?.sample()
                if (sample != null) {
                    val snapshot = readBatterySnapshot(applicationContext)
                    latestSample = sample
                    latestTempC = snapshot.tempC
                    latestLevel = snapshot.level

                    if (!sample.charging) {
                        csvLogger?.append(sample)
                    }

                    PowerMonitorState.updateSample(
                        sample = sample,
                        tempC = snapshot.tempC,
                        level = snapshot.level,
                        path = csvLogger?.file?.absolutePath
                    )

                    val dischargeWatts = if (!sample.charging) {
                        (abs(sample.powerMw) / 1000.0).coerceAtLeast(0.0)
                    } else {
                        0.0
                    }

                    BatteryHistory.append(
                        applicationContext,
                        BatteryPoint(
                            time = sample.timestamp,
                            level = snapshot.level,
                            powerW = dischargeWatts,
                            tempC = snapshot.tempC,
                            voltageMv = sample.voltageMv,
                            screenOn = true,
                            charging = sample.charging
                        )
                    )

                    notificationManager().notify(NOTIFICATION_ID, buildNotification())
                } else {
                    PowerMonitorState.markSampleUnavailable()
                }
                nextDelay = SAMPLE_INTERVAL_UI_FOREGROUND_MS
            } catch (_: Throwable) {
                PowerMonitorState.markSampleUnavailable()
            } finally {
                if (recording) {
                    workerHandler.removeCallbacks(this)
                    workerHandler.postDelayed(this, nextDelay)
                }
            }
        }
    }

    /**
     * 独立的后台场景追踪任务。
     */
    private val sceneTrackRunnable = object : Runnable {
        override fun run() {
            if (!recording) return
            try {
                val powerManager = getSystemService(POWER_SERVICE) as PowerManager
                val sample = latestSample
                if (!powerManager.isInteractive || sample == null) {
                    finishAndSaveActiveScene()
                    return
                }

                // 在充电的时候不记录放电功耗场景
                if (sample.charging) {
                    finishAndSaveActiveScene()
                    activeSceneLabel = "充电中"
                    return
                }

                val dischargeWatts = (abs(sample.powerMw) / 1000.0).coerceAtLeast(0.0)
                trackForegroundAppPowerScene(
                    now = System.currentTimeMillis(),
                    powerW = dischargeWatts,
                    tempC = latestTempC,
                    level = latestLevel,
                    voltageMv = sample.voltageMv,
                    charging = false
                )
            } catch (_: Throwable) {
            } finally {
                if (recording) {
                    sceneHandler.removeCallbacks(this)
                    sceneHandler.postDelayed(this, SCENE_TRACK_INTERVAL_MS)
                }
            }
        }
    }

    /**
     * 【第一重反冻结】：启动运行在 root (uid=0) 下的独立反冻结守护子进程。
     * 当用户从 A 切到 B 再切到 C（A 退至 N-2）时，国产 ROM（如 ColorOS Hans / HyperOS Millet）
     * 会向 /sys/fs/cgroup/.../cgroup.freeze 写入 1 冻结应用进程。
     * 由于 root 子进程处于 root cgroup 不受应用冻结影响，它会每秒自动将本应用 PID 的 oom_score_adj 锁定为 -900，
     * 并将 cgroup.freeze 强制写回 0（秒解冻），使采样线程在 B->C->D 任意切换下永远保持活跃！
     */
    private fun startRootAntiFreezeDaemon() {
        stopRootAntiFreezeDaemon()
        val myPid = android.os.Process.myPid()
        val myUid = android.os.Process.myUid()
        val pkg = packageName
        try {
            val proc = ProcessBuilder("su").redirectErrorStream(true).start()
            antiFreezeRootProcess = proc
            val writer = OutputStreamWriter(proc.outputStream, Charsets.UTF_8)
            val script = """
                cmd deviceidle whitelist +$pkg >/dev/null 2>&1
                cmd appops set $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1
                cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1
                cmd activity set-standby-bucket $pkg active >/dev/null 2>&1
                while [ -d /proc/$myPid ]; do
                    echo -900 > /proc/$myPid/oom_score_adj 2>/dev/null
                    echo 0 > /sys/fs/cgroup/uid_$myUid/pid_$myPid/cgroup.freeze 2>/dev/null
                    echo 0 > /sys/fs/cgroup/freeze/uid_$myUid/pid_$myPid/cgroup.freeze 2>/dev/null
                    echo 0 > /sys/fs/cgroup/freezer/perf/frozen/cgroup.freeze 2>/dev/null
                    echo $myPid > /dev/freezer/thawed/cgroup.procs 2>/dev/null
                    echo $myPid > /dev/cpuctl/top-app/cgroup.procs 2>/dev/null
                    sleep 1
                done
            """.trimIndent() + "\n"
            writer.write(script)
            writer.flush()
            AppLogManager.i("AntiFreeze", "已启动 Root 反冻结守护进程 (PID=$myPid, UID=$myUid)")
        } catch (t: Throwable) {
            AppLogManager.w("AntiFreeze", "启动 Root 反冻结守护异常", t)
        }
    }

    private fun stopRootAntiFreezeDaemon() {
        val old = antiFreezeRootProcess
        antiFreezeRootProcess = null
        if (old != null) {
            try {
                old.destroyForcibly()
            } catch (_: Throwable) {
            }
        }
    }

    /**
     * 【第二重反冻结】：若用户已授予悬浮窗权限，挂载一个 1×1 像素全透明、不拦截任何触摸的隐形窗口，
     * 使系统 WindowManager 标记本进程 hasOverlayUi = true，从源头阻止 ROM 在 B->C 时将本进程判定为后台 N-2 冻结对象。
     */
    private fun attachKeepAliveOverlayIfPermitted() {
        if (keepAliveOverlayView != null) return
        if (!Settings.canDrawOverlays(this)) return
        Handler(Looper.getMainLooper()).post {
            if (!recording || keepAliveOverlayView != null || !Settings.canDrawOverlays(this)) return@post
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val view = View(applicationContext).apply {
                    alpha = 0f
                }
                val lp = WindowManager.LayoutParams(
                    1,
                    1,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = 0
                    y = 0
                }
                wm.addView(view, lp)
                keepAliveOverlayView = view
                AppLogManager.i("AntiFreeze", "已挂载 1x1 无感保活窗口锚点 (hasOverlayUi=true)")
            } catch (_: Throwable) {
            }
        }
    }

    private fun detachKeepAliveOverlay() {
        val view = keepAliveOverlayView ?: return
        keepAliveOverlayView = null
        Handler(Looper.getMainLooper()).post {
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                wm.removeView(view)
            } catch (_: Throwable) {
            }
        }
    }

    /**
     * 【第三重反冻结】：当 MainActivity (excludeFromRecents="true") 在从 B 切换到 C 时被系统移除 Task，
     * 拦截 onTaskRemoved 并立刻唤醒采样队列，防止服务随 Task 移除而中断。
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (recording) {
            workerHandler.removeCallbacks(sampleRunnable)
            workerHandler.post(sampleRunnable)
            sceneHandler.removeCallbacks(sceneTrackRunnable)
            sceneHandler.post(sceneTrackRunnable)
            AppLogManager.i("AntiFreeze", "检测到 Recent Task 移除 (B->C)，已保持后台监测服务继续运行")
        }
    }

    private fun trackForegroundAppPowerScene(
        now: Long,
        powerW: Double,
        tempC: Double,
        level: Int,
        voltageMv: Int,
        charging: Boolean
    ) {
        val fg = detectForegroundAppFast()
        if (fg == null || fg.packageName.isEmpty()) {
            emptyFocusCount++
            if (emptyFocusCount >= 2) {
                finishAndSaveActiveScene()
            }
            return
        }
        emptyFocusCount = 0

        val pkg = fg.packageName
        if (pkg == "com.android.systemui" || pkg == "android" || isLauncherPackage(pkg)) {
            finishAndSaveActiveScene()
            return
        }

        val current = activeAppScene
        if (current != null && (current.packageName != pkg || current.samples.size >= MAX_SCENE_SAMPLES)) {
            finishAndSaveActiveScene()
        }

        val session = activeAppScene ?: run {
            val label = resolveAppLabel(pkg)
            AppSession(
                id = now,
                packageName = pkg,
                label = label,
                activity = fg.activity,
                startTime = now,
                endTime = now,
                model = Build.MODEL ?: "",
                soc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    Build.SOC_MODEL ?: Build.HARDWARE
                } else {
                    Build.HARDWARE
                },
                os = "Android ${Build.VERSION.RELEASE}"
            ).also {
                activeAppScene = it
                activeSceneLabel = label
                lastSceneFlushTimeMs = 0L
            }
        }

        activeSceneLabel = session.label
        session.endTime = now
        synchronized(session.samples) {
            session.samples.add(
                SceneSample(
                    time = now,
                    fps = 0.0,
                    frameMs = 0.0,
                    powerW = powerW,
                    capacity = level,
                    batteryTemp = tempC,
                    voltageMv = voltageMv,
                    charging = charging
                )
            )
            if (session.samples.size == 1) {
                session.samples.add(0, session.samples.first().copy(time = (now - 1000L).coerceAtLeast(0L)))
                session.endTime = now
            }
        }

        val sampleCount = session.samples.size
        if (sampleCount <= 3 || now - lastSceneFlushTimeMs >= SCENE_FLUSH_INTERVAL_MS) {
            lastSceneFlushTimeMs = now
            SessionStore.save(applicationContext, session)
        }
    }

    private fun finishAndSaveActiveScene() {
        val current = activeAppScene ?: return
        activeAppScene = null
        activeSceneLabel = ""
        lastSceneFlushTimeMs = 0L
        if (current.samples.isNotEmpty()) {
            current.endTime = maxOf(System.currentTimeMillis(), current.startTime + 1_000L)
            SessionStore.save(applicationContext, current)
        }
    }

    private fun detectForegroundAppFast(): ForegroundApp? {
        val out = RootShell.exec(
            "dumpsys activity activities 2>/dev/null | grep -E 'topResumedActivity|mResumedActivity|ResumedActivity' | head -6; " +
                "dumpsys window displays 2>/dev/null | grep -E 'mCurrentFocus|mFocusedApp' | head -6",
            3_500L
        ).orEmpty()
        for (rawLine in out.lineSequence()) {
            val line = rawLine.trim()
            if (line.isEmpty() || line.contains("=null")) continue
            val m = componentRegex.find(line) ?: continue
            val pkg = m.groupValues[1]
            val act = m.groupValues[2]
            if (pkg != "com.android.systemui" && pkg != "android") {
                return ForegroundApp(pkg, act)
            }
        }
        return null
    }

    private fun isLauncherPackage(pkg: String): Boolean {
        val lower = pkg.lowercase(Locale.US)
        return lower.contains("launcher") || lower.contains("miui.home") || lower.contains("trebuchet")
    }

    private fun resolveAppLabel(pkg: String): String {
        return try {
            val info = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(info).toString().ifBlank { pkg }
        } catch (_: Throwable) {
            pkg
        }
    }

    override fun onCreate() {
        super.onCreate()
        serviceStartTimeMs = System.currentTimeMillis()
        workerThread = HandlerThread("PowerLogger-Battery1Hz").apply { start() }
        workerHandler = Handler(workerThread.looper)
        sceneThread = HandlerThread("PowerLogger-SceneTracker").apply { start() }
        sceneHandler = Handler(sceneThread.looper)
        createNotificationChannel()
        registerScreenReceiver()
    }

    private fun registerScreenReceiver() {
        if (screenReceiverRegistered) return
        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            }
            registerReceiver(screenStateReceiver, filter)
            screenReceiverRegistered = true
        } catch (_: Throwable) {
        }
    }

    private fun unregisterScreenReceiver() {
        if (!screenReceiverRegistered) return
        screenReceiverRegistered = false
        try {
            unregisterReceiver(screenStateReceiver)
        } catch (_: Throwable) {
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                workerHandler.post { stopRecording("已停止记录") }
                return START_NOT_STICKY
            }
            ACTION_CLEAR_CACHE -> {
                sceneHandler.post {
                    activeAppScene = null
                    activeSceneLabel = ""
                    lastSceneFlushTimeMs = 0L
                }
                PowerMonitorState.trimMemory()
                return START_NOT_STICKY
            }
            ACTION_UI_FOREGROUND -> {
                uiInForeground = true
                if (recording) {
                    workerHandler.removeCallbacks(sampleRunnable)
                    workerHandler.post(sampleRunnable)
                }
                return if (recording) START_STICKY else START_NOT_STICKY
            }
            ACTION_UI_BACKGROUND -> {
                uiInForeground = false
                attachKeepAliveOverlayIfPermitted()
                sceneHandler.post {
                    BatteryHistory.flush()
                    activeAppScene?.let { SessionStore.save(applicationContext, it) }
                }
                PowerMonitorState.trimMemory()
                return if (recording) START_STICKY else START_NOT_STICKY
            }
        }

        if (!enterForeground()) {
            PowerMonitorState.markStopped("无法启动前台服务，请检查系统限制")
            stopSelf(startId)
            return START_NOT_STICKY
        }

        workerHandler.post { startRecording() }
        return START_STICKY
    }

    private fun enterForeground(): Boolean {
        if (foregroundStarted) return true
        return try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            foregroundStarted = true
            true
        } catch (e: Throwable) {
            android.util.Log.e(TAG, "startForeground 失败", e)
            false
        }
    }

    private fun startRecording() {
        if (recording || checkingRoot) return
        checkingRoot = true
        PowerMonitorState.markStarting()

        if (!RootShell.acquire()) {
            failStart("Root 不可用：请在 Magisk/KernelSU 中授予 PowerLogger 权限")
            return
        }
        rootLeaseHeld = true

        try {
            sampler = BatterySampler(this).also { it.initialize() }
            csvLogger = CsvLogger(this)
            val outputFile = csvLogger?.start()
            if (outputFile == null) {
                failStart("无法创建 CSV 文件，请检查外部私有目录空间")
                return
            }

            acquireWakeLock()
            checkingRoot = false
            recording = true
            PowerMonitorState.markSessionStarted(outputFile.absolutePath)

            // 启动 Root 内核级反冻结守护 + 1x1 透明窗口保活锚点
            startRootAntiFreezeDaemon()
            attachKeepAliveOverlayIfPermitted()

            workerHandler.removeCallbacks(sampleRunnable)
            workerHandler.post(sampleRunnable)

            sceneHandler.removeCallbacks(sceneTrackRunnable)
            sceneHandler.postDelayed(sceneTrackRunnable, 500L)

            AppLogManager.i("PowerService", "反冻结全天候功耗监测已启动（B->C 切换防冻结已激活）")
        } catch (e: Throwable) {
            AppLogManager.e("PowerService", "启动记录失败", e)
            failStart("启动记录失败：${e.message ?: "未知错误"}")
        }
    }

    private fun failStart(message: String) {
        checkingRoot = false
        recording = false
        activeAppScene = null
        activeSceneLabel = ""
        stopRootAntiFreezeDaemon()
        detachKeepAliveOverlay()
        try {
            csvLogger?.stop()
        } catch (_: Throwable) {
        }
        csvLogger = null
        sampler?.close()
        sampler = null
        BatteryHistory.flush()
        releaseRootLease()
        releaseWakeLock()
        PowerMonitorState.markStopped(message)
        stopForeground(STOP_FOREGROUND_REMOVE)
        foregroundStarted = false
        stopSelf()
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
        }
    }

    private fun stopRecording(message: String) {
        recording = false
        checkingRoot = false
        workerHandler.removeCallbacks(sampleRunnable)
        sceneHandler.removeCallbacks(sceneTrackRunnable)

        stopRootAntiFreezeDaemon()
        detachKeepAliveOverlay()
        finishAndSaveActiveScene()

        try {
            csvLogger?.flush()
            csvLogger?.stop()
        } catch (e: Throwable) {
            android.util.Log.w(TAG, "CSV flush 失败", e)
        }
        csvLogger = null
        sampler?.close()
        sampler = null
        BatteryHistory.flush()

        releaseRootLease()
        releaseWakeLock()
        PowerMonitorState.markStopped(message)
        PowerMonitorState.trimMemory()

        if (foregroundStarted) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            foregroundStarted = false
        }
        stopSelf()
    }

    private fun releaseRootLease() {
        if (rootLeaseHeld) {
            rootLeaseHeld = false
            RootShell.release()
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PowerLogger::Sampling").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Throwable) {
        } finally {
            wakeLock = null
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "整机与场景功耗监测",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "每秒实时显示当前功率、电压和电流（放电为 -，充电为 +）"
                setShowBadge(false)
            }
            notificationManager().createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val state = PowerMonitorState.state.value
        val absWatts = abs(state.powerMw) / 1000.0
        val absMa = abs(state.currentMa)
        val signChar = if (state.charging) "+" else "-"

        val powerText = String.format(Locale.US, "%s%.2f W", signChar, absWatts)
        val currentText = String.format(Locale.US, "%s%.1f mA", signChar, absMa)
        val label = activeSceneLabel
        val sceneSuffix = if (label.isNotBlank()) "  ·  $label" else ""

        val line = if (state.lastSampleTime > 0L) {
            "$powerText  ·  ${state.voltageMv} mV  ·  $currentText$sceneSuffix"
        } else {
            "正在全天候监测功耗与 App scenes…"
        }

        val openIntent = Intent(this, MainActivity::class.java)
        val openPendingIntent = PendingIntent.getActivity(
            this,
            REQUEST_OPEN,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, PowerMonitorService::class.java).setAction(ACTION_STOP)
        val stopPendingIntent = PendingIntent.getService(
            this,
            REQUEST_STOP,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle(if (state.charging) "PowerLogger 正在充电 (+)" else "PowerLogger 功耗统计运行中")
            .setContentText(line)
            .setStyle(NotificationCompat.BigTextStyle().bigText(line))
            .setContentIntent(openPendingIntent)
            .setWhen(serviceStartTimeMs)
            .setShowWhen(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_media_pause, "暂停监测", stopPendingIntent)
            .build()
    }

    private fun notificationManager(): NotificationManager =
        getSystemService(NOTIFICATION_SERVICE) as NotificationManager

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        PowerMonitorState.trimMemory()
    }

    override fun onDestroy() {
        recording = false
        unregisterScreenReceiver()
        workerHandler.removeCallbacks(sampleRunnable)
        sceneHandler.removeCallbacks(sceneTrackRunnable)
        stopRootAntiFreezeDaemon()
        detachKeepAliveOverlay()
        finishAndSaveActiveScene()
        try {
            csvLogger?.stop()
        } catch (_: Throwable) {
        }
        sampler?.close()
        sampler = null
        BatteryHistory.flush()
        releaseRootLease()
        releaseWakeLock()
        PowerMonitorState.markStopped("服务已结束")
        workerThread.quitSafely()
        sceneThread.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.example.powerlogger.action.START"
        const val ACTION_STOP = "com.example.powerlogger.action.STOP"
        const val ACTION_UI_FOREGROUND = "com.example.powerlogger.action.UI_FOREGROUND"
        const val ACTION_UI_BACKGROUND = "com.example.powerlogger.action.UI_BACKGROUND"
        const val ACTION_CLEAR_CACHE = "com.example.powerlogger.action.CLEAR_CACHE"

        private const val TAG = "PowerLogger-Service"
        private const val CHANNEL_ID = "power_logger_recording"
        private const val NOTIFICATION_ID = 2401
        private const val REQUEST_OPEN = 2402
        private const val REQUEST_STOP = 2403
        private const val SAMPLE_INTERVAL_UI_FOREGROUND_MS = 1_000L
        private const val SAMPLE_INTERVAL_SCREEN_OFF_MS = 5_000L
        private const val SCENE_TRACK_INTERVAL_MS = 2_000L
        private const val SCENE_FLUSH_INTERVAL_MS = 12_000L
        private const val MAX_SCENE_SAMPLES = 3600
    }
}
