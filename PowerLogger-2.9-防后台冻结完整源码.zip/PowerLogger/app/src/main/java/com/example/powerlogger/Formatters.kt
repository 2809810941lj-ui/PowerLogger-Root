package com.example.powerlogger

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatDurationShort(ms: Long): String {
    val total = (ms / 1000L).coerceAtLeast(0L)
    val h = total / 3600L
    val m = (total % 3600L) / 60L
    val s = total % 60L
    return when {
        h > 0L -> "${h}h${m}m"
        m > 0L && s > 0L -> "${m}m${s}s"
        m > 0L -> "${m}m"
        else -> "${s}s"
    }
}

fun formatExpected(ms: Long): String {
    val total = (ms / 1000L).coerceAtLeast(0L)
    val h = total / 3600L
    val m = (total % 3600L) / 60L
    return when {
        h > 0L && m > 0L -> "${h}h${m}"
        h > 0L -> "${h}h"
        m > 0L -> "${m}m"
        else -> "--"
    }
}

fun formatDateTime(ms: Long): String {
    if (ms <= 0L) return "--"
    return SimpleDateFormat("yyyy.MM.dd HH:mm:ss", Locale.US).format(Date(ms))
}

fun formatClock(ms: Long): String {
    if (ms <= 0L) return "--"
    return SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(ms))
}

fun formatWatts(value: Double): String = String.format(Locale.US, "%.2fW", value)

fun formatTemp(value: Double): String {
    if (value <= 0.0) return "--"
    return String.format(Locale.US, "%.1f°C", value)
}

fun axisLabels(durationMs: Long, count: Int = 5): List<String> {
    val safe = durationMs.coerceAtLeast(1000L)
    return (0 until count).map { index ->
        val t = safe * index / (count - 1).coerceAtLeast(1)
        val sec = t / 1000L
        when {
            sec <= 0L -> "0"
            sec >= 3600L -> "${sec / 3600L}h${(sec % 3600L) / 60L}m"
            else -> "${sec / 60L}m${sec % 60L}s"
        }
    }
}

fun niceMax(value: Double, floor: Double, step: Double): Float {
    if (value <= 0.0) return floor.toFloat()
    val target = maxOf(value, floor)
    val units = kotlin.math.ceil(target / step).toInt()
    return (units * step).toFloat().coerceAtLeast(floor.toFloat())
}
