package com.example.powerlogger

import android.content.Context
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import kotlin.math.abs

/**
 * 整机电池单次采样结果：
 * 严格遵循用户定义：
 * - 放电（Discharging）：currentMa 为负数（-），powerMw 为负数（-）
 * - 充电（Charging）：currentMa 为正数（+），powerMw 为正数（+）
 */
data class PowerSample(
    val timestamp: Long,
    val currentMa: Double,
    val voltageMv: Int,
    val powerMw: Double,
    val charging: Boolean,
    val source: String
)

/**
 * 专用极速电池采样器：
 * 内部维护一条轻量级独立 su 管道专门读取 sysfs 电流/电压节点，
 * 绝不与耗时的 dumpsys window / SurfaceFlinger / meminfo 争抢同一把锁，确保通知栏每秒 100% 准时刷新不卡死。
 */
class BatterySampler(private val context: Context) {
    private val currentCandidates = listOf(
        "/sys/class/oplus_chg/battery/current_now",
        "/sys/class/power_supply/battery/current_now",
        "/sys/class/power_supply/bms/current_now",
        "/sys/class/power_supply/battery/BatteryAverageCurrent",
        "/sys/class/power_supply/battery/batt_current",
        "/sys/class/power_supply/bms/batt_current"
    )

    private val voltageCandidates = listOf(
        "/sys/class/oplus_chg/battery/voltage_now",
        "/sys/class/power_supply/battery/voltage_now",
        "/sys/class/power_supply/bms/voltage_now",
        "/sys/class/power_supply/battery/BatteryAverageVoltage",
        "/sys/class/power_supply/battery/batt_vol",
        "/sys/class/power_supply/bms/batt_vol"
    )

    private val shellLock = Any()
    private var suProcess: Process? = null
    private var suWriter: BufferedWriter? = null
    private var suReader: BufferedReader? = null

    fun initialize() {
        readSysfsValues()
    }

    fun close() = synchronized(shellLock) {
        closeDedicatedSuLocked()
    }

    fun sample(): PowerSample? {
        val snapshot = readBatterySnapshot(context)
        val values = readSysfsValues()
        val rawCurrent = values.current
        val currentPath = values.currentPath
        val rawVoltage = values.voltage
        val voltagePath = values.voltagePath

        val sysfsVoltageMv = rawVoltage?.let { toMilliVolts(it, voltagePath.orEmpty()) }
            ?.takeIf { it in 2_500..6_000 }
        val sysfsCurrentMa = rawCurrent?.let { toMilliAmps(it, currentPath.orEmpty()) }
            ?.takeIf { it in 0.0..30_000.0 }

        val voltageMv = sysfsVoltageMv
            ?: snapshot.voltageMv.takeIf { it in 2_500..6_000 }
            ?: 0
        val currentAbsMa = sysfsCurrentMa
            ?: abs(snapshot.currentMa).takeIf { it in 0.0..30_000.0 }
            ?: 0.0

        if (voltageMv <= 0) return null

        // 严格定义：充电为正（+），放电为负（-）
        val sign = if (snapshot.charging) 1.0 else -1.0
        val signedCurrentMa = currentAbsMa * sign
        val powerMw = (voltageMv.toDouble() * currentAbsMa / 1000.0) * sign

        val source = when {
            sysfsCurrentMa != null && sysfsVoltageMv != null -> "sysfs"
            sysfsCurrentMa != null || sysfsVoltageMv != null -> "mixed"
            else -> "api"
        }
        return PowerSample(
            timestamp = System.currentTimeMillis(),
            currentMa = signedCurrentMa,
            voltageMv = voltageMv,
            powerMw = powerMw,
            charging = snapshot.charging,
            source = source
        )
    }

    private data class NodeValues(
        val current: Double?,
        val currentPath: String?,
        val voltage: Double?,
        val voltagePath: String?
    )

    private fun readSysfsValues(): NodeValues = synchronized(shellLock) {
        val marker = "__BAT_END__"
        val command = buildString {
            append("for p in ")
            append(currentCandidates.joinToString(" "))
            append("; do v=\$(cat \"\$p\" 2>/dev/null); ")
            append("case \"\$v\" in ''|*[!0-9.-]*) continue;; esac; ")
            append("echo \"CUR|\$p|\$v\"; break; done\n")
            append("for p in ")
            append(voltageCandidates.joinToString(" "))
            append("; do v=\$(cat \"\$p\" 2>/dev/null); ")
            append("case \"\$v\" in ''|*[!0-9.-]*) continue;; esac; ")
            append("echo \"VOL|\$p|\$v\"; break; done\n")
            append("echo $marker\n")
        }

        var current: Double? = null
        var currentPath: String? = null
        var voltage: Double? = null
        var voltagePath: String? = null

        try {
            if (!ensureDedicatedSuLocked()) {
                return NodeValues(null, null, null, null)
            }
            val writer = suWriter ?: return NodeValues(null, null, null, null)
            val reader = suReader ?: return NodeValues(null, null, null, null)

            writer.write(command)
            writer.flush()

            var linesRead = 0
            while (linesRead < 20) {
                val line = reader.readLine() ?: throw IllegalStateException("su EOF")
                linesRead++
                val trimmed = line.trim()
                if (trimmed == marker) break
                val parts = trimmed.split('|', limit = 3)
                if (parts.size != 3) continue
                val value = parts[2].toDoubleOrNull() ?: continue
                when (parts[0]) {
                    "CUR" -> {
                        current = value
                        currentPath = parts[1]
                    }
                    "VOL" -> {
                        voltage = value
                        voltagePath = parts[1]
                    }
                }
            }
        } catch (_: Throwable) {
            closeDedicatedSuLocked()
        }

        return NodeValues(current, currentPath, voltage, voltagePath)
    }

    private fun ensureDedicatedSuLocked(): Boolean {
        val p = suProcess
        if (p != null && p.isAlive && suWriter != null && suReader != null) {
            return true
        }
        closeDedicatedSuLocked()
        return try {
            val started = ProcessBuilder("su").redirectErrorStream(true).start()
            suProcess = started
            suWriter = BufferedWriter(OutputStreamWriter(started.outputStream, Charsets.UTF_8))
            suReader = BufferedReader(InputStreamReader(started.inputStream, Charsets.UTF_8))
            true
        } catch (_: Throwable) {
            closeDedicatedSuLocked()
            false
        }
    }

    private fun closeDedicatedSuLocked() {
        try { suWriter?.close() } catch (_: Throwable) {}
        try { suReader?.close() } catch (_: Throwable) {}
        suWriter = null
        suReader = null
        val old = suProcess
        suProcess = null
        if (old != null) {
            try { old.destroyForcibly() } catch (_: Throwable) {}
        }
    }

    private fun toMilliAmps(raw: Double, path: String): Double {
        val value = abs(raw)
        return when {
            path.endsWith("current_now") && value >= 1_500.0 -> value / 1000.0
            value >= 100_000.0 -> value / 1000.0
            else -> value
        }
    }

    private fun toMilliVolts(raw: Double, path: String): Int {
        val value = abs(raw)
        val mv = when {
            path.endsWith("voltage_now") && value >= 100_000.0 -> value / 1000.0
            value >= 100_000.0 -> value / 1000.0
            else -> value
        }
        return mv.toInt()
    }
}
