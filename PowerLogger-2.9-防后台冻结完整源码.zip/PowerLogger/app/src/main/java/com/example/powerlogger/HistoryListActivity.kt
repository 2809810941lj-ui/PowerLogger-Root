package com.example.powerlogger

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 历史记录列表 Activity：
 * 从 Room 数据库读取所有已保存的应用帧率与功耗记录，
 * 点击列表项通过 Intent 传递记录 ID 跳转至单应用数据详情页。
 */
class HistoryListActivity : ComponentActivity() {

    private lateinit var rvHistoryList: RecyclerView
    private lateinit var llEmptyState: LinearLayout
    private lateinit var tvRecordCount: TextView
    private lateinit var tvClearAll: TextView
    private lateinit var btnBack: ImageButton
    private lateinit var adapter: HistoryRecordAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history_list)

        btnBack = findViewById(R.id.btnBack)
        tvRecordCount = findViewById(R.id.tvRecordCount)
        tvClearAll = findViewById(R.id.tvClearAll)
        rvHistoryList = findViewById(R.id.rvHistoryList)
        llEmptyState = findViewById(R.id.llEmptyState)

        adapter = HistoryRecordAdapter(
            onItemClick = { record ->
                openSessionDetail(record.id)
            },
            onItemLongClick = { record ->
                confirmDeleteSingle(record)
            }
        )

        rvHistoryList.layoutManager = LinearLayoutManager(this)
        rvHistoryList.adapter = adapter

        btnBack.setOnClickListener {
            finish()
        }

        tvClearAll.setOnClickListener {
            confirmClearAll()
        }

        observeRoomRecords()
    }

    private fun observeRoomRecords() {
        val dao = AppDatabase.getInstance(this).sessionRecordDao()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                dao.observeAll().collectLatest { records ->
                    adapter.submitList(records)
                    tvRecordCount.text = "共 ${records.size} 条记录"
                    tvClearAll.visibility = if (records.isNotEmpty()) View.VISIBLE else View.GONE
                    if (records.isEmpty()) {
                        rvHistoryList.visibility = View.GONE
                        llEmptyState.visibility = View.VISIBLE
                    } else {
                        rvHistoryList.visibility = View.VISIBLE
                        llEmptyState.visibility = View.GONE
                    }
                }
            }
        }
    }

    private fun openSessionDetail(recordId: Long) {
        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra(MainActivity.EXTRA_SESSION_ID, recordId)
            putExtra(MainActivity.EXTRA_FROM_HISTORY, true)
        }
        startActivity(intent)
    }

    private fun confirmDeleteSingle(record: SessionRecordEntity) {
        AlertDialog.Builder(this)
            .setTitle("删除该条记录？")
            .setMessage("将删除「${record.appName}」于 ${formatDateTime(record.startTime)} 的记录数据。")
            .setPositiveButton("删除") { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    AppDatabase.getInstance(applicationContext).sessionRecordDao().deleteById(record.id)
                    SessionStore.delete(applicationContext, record.id)
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@HistoryListActivity, "记录已删除", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun confirmClearAll() {
        AlertDialog.Builder(this)
            .setTitle("清空全部历史记录？")
            .setMessage("此操作将清空 Room 数据库中的所有应用测试记录，不可恢复。")
            .setPositiveButton("清空") { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    AppDatabase.getInstance(applicationContext).sessionRecordDao().deleteAll()
                    SessionStore.clear(applicationContext)
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@HistoryListActivity, "已清空全部历史记录", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }
}
