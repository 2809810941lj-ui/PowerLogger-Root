package com.example.powerlogger

import android.os.SystemClock
import kotlin.math.sqrt

internal data class FpsReading(
    val fps: Double,
    val jitter: Double,
    val latestTimestampNs: Long = 0L
)

/**
 * 帧率时间戳与 SurfaceFlinger TimeStats 解析器：
 * 1. 解决手机休眠后 System.nanoTime() (CLOCK_MONOTONIC) 与硬件呈现时间戳 (CLOCK_BOOTTIME) 偏移导致全部帧被过滤为 0 的问题；
 * 2. 引入增量帧时间戳对比（lastMaxTimestampNs），只要环形缓冲区有新帧推进即可基于帧间真实时间差计算 FPS；
 * 3. 支持解析 Android 10-16 的 `dumpsys SurfaceFlinger --timestats` 输出，覆盖 BLAST 图层、SurfaceView 与游戏图层；
 * 4. 在 `gfxinfo framestats` 中同时支持 FrameCompleted、SwapBuffersCompleted 与 IntendedVsync。
 */
internal object FpsFrameParser {
    private const val FPS_WINDOW_NS = 1_800_000_000L
    private const val CLOCK_MATCH_TOLERANCE_NS = 3_000_000_000L
    private const val MIN_FPS_SPAN_SECONDS = 0.08
    private const val MAX_SUPPORTED_FPS = 480.0

    /**
     * 提取 SurfaceFlinger --list 中的真实图层名。
     */
    fun normalizeLayerName(rawLine: String): String? {
        var line = rawLine.trim()
        if (line.isEmpty()) return null

        if (line.startsWith("RequestedLayerState{")) {
            line = line.removePrefix("RequestedLayerState{")
                .substringBefore(" parentId=")
                .removeSuffix("}")
                .trim()
        } else if (line.startsWith("Layer{")) {
            val inner = line.removePrefix("Layer{").removeSuffix("}").trim()
            val named = Regex("(?:^|\\s)name=([^,}]+)").find(inner)?.groupValues?.getOrNull(1)
            line = (named ?: inner).trim()
        }

        // 剥离行尾可能附带的调试属性（如 " (BLAST)" 之后的统计信息）
        return line.takeIf { it.isNotEmpty() }
    }

    /**
     * 解析 SurfaceFlinger --latency 三列：desiredPresent、actualPresent、frameReady。
     */
    fun parseSurfaceFlingerLatency(text: String, previousMaxTs: Long = 0L): FpsReading {
        if (text.isBlank()) return FpsReading(0.0, 0.0, previousMaxTs)
        val timestamps = text.lineSequence().mapNotNull { line ->
            val columns = line.trim().split(Regex("\\s+"))
            if (columns.size < 3) return@mapNotNull null
            val actualPresent = columns[1].toLongOrNull() ?: return@mapNotNull null
            val frameReady = columns[2].toLongOrNull() ?: 0L
            when {
                actualPresent in 1_000_000L until Long.MAX_VALUE -> actualPresent
                frameReady in 1_000_000L until Long.MAX_VALUE -> frameReady
                else -> null
            }
        }.toList()
        return calculateFps(timestamps, previousMaxTs)
    }

    /**
     * 解析 dumpsys gfxinfo <pkg> framestats 的 PROFILEDATA CSV 块。
     */
    fun parseGfxInfoFrameStats(text: String, previousMaxTs: Long = 0L): FpsReading {
        if (text.isBlank()) return FpsReading(0.0, 0.0, previousMaxTs)
        val marker = "---PROFILEDATA---"
        var searchFrom = 0
        val allTimestamps = ArrayList<Long>()

        while (true) {
            val start = text.indexOf(marker, searchFrom)
            if (start < 0) break
            val contentStart = start + marker.length
            val end = text.indexOf(marker, contentStart)
            val block = if (end >= 0) text.substring(contentStart, end) else text.substring(contentStart)
            searchFrom = if (end >= 0) end + marker.length else text.length

            val lines = block.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
            val headerIdx = lines.indexOfFirst {
                it.contains("IntendedVsync") || it.contains("FrameCompleted")
            }
            if (headerIdx < 0) continue

            val headers = lines[headerIdx].split(',').map { it.trim() }
            val completedIdx = headers.indexOf("FrameCompleted")
            val swapIdx = headers.indexOf("SwapBuffersCompleted")
            val gpuIdx = headers.indexOf("GpuCompleted")
            val vsyncIdx = headers.indexOf("IntendedVsync")

            for (i in (headerIdx + 1) until lines.size) {
                val cols = lines[i].split(',')
                val ts = pickValidTimestamp(cols, completedIdx)
                    ?: pickValidTimestamp(cols, gpuIdx)
                    ?: pickValidTimestamp(cols, swapIdx)
                    ?: pickValidTimestamp(cols, vsyncIdx)
                if (ts != null) {
                    allTimestamps.add(ts)
                }
            }
        }

        return calculateFps(allTimestamps, previousMaxTs)
    }

    private fun pickValidTimestamp(cols: List<String>, index: Int): Long? {
        if (index < 0 || index >= cols.size) return null
        val v = cols[index].trim().toLongOrNull() ?: return null
        return v.takeIf { it in 1_000_000L until Long.MAX_VALUE }
    }

    /**
     * 解析 Android 10-16 `dumpsys SurfaceFlinger --timestats -dump` 输出。
     * TimeStats 由 SurfaceFlinger 合成器直接统计每个图层的真实上屏帧率（包括 BLAST、SurfaceView、Flutter、WebView、Vulkan/OpenGL）。
     */
    fun parseSurfaceFlingerTimeStats(text: String, targetPackage: String): FpsReading {
        if (text.isBlank() || targetPackage.isBlank()) return FpsReading(0.0, 0.0)
        var bestFps = 0.0

        // 按图层块拆分（每个图层块以 layerName = ... 开始）
        val blocks = text.split(Regex("(?=layerName\\s*=)"))
        for (block in blocks) {
            val matchesPkg = block.contains(targetPackage, ignoreCase = true)
            if (!matchesPkg) continue
            // 排除截图、壁纸、启动页与后台阴影层
            val firstLine = block.lineSequence().firstOrNull().orEmpty()
            if (firstLine.contains("Screenshot", ignoreCase = true) ||
                firstLine.contains("Wallpaper", ignoreCase = true) ||
                firstLine.contains("Splash", ignoreCase = true) ||
                firstLine.contains("Snapshot", ignoreCase = true)
            ) {
                continue
            }

            val avgMatch = Regex("averageFPS\\s*=\\s*([0-9]+(?:\\.[0-9]+)?)").find(block)
            val fpsVal = avgMatch?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: 0.0
            if (fpsVal in 1.0..MAX_SUPPORTED_FPS && fpsVal > bestFps) {
                bestFps = fpsVal
            }
        }

        return FpsReading(fps = bestFps, jitter = 0.0)
    }

    private fun calculateFps(timestamps: List<Long>, previousMaxTs: Long): FpsReading {
        val sorted = timestamps.asSequence()
            .filter { it in 1_000_000L until Long.MAX_VALUE }
            .distinct()
            .sorted()
            .toList()
        if (sorted.size < 2) {
            return FpsReading(0.0, 0.0, sorted.lastOrNull() ?: previousMaxTs)
        }

        val maxTs = sorted.last()
        val monoNow = System.nanoTime()
        val bootNow = try { SystemClock.elapsedRealtimeNanos() } catch (_: Throwable) { monoNow }

        // 判断缓冲区末尾是否有新帧产生：
        // 1) 与上一轮采样的最大时间戳相比有新帧推进（previousMaxTs > 0 && maxTs > previousMaxTs）
        // 2) 或者最大时间戳在当前 CLOCK_MONOTONIC / CLOCK_BOOTTIME 的 2.5 秒窗口内
        val hasNewFramesSinceLastPoll = previousMaxTs > 0L && maxTs > previousMaxTs
        val matchesMonoClock = kotlin.math.abs(monoNow - maxTs) <= CLOCK_MATCH_TOLERANCE_NS
        val matchesBootClock = kotlin.math.abs(bootNow - maxTs) <= CLOCK_MATCH_TOLERANCE_NS

        if (!hasNewFramesSinceLastPoll && !matchesMonoClock && !matchesBootClock) {
            // 如果既没有新帧推进，也不在当前时钟附近，说明画面完全静止且缓冲区里是旧历史帧
            return FpsReading(0.0, 0.0, maxTs)
        }

        // 若本轮没有新帧产生（maxTs == previousMaxTs），且距离当前时钟已超过 1.1 秒，说明已经停止滑动
        if (previousMaxTs > 0L && maxTs <= previousMaxTs) {
            val ageMono = monoNow - maxTs
            val ageBoot = bootNow - maxTs
            val minAge = minOf(
                if (ageMono >= 0L) ageMono else Long.MAX_VALUE,
                if (ageBoot >= 0L) ageBoot else Long.MAX_VALUE
            )
            if (minAge > 1_100_000_000L) {
                return FpsReading(0.0, 0.0, maxTs)
            }
        }

        // 以缓冲区最新帧 maxTs 为基准向前回溯 1.8 秒窗口，彻底免疫 CLOCK_MONOTONIC 与 CLOCK_BOOTTIME 偏移
        val windowStart = maxTs - FPS_WINDOW_NS
        val recent = sorted.filter { it >= windowStart }
        if (recent.size < 2) return FpsReading(0.0, 0.0, maxTs)

        // 剔除超过 500ms 的长时间停顿间隔，保留连续滑动期间的真实帧间隔
        val intervalsNs = recent.zipWithNext { a, b -> b - a }.filter { it in 500_000L..500_000_000L }
        if (intervalsNs.isEmpty()) return FpsReading(0.0, 0.0, maxTs)

        // 修复 P1-15：分子（intervalsNs.size）与分母（activeSpanSeconds）严格使用相同的过滤后连续帧间隔集合
        val activeSpanSeconds = intervalsNs.sum() / 1_000_000_000.0
        if (activeSpanSeconds < MIN_FPS_SPAN_SECONDS) return FpsReading(0.0, 0.0, maxTs)

        val fps = intervalsNs.size.toDouble() / activeSpanSeconds
        if (fps !in 1.0..MAX_SUPPORTED_FPS) return FpsReading(0.0, 0.0, maxTs)

        val intervalsMs = intervalsNs.map { it / 1_000_000.0 }
        return FpsReading(
            fps = fps,
            jitter = standardDeviation(intervalsMs),
            latestTimestampNs = maxTs
        )
    }

    private fun standardDeviation(values: List<Double>): Double {
        if (values.size < 2) return 0.0
        val mean = values.average()
        val variance = values.sumOf { (it - mean) * (it - mean) } / values.size
        return sqrt(variance)
    }
}
