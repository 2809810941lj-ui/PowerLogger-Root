package com.example.powerlogger

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.max

/**
 * 单应用数据详情页：
 * 根据传入的 sessionId 优先从 Room 数据库读取 SessionRecordEntity 并解析曲线 JSON 渲染图表；
 * 若数据库中不存在则回退读取本地文件 SessionStore。
 */
@Composable
fun SessionDetailScreen(
    sessionId: Long,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var loading by remember(sessionId) { mutableStateOf(true) }
    var sessionState by remember(sessionId) { mutableStateOf<AppSession?>(null) }

    LaunchedEffect(sessionId) {
        loading = true
        val loaded = withContext(Dispatchers.IO) {
            val entity = try {
                AppDatabase.getInstance(context).sessionRecordDao().getById(sessionId)
            } catch (_: Exception) {
                null
            }
            entity?.toAppSession() ?: SessionStore.load(context, sessionId)
        }
        sessionState = loaded
        loading = false
    }

    if (loading) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = AccentBlue)
        }
        return
    }

    val session = sessionState
    if (session == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("记录不存在或已被删除", fontSize = 15.sp, color = Ink)
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onBack) { Text("返回") }
        }
        return
    }

    val stats = remember(session) { session.buildStats() }
    val samples = remember(session) { session.samples.downsample(320) }
    val labels = remember(session) { axisLabels(session.durationMs, 5) }

    var showNoteDialog by remember { mutableStateOf(false) }
    var noteDraft by remember(session.note) { mutableStateOf(session.note) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 28.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, end = 6.dp, top = 6.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                BackGlyph(iconSize = 23.dp, tint = Ink)
            }
            Text(
                text = session.label,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = Ink,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { shareSession(context, session, stats) }) {
                ShareGlyph(iconSize = 19.dp, tint = Ink)
            }
        }

        Column(
            modifier = Modifier.padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(11.dp)
        ) {
            InfoCard(session)

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showNoteDialog = true },
                shape = RoundedCornerShape(14.dp),
                color = Color.White
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = session.note.ifBlank { "未设置备注，点击此处输入" },
                        fontSize = 12.sp,
                        color = if (session.note.isBlank()) InkSoft else Ink,
                        modifier = Modifier.weight(1f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    ChevronGlyph(iconSize = 14.dp)
                }
            }

            SummaryCard(session = session, stats = stats)

            if (samples.size < 2) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = Color.White
                ) {
                    Text(
                        text = "记录时间太短，至少需要 2 个采样点才能绘制曲线。",
                        fontSize = 12.sp,
                        color = InkSoft,
                        modifier = Modifier.padding(18.dp)
                    )
                }
            } else {
                val fpsValues = samples.map { it.fps.toFloat() }
                val temperatureValues = samples.map { it.batteryTemp.toFloat() }
                val frameValues = samples.map { it.frameMs.toFloat() }
                val cpuTotal = samples.map { it.cpuTotal.toFloat() }
                val cpuLittle = samples.map { it.cpuLittle.toFloat() }
                val cpuBig = samples.map { it.cpuBig.toFloat() }
                val freqLittle = samples.map { it.freqLittle.toFloat() }
                val freqBig = samples.map { it.freqBig.toFloat() }
                val gpuValues = samples.map { it.gpuUsage.toFloat() }
                val powerValues = samples.map { it.powerW.toFloat() }
                val capacityValues = samples.map { it.capacity.toFloat() }
                val cpuTempValues = samples.map { it.cpuTemp.toFloat() }

                ChartCard(
                    title = "FPS",
                    trailing = "Temperature(°C)",
                    series = listOf(
                        ChartSeries("FPS", Color(0xFF7C7C82), valuesToPoints(fpsValues), 0),
                        ChartSeries("TEMP(°C)", AccentOrange, valuesToPoints(temperatureValues), 1)
                    ),
                    xLabels = labels,
                    yLeftMax = niceMax(stats.fpsMax, 60.0, 15.0),
                    yRightMax = 60f
                )

                ChartCard(
                    title = "Frame Time(ms)",
                    trailing = String.format(Locale.US, "MAX %.0fms", frameValues.maxOrNull() ?: 0f),
                    series = listOf(
                        ChartSeries("Frame", AccentCyan, valuesToPoints(frameValues), 0)
                    ),
                    xLabels = labels,
                    yLeftMax = niceMax(
                        (frameValues.maxOrNull() ?: 0f).toDouble(),
                        33.0,
                        10.0
                    ),
                    fill = true
                )

                ChartCard(
                    title = "CPU Usage(%)",
                    trailing = "",
                    series = listOf(
                        ChartSeries("Total", AccentCyan, valuesToPoints(cpuTotal), 0),
                        ChartSeries("CPU 0-5", AccentBlue, valuesToPoints(cpuLittle), 0),
                        ChartSeries("CPU 6-7", AccentOrange, valuesToPoints(cpuBig), 0)
                    ),
                    xLabels = labels,
                    yLeftMax = 100f
                )

                ChartCard(
                    title = "CPU Frequency(MHz)",
                    trailing = "",
                    series = listOf(
                        ChartSeries("CPU 0-5", AccentCyan, valuesToPoints(freqLittle), 0),
                        ChartSeries("CPU 6-7", AccentOrange, valuesToPoints(freqBig), 0)
                    ),
                    xLabels = labels,
                    yLeftMax = niceMax(
                        max(
                            frequencyMax(freqLittle),
                            frequencyMax(freqBig)
                        ),
                        2000.0,
                        500.0
                    )
                )

                if (gpuValues.any { it > 0f }) {
                    ChartCard(
                        title = "GPU Usage(%)",
                        trailing = "",
                        series = listOf(
                            ChartSeries("GPU", AccentGreen, valuesToPoints(gpuValues), 0)
                        ),
                        xLabels = labels,
                        yLeftMax = 100f
                    )
                }

                ChartCard(
                    title = "Power(W)",
                    trailing = "Capacity %",
                    series = listOf(
                        ChartSeries("Power(W)", AccentBlue, valuesToPoints(powerValues), 0),
                        ChartSeries("Capacity(%)", AccentCyan, valuesToPoints(capacityValues), 1)
                    ),
                    xLabels = labels,
                    yLeftMax = niceMax(stats.maxPower, 5.0, 1.0),
                    yRightMax = 100f
                )

                if (cpuTempValues.any { it > 0.1f }) {
                    ChartCard(
                        title = "CPU Temperature(°C)",
                        trailing = "",
                        series = listOf(
                            ChartSeries("CPU", AccentOrange, valuesToPoints(cpuTempValues), 0)
                        ),
                        xLabels = labels,
                        yLeftMax = 100f
                    )
                }
            }

            Text(
                text = "共 ${session.samples.size} 个采样点 · 记录时长 " +
                    formatDurationShort(session.durationMs) +
                    " · ${session.packageName}",
                fontSize = 10.sp,
                color = InkSoft,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
            )
        }
    }

    if (showNoteDialog) {
        AlertDialog(
            onDismissRequest = { showNoteDialog = false },
            title = { Text("场景备注") },
            text = {
                OutlinedTextField(
                    value = noteDraft,
                    onValueChange = {
                        if (it.length <= 200) noteDraft = it
                    },
                    placeholder = { Text("例如：王者荣耀 120 帧模式") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    session.note = noteDraft
                    val updatedJson = session.toJson().toString()
                    scope.launch(Dispatchers.IO) {
                        try {
                            AppDatabase.getInstance(context)
                                .sessionRecordDao()
                                .updateNoteAndJson(session.id, noteDraft, updatedJson)
                        } catch (_: Exception) {
                        }
                        SessionStore.save(context, session)
                    }
                    sessionState = session.copy(note = noteDraft)
                    showNoteDialog = false
                }) {
                    Text("保存")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNoteDialog = false }) { Text("取消") }
            }
        )
    }
}

@Composable
private fun InfoCard(session: AppSession) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = Color.White
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            InfoCell(
                icon = { ChipGlyph(iconSize = 22.dp, tint = Color(0xFF6C63FF)) },
                label = "Platform",
                value = session.soc.ifBlank { "--" },
                modifier = Modifier.weight(1f)
            )
            InfoCell(
                icon = { PhoneGlyph(iconSize = 22.dp, tint = Color(0xFF3B82F6)) },
                label = "Model",
                value = session.model.ifBlank { "--" },
                modifier = Modifier.weight(1f)
            )
            InfoCell(
                icon = { AndroidGlyph(iconSize = 22.dp, tint = Color(0xFF34C77B)) },
                label = "OS",
                value = session.os.ifBlank { "--" },
                modifier = Modifier.weight(1f)
            )
            InfoCell(
                icon = { ProfileGlyph(iconSize = 22.dp, tint = Color(0xFFF2994A)) },
                label = "Profile",
                value = "Root",
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun InfoCell(
    icon: @Composable () -> Unit,
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        icon()
        Spacer(Modifier.height(4.dp))
        Text(text = label, fontSize = 9.sp, color = InkSoft)
        Spacer(Modifier.height(1.dp))
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = Ink,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun SummaryCard(session: AppSession, stats: SessionStats) {
    val context = LocalContext.current
    val metrics = context.resources.displayMetrics
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = Color.White
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(packageName = session.packageName, size = 34.dp)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = formatDateTime(session.startTime),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Ink
                    )
                    Text(
                        text = "${session.packageName} / ${session.activity}",
                        fontSize = 9.sp,
                        color = InkSoft,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    text = "cpu: ${metrics.widthPixels}×${metrics.heightPixels}",
                    fontSize = 9.sp,
                    color = InkSoft
                )
            }

            Spacer(Modifier.height(12.dp))

            Row(Modifier.fillMaxWidth()) {
                SummaryStat(
                    caption = "MAX",
                    value = fpsText(stats.fpsMax),
                    unit = "FPS",
                    modifier = Modifier.weight(1f)
                )
                SummaryStat(
                    caption = "MIN",
                    value = fpsText(stats.fpsMin),
                    unit = "FPS",
                    modifier = Modifier.weight(1f)
                )
                SummaryStat(
                    caption = "AVG",
                    value = fpsText(stats.fpsAvg),
                    unit = "FPS",
                    modifier = Modifier.weight(1f)
                )
                SummaryStat(
                    caption = "JITTER",
                    value = String.format(Locale.US, "%.1f%%", stats.jitterPercent),
                    unit = "",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(11.dp))

            Row(Modifier.fillMaxWidth()) {
                SummaryStat(
                    caption = "5% LOW",
                    value = fpsText(stats.low5),
                    unit = "FPS",
                    modifier = Modifier.weight(1f)
                )
                SummaryStat(
                    caption = "AVG SOC",
                    value = String.format(Locale.US, "%.1f%%", stats.avgSoc),
                    unit = "",
                    modifier = Modifier.weight(1f)
                )
                SummaryStat(
                    caption = "MAX battery",
                    value = String.format(Locale.US, "%.1f", stats.maxBatteryTemp),
                    unit = "°C",
                    modifier = Modifier.weight(1f)
                )
                SummaryStat(
                    caption = "AVG Power",
                    value = String.format(Locale.US, "%.2f", stats.avgPower),
                    unit = "W",
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun SummaryStat(
    caption: String,
    value: String,
    unit: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = caption, fontSize = 9.sp, color = InkSoft, maxLines = 1)
        Text(
            text = value,
            fontSize = 21.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1F6FE5),
            maxLines = 1
        )
        if (unit.isNotEmpty()) {
            Text(text = unit, fontSize = 9.sp, color = InkSoft)
        }
    }
}

private fun fpsText(value: Double): String {
    return if (value <= 0.0) "--" else String.format(Locale.US, "%.1f", value)
}

private fun frequencyMax(values: List<Float>): Double {
    return (values.maxOrNull() ?: 0f).toDouble()
}

private fun shareSession(context: Context, session: AppSession, stats: SessionStats) {
    val text = buildString {
        appendLine("${session.label} 场景记录")
        appendLine(formatDateTime(session.startTime))
        appendLine(
            String.format(
                Locale.US,
                "FPS  MAX %.1f  MIN %.1f  AVG %.1f  JITTER %.1f%%",
                stats.fpsMax,
                stats.fpsMin,
                stats.fpsAvg,
                stats.jitterPercent
            )
        )
        appendLine(
            String.format(
                Locale.US,
                "5%% LOW %.1f   AVG SOC %.1f%%   MAX battery %.1f°C",
                stats.low5,
                stats.avgSoc,
                stats.maxBatteryTemp
            )
        )
        appendLine(String.format(Locale.US, "AVG Power %.2fW", stats.avgPower))
        append("由 PowerLogger 记录")
    }
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    try {
        context.startActivity(Intent.createChooser(intent, "分享场景数据"))
    } catch (_: Exception) {
    }
}
