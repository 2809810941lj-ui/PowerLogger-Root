package com.example.powerlogger

import android.content.Context
import android.util.Log
import kotlin.math.abs
import kotlin.math.min

data class ForegroundApp(
    val packageName: String,
    val activity: String
)

/**
 * 通过常驻 su shell 采集前台应用、多源 FPS（SurfaceFlinger latency + SurfaceFlinger TimeStats + gfxinfo framestats）、
 * CPU/GPU、温度和电池数据。
 */
class SceneSampler(private val context: Context) {

    private val coreCount: Int = Runtime.getRuntime().availableProcessors().coerceIn(1, 16)

    private var focusPackage: String = ""
    private var focusActivity: String = ""
    private var focusAt: Long = 0L
    private var emptyFocusCount: Int = 0

    private var layerCandidates: List<String> = emptyList()
    private var layerPackage: String = ""
    private var layerActivity: String = ""
    private var layerAt: Long = 0L

    // 增量帧时间戳追踪，解决休眠后 CLOCK_MONOTONIC 与 CLOCK_BOOTTIME 偏移导致 FPS 恒为 0 的问题
    private val layerMaxTimestampMap = HashMap<String, Long>()
    private var gfxLastMaxTimestampNs: Long = 0L
    private var timeStatsEnabled: Boolean = false

    var lastFpsSource: String = "未采集"
        private set

    private var clustersReady = false
    private var littleCores: List<Int> = (0 until min(6, coreCount)).toList()
    private var bigCores: List<Int> = if (coreCount > 6) (6 until coreCount).toList() else emptyList()
    var littleLabel: String = "CPU 0-5"
        private set
    var bigLabel: String = "CPU 6-7"
        private set

    private var lastTotal: Long = -1L
    private var lastIdle: Long = -1L
    private var lastCoreTotal: LongArray = LongArray(0)
    private var lastCoreIdle: LongArray = LongArray(0)

    private var lastGpuBusy: Long = -1L
    private var lastGpuTotal: Long = -1L

    private var thermalReady = false
    private var cpuZone: String? = null
    private var gpuZone: String? = null
    private var batteryZone: String? = null

    private var cachedCpuTemp = 0.0
    private var cachedGpuTemp = 0.0

    fun currentForeground(): ForegroundApp {
        val now = System.currentTimeMillis()
        if (focusPackage.isEmpty() || now - focusAt > 650L) {
            refreshForeground()
        }
        return ForegroundApp(focusPackage, focusActivity)
    }

    fun foregroundNow(): ForegroundApp {
        refreshForeground()
        return ForegroundApp(focusPackage, focusActivity)
    }

    fun resetLayerCache() {
        layerCandidates = emptyList()
        layerPackage = ""
        layerActivity = ""
        layerAt = 0L
        layerMaxTimestampMap.clear()
        gfxLastMaxTimestampNs = 0L
    }

    private fun ensureTimeStatsEnabled() {
        if (timeStatsEnabled) return
        timeStatsEnabled = true
        RootShell.exec("dumpsys SurfaceFlinger --timestats -enable -clear 2>/dev/null", 3_000L)
    }

    /**
     * 修复原先 `grep -m1` 被第一行 `mCurrentFocus=null` 截断导致读不到 `mFocusedApp` 的严重 Bug。
     */
    private fun refreshForeground() {
        val output = RootShell.exec(
            "dumpsys window 2>/dev/null | grep -E 'mCurrentFocus|mFocusedApp'; " +
                "dumpsys activity activities 2>/dev/null | grep -E 'topResumedActivity|mResumedActivity' | head -6"
        ) ?: ""

        val pattern = Regex("([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+)+)/([A-Za-z0-9_.$]+)")
        val candidates = ArrayList<ForegroundApp>()

        for (rawLine in output.lineSequence()) {
            val line = rawLine.trim()
            if (line.isEmpty() || line.contains("=null")) continue
            val match = pattern.find(line) ?: continue
            val pkg = match.groupValues[1]
            val act = match.groupValues[2]
            if (pkg == "com.android.systemui" || pkg == "android") continue
            candidates.add(ForegroundApp(pkg, act))
        }

        val chosen = candidates.firstOrNull()
        val newPackage = chosen?.packageName ?: ""
        val newActivity = chosen?.activity ?: ""

        if (newPackage.isEmpty()) {
            emptyFocusCount++
            // 修复 P1-16：连续 2 次无法识别前台焦点时清空旧包名，防止将未知窗口的数据归属给上一个应用
            if (emptyFocusCount >= 2) {
                focusPackage = ""
                focusActivity = ""
                layerCandidates = emptyList()
            }
        } else {
            emptyFocusCount = 0
            if (newPackage != focusPackage) {
                layerCandidates = emptyList()
                layerPackage = ""
                layerActivity = ""
                layerAt = 0L
                layerMaxTimestampMap.clear()
                gfxLastMaxTimestampNs = 0L
            }
            focusPackage = newPackage
            focusActivity = newActivity
        }
        focusAt = System.currentTimeMillis()
    }

    private fun discoverLayers(pkg: String, activity: String): List<String> {
        if (pkg.isEmpty()) return emptyList()
        val now = System.currentTimeMillis()
        val cacheTtl = if (layerCandidates.isEmpty()) 1_200L else 5_000L
        if (pkg == layerPackage && activity == layerActivity && now - layerAt < cacheTtl) {
            return layerCandidates
        }

        val quotedPackage = shellQuote(pkg)
        var output = RootShell.exec(
            "dumpsys SurfaceFlinger --list 2>/dev/null | grep -F $quotedPackage | head -80"
        ) ?: ""
        if (output.isBlank()) {
            output = RootShell.exec(
                "dumpsys SurfaceFlinger --list --all 2>/dev/null | grep -F $quotedPackage | head -80"
            ) ?: ""
        }

        val rawCandidates = output.lineSequence()
            .mapNotNull { FpsFrameParser.normalizeLayerName(it) }
            .filter { it.contains(pkg) }
            .filter {
                !it.contains("Background", ignoreCase = true) &&
                    !it.contains("Splash", ignoreCase = true) &&
                    !it.contains("Bounds for", ignoreCase = true) &&
                    !it.contains("Snapshot", ignoreCase = true) &&
                    !it.contains("Starting", ignoreCase = true) &&
                    !it.contains("Magnification", ignoreCase = true)
            }
            .distinct()
            .sortedBy { name ->
                when {
                    name.contains("SurfaceView", ignoreCase = true) && name.contains("BLAST", ignoreCase = true) -> 0
                    name.contains("SurfaceView", ignoreCase = true) -> 1
                    name.contains("BLAST", ignoreCase = true) -> 2
                    name.endsWith("#0") -> 3
                    else -> 4
                }
            }
            .toList()

        // 同时保留带 #序号 和去掉 #序号 的候选名（兼容不同 Android 版本 SurfaceFlinger --latency 匹配规则）
        val expanded = LinkedHashSet<String>()
        for (item in rawCandidates) {
            expanded.add(item)
            if (item.contains('#')) {
                val stripped = item.substringBeforeLast('#').trim()
                if (stripped.isNotEmpty()) expanded.add(stripped)
            }
            if (expanded.size >= MAX_LAYER_CANDIDATES) break
        }

        if (activity.isNotEmpty() && expanded.size < MAX_LAYER_CANDIDATES) {
            val fullActivity = if (activity.startsWith(".")) pkg + activity else activity
            expanded.add("$pkg/$fullActivity#0")
            expanded.add("$pkg/$fullActivity")
            expanded.add("SurfaceView[$pkg/$fullActivity](BLAST)#0")
            expanded.add("SurfaceView[$pkg/$fullActivity]#0")
        }

        layerCandidates = expanded.take(MAX_LAYER_CANDIDATES)
        layerPackage = pkg
        layerActivity = activity
        layerAt = now
        return layerCandidates
    }

    private fun ensureClusters() {
        if (clustersReady) return
        val indices = (0 until coreCount).joinToString(" ")
        val command = "for i in $indices; do echo \"F\$i \$(cat /sys/devices/system/cpu/cpu\$i/cpufreq/cpuinfo_max_freq 2>/dev/null)\"; done"
        val output = RootShell.exec(command) ?: ""
        val frequencies = HashMap<Int, Long>()
        output.lineSequence().forEach { line ->
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size >= 2 && parts[0].startsWith("F")) {
                val index = parts[0].substring(1).toIntOrNull() ?: return@forEach
                val value = parts[1].toLongOrNull() ?: return@forEach
                if (value > 0L) frequencies[index] = value
            }
        }

        val maxFrequency = frequencies.values.maxOrNull() ?: 0L
        if (maxFrequency > 0L && frequencies.size >= 2) {
            val big = frequencies.filter { it.value >= maxFrequency * 0.95 }.keys.sorted()
            val little = (0 until coreCount).filter { it !in big }
            if (big.isNotEmpty() && little.isNotEmpty()) {
                bigCores = big
                littleCores = little
            }
        }

        littleLabel = clusterLabel(littleCores, "CPU")
        bigLabel = if (bigCores.isEmpty()) "" else clusterLabel(bigCores, "CPU")
        clustersReady = true
    }

    private fun clusterLabel(cores: List<Int>, prefix: String): String {
        if (cores.isEmpty()) return prefix
        val first = cores.first()
        val last = cores.last()
        return if (last - first + 1 == cores.size) "$prefix $first-$last" else "$prefix 小核"
    }

    private fun ensureThermal() {
        if (thermalReady) return
        val command = "for z in /sys/class/thermal/thermal_zone*; do echo \"\$z \$(cat \$z/type 2>/dev/null)\"; done"
        val output = RootShell.exec(command) ?: return
        var cpu: String? = null
        var gpu: String? = null
        var battery: String? = null
        output.lineSequence().forEach { line ->
            val split = line.trim().indexOf(' ')
            if (split <= 0) return@forEach
            val path = line.trim().substring(0, split)
            val type = line.trim().substring(split + 1).trim().lowercase()
            when {
                type == "cpu-0-0" || type == "cpu-0-1" -> cpu = path
                type.contains("gpuss") || type.contains("gpu") -> if (gpu == null) gpu = path
                type.contains("batt") -> if (battery == null) battery = path
                type.contains("cpu") || type.contains("soc") -> if (cpu == null) cpu = path
            }
        }
        cpuZone = cpu
        gpuZone = gpu
        batteryZone = battery
        thermalReady = true
    }

    fun sample(collectDetails: Boolean): SceneSample? {
        ensureTimeStatsEnabled()
        val foreground = currentForeground()
        val pkg = foreground.packageName
        val activeLayers = if (pkg.isNotEmpty()) {
            discoverLayers(pkg, foreground.activity)
        } else {
            emptyList()
        }

        if (collectDetails) {
            ensureClusters()
            ensureThermal()
        }

        val command = buildCommand(pkg, activeLayers, collectDetails)
        val output = RootShell.exec(command) ?: return null
        val battery = readBatterySnapshot(context)

        val voltageRaw = firstNumber(section(output, "VOL"))
        val currentRaw = firstNumber(section(output, "CUR"))
        val voltageMv = when {
            voltageRaw != null && abs(voltageRaw) > 100_000.0 -> (abs(voltageRaw) / 1000.0).toInt()
            voltageRaw != null && abs(voltageRaw) > 1000.0 -> abs(voltageRaw).toInt()
            else -> battery.voltageMv
        }
        val currentMa = if (currentRaw != null) {
            abs(currentRaw) / 1000.0
        } else {
            abs(battery.currentMa)
        }
        val powerW = voltageMv * currentMa / 1_000_000.0

        var cpuTotal = 0.0
        var cpuLittle = 0.0
        var cpuBig = 0.0
        var freqLittle = 0.0
        var freqBig = 0.0
        var gpuUsage = 0.0
        var gpuFrequency = 0.0
        var cpuTemp = cachedCpuTemp
        var gpuTemp = cachedGpuTemp
        var batteryTemp = battery.tempC

        if (collectDetails) {
            val previousCoreTotal = lastCoreTotal.copyOf()
            val previousCoreIdle = lastCoreIdle.copyOf()
            val cpu = parseCpu(section(output, "CPU"))
            cpuTotal = cpu.totalUsage
            cpuLittle = clusterUsage(cpu.coreTotal, cpu.coreIdle, previousCoreTotal, previousCoreIdle, littleCores)
            cpuBig = clusterUsage(cpu.coreTotal, cpu.coreIdle, previousCoreTotal, previousCoreIdle, bigCores)

            val frequencies = parseFrequencies(section(output, "FREQ"))
            freqLittle = averageFrequency(frequencies, littleCores)
            freqBig = averageFrequency(frequencies, bigCores)

            val gpu = parseGpu(section(output, "GPU"))
            gpuUsage = gpu.first
            gpuFrequency = gpu.second

            val temperatures = parseTemperatures(section(output, "TEMP"))
            cpuTemp = temperatures["TCPU"] ?: cachedCpuTemp
            gpuTemp = temperatures["TGPU"] ?: cachedGpuTemp
            val sysBatteryTemp = temperatures["TBAT"]
            if (sysBatteryTemp != null && sysBatteryTemp > 0.0) batteryTemp = sysBatteryTemp

            cachedCpuTemp = cpuTemp
            cachedGpuTemp = gpuTemp
        }

        // 1. 尝试从 SurfaceFlinger --latency 解析各候选图层帧率（带增量时间戳跟踪）
        var bestLatencyReading: FpsReading? = null
        activeLayers.forEachIndexed { index, layerName ->
            val prevMax = layerMaxTimestampMap[layerName] ?: 0L
            val reading = FpsFrameParser.parseSurfaceFlingerLatency(section(output, "LAT$index"), prevMax)
            if (reading.latestTimestampNs > prevMax) {
                layerMaxTimestampMap[layerName] = reading.latestTimestampNs
            }
            if (reading.fps > (bestLatencyReading?.fps ?: 0.0)) {
                bestLatencyReading = reading
            }
        }

        // 在同一次批处理命令输出中按严格优先级解析（SurfaceFlinger Latency -> gfxinfo framestats -> SurfaceFlinger TimeStats），
        // 避免分 3 次进入 RootShell.lock 排队造成悬浮窗刷新卡顿。
        val gfxReading = if (pkg.isNotEmpty()) {
            val r = FpsFrameParser.parseGfxInfoFrameStats(section(output, "GFX"), gfxLastMaxTimestampNs)
            if (r.latestTimestampNs > gfxLastMaxTimestampNs) {
                gfxLastMaxTimestampNs = r.latestTimestampNs
            }
            r
        } else {
            FpsReading(0.0, 0.0)
        }

        val timeStatsReading = if (pkg.isNotEmpty()) {
            FpsFrameParser.parseSurfaceFlingerTimeStats(section(output, "TSTATS"), pkg)
        } else {
            FpsReading(0.0, 0.0)
        }

        val chosenReading: FpsReading
        when {
            bestLatencyReading != null && bestLatencyReading!!.fps > 0.0 -> {
                chosenReading = bestLatencyReading!!
                lastFpsSource = "SurfaceFlinger Latency"
            }
            gfxReading.fps > 0.0 -> {
                chosenReading = gfxReading
                lastFpsSource = "gfxinfo framestats"
            }
            timeStatsReading.fps > 0.0 -> {
                chosenReading = timeStatsReading
                lastFpsSource = "SurfaceFlinger TimeStats"
            }
            else -> {
                chosenReading = FpsReading(0.0, 0.0)
                lastFpsSource = if (pkg.isEmpty()) "未识别到前台包名" else "当前画面静止（无新增帧提交）"
            }
        }

        val fps = chosenReading.fps
        val jitter = chosenReading.jitter

        return SceneSample(
            time = System.currentTimeMillis(),
            fps = fps,
            frameMs = if (fps > 0.0) 1000.0 / fps else 0.0,
            jitter = jitter,
            cpuTotal = cpuTotal,
            cpuLittle = cpuLittle,
            cpuBig = cpuBig,
            freqLittle = freqLittle,
            freqBig = freqBig,
            gpuUsage = gpuUsage,
            gpuFreq = gpuFrequency,
            powerW = powerW,
            capacity = battery.level,
            cpuTemp = cpuTemp,
            gpuTemp = gpuTemp,
            batteryTemp = batteryTemp,
            voltageMv = voltageMv,
            charging = battery.charging
        )
    }

    /**
     * 将电压电流、CPU/GPU/温度、SurfaceFlinger latency、SurfaceFlinger timestats 与 gfxinfo framestats
     * 全部合并进同一次 su shell 批处理命令中执行，既保证所有应用都能读到 FPS，又避免多次唤醒进程。
     */
    private fun buildCommand(
        foregroundPkg: String,
        activeLayers: List<String>,
        collectDetails: Boolean
    ): String {
        val builder = StringBuilder()
        builder.append("echo '#CUR'; cat /sys/class/power_supply/battery/current_now 2>/dev/null\n")
        builder.append("echo '#VOL'; cat /sys/class/power_supply/battery/voltage_now 2>/dev/null\n")

        if (collectDetails) {
            builder.append("echo '#CPU'; cat /proc/stat 2>/dev/null\n")
            val indices = (0 until coreCount).joinToString(" ")
            builder.append(
                "echo '#FREQ'; for i in $indices; do echo \"F\$i \$(cat /sys/devices/system/cpu/cpu\$i/cpufreq/scaling_cur_freq 2>/dev/null)\"; done\n"
            )
            builder.append(
                "echo '#GPU'; cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null; " +
                    "cat /sys/class/kgsl/kgsl-3d0/gpuclk 2>/dev/null; " +
                    "cat /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq 2>/dev/null; " +
                    "cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage 2>/dev/null\n"
            )
            builder.append("echo '#TEMP'\n")
            cpuZone?.let {
                builder.append("echo \"TCPU \$(cat ${shellQuote("$it/temp")} 2>/dev/null)\"\n")
            }
            gpuZone?.let {
                builder.append("echo \"TGPU \$(cat ${shellQuote("$it/temp")} 2>/dev/null)\"\n")
            }
            batteryZone?.let {
                builder.append("echo \"TBAT \$(cat ${shellQuote("$it/temp")} 2>/dev/null)\"\n")
            }
        }

        activeLayers.forEachIndexed { index, activeLayer ->
            builder.append("echo '#LAT$index'; dumpsys SurfaceFlinger --latency ${shellQuote(activeLayer)} 2>/dev/null\n")
        }

        if (foregroundPkg.isNotEmpty()) {
            builder.append("echo '#GFX'; dumpsys gfxinfo ${shellQuote(foregroundPkg)} framestats 2>/dev/null\n")
            builder.append("echo '#TSTATS'; dumpsys SurfaceFlinger --timestats -dump 2>/dev/null\n")
        }

        return builder.toString()
    }

    private fun section(output: String, name: String): String {
        val marker = "#$name"
        val start = output.indexOf(marker)
        if (start < 0) return ""
        val lineEnd = output.indexOf('\n', start)
        val from = if (lineEnd < 0) output.length else lineEnd + 1
        val next = output.indexOf("\n#", from)
        return if (next < 0) output.substring(from) else output.substring(from, next)
    }

    private fun firstNumber(text: String): Double? {
        return text.lineSequence()
            .map { it.trim() }
            .mapNotNull { it.toDoubleOrNull() }
            .firstOrNull()
    }

    private data class CpuResult(
        val totalUsage: Double,
        val coreTotal: LongArray,
        val coreIdle: LongArray
    )

    private fun parseCpu(text: String): CpuResult {
        val lines = text.lineSequence().map { it.trim() }.filter { it.startsWith("cpu") }.toList()
        if (lines.isEmpty()) return CpuResult(0.0, LongArray(coreCount), LongArray(coreCount))

        var aggregateTotal = 0L
        var aggregateIdle = 0L
        val coreTotal = LongArray(coreCount)
        val coreIdle = LongArray(coreCount)

        lines.forEach { line ->
            val parts = line.split(Regex("\\s+"))
            if (parts.size < 5) return@forEach
            val isAggregate = parts[0] == "cpu"
            val coreIndex = if (isAggregate) -1 else parts[0].removePrefix("cpu").toIntOrNull() ?: -1
            if (!isAggregate && (coreIndex < 0 || coreIndex >= coreCount)) return@forEach
            var total = 0L
            var idle = 0L
            for (i in 1 until parts.size) {
                val value = parts[i].toLongOrNull() ?: continue
                total += value
                if (i == 4 || i == 5) idle += value
            }
            if (isAggregate) {
                aggregateTotal = total
                aggregateIdle = idle
            } else {
                coreTotal[coreIndex] = total
                coreIdle[coreIndex] = idle
            }
        }

        if (lastTotal < 0L) {
            lastTotal = aggregateTotal
            lastIdle = aggregateIdle
            lastCoreTotal = coreTotal
            lastCoreIdle = coreIdle
            return CpuResult(0.0, coreTotal, coreIdle)
        }

        val deltaTotal = aggregateTotal - lastTotal
        val deltaIdle = aggregateIdle - lastIdle
        val usage = if (deltaTotal > 0L) {
            (100.0 * (deltaTotal - deltaIdle) / deltaTotal.toDouble()).coerceIn(0.0, 100.0)
        } else {
            0.0
        }

        lastTotal = aggregateTotal
        lastIdle = aggregateIdle
        lastCoreTotal = coreTotal
        lastCoreIdle = coreIdle
        return CpuResult(usage, coreTotal, coreIdle)
    }

    private fun clusterUsage(
        coreTotal: LongArray,
        coreIdle: LongArray,
        previousTotal: LongArray,
        previousIdle: LongArray,
        cores: List<Int>
    ): Double {
        if (cores.isEmpty()) return 0.0
        var total = 0L
        var idle = 0L
        var valid = false
        cores.forEach { index ->
            if (index in coreTotal.indices && index in previousTotal.indices && previousTotal[index] > 0L) {
                val deltaTotal = coreTotal[index] - previousTotal[index]
                val deltaIdle = coreIdle[index] - previousIdle[index]
                if (deltaTotal > 0L) {
                    total += deltaTotal
                    idle += deltaIdle
                    valid = true
                }
            }
        }
        if (!valid || total <= 0L) return 0.0
        return (100.0 * (total - idle) / total.toDouble()).coerceIn(0.0, 100.0)
    }

    private fun parseFrequencies(text: String): Map<Int, Double> {
        val result = HashMap<Int, Double>()
        text.lineSequence().forEach { line ->
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size >= 2 && parts[0].startsWith("F")) {
                val index = parts[0].substring(1).toIntOrNull() ?: return@forEach
                val value = parts[1].toDoubleOrNull() ?: return@forEach
                if (value > 0.0) result[index] = value
            }
        }
        return result
    }

    private fun averageFrequency(frequencies: Map<Int, Double>, cores: List<Int>): Double {
        if (cores.isEmpty()) return 0.0
        var sum = 0.0
        var count = 0
        cores.forEach { index ->
            val value = frequencies[index]
            if (value != null && value > 0.0) {
                sum += value
                count++
            }
        }
        return if (count == 0) 0.0 else sum / count / 1000.0
    }

    private fun parseGpu(text: String): Pair<Double, Double> {
        var busy = -1L
        var total = -1L
        var percent = -1.0
        var frequency = 0.0

        text.lineSequence().forEach { line ->
            val trimmed = line.trim()
            if (trimmed.isEmpty()) return@forEach
            val parts = trimmed.split(Regex("\\s+"))
            when {
                parts.size >= 2 && parts[0].toLongOrNull() != null && parts[1].toLongOrNull() != null -> {
                    busy = parts[0].toLong()
                    total = parts[1].toLong()
                }
                trimmed.endsWith("%") -> {
                    percent = trimmed.removeSuffix("%").trim().toDoubleOrNull() ?: percent
                }
                parts.size == 1 -> {
                    val value = parts[0].toDoubleOrNull() ?: return@forEach
                    if (value > 1_000_000.0) {
                        frequency = value / 1_000_000.0
                    } else if (value in 0.0..100.0) {
                        percent = value
                    }
                }
            }
        }

        var usage = 0.0
        when {
            percent >= 0.0 -> usage = percent.coerceIn(0.0, 100.0)
            busy >= 0L && total >= 0L && lastGpuBusy >= 0L && lastGpuTotal >= 0L -> {
                val deltaBusy = busy - lastGpuBusy
                val deltaTotal = total - lastGpuTotal
                if (deltaTotal > 0L && deltaBusy >= 0L) {
                    usage = (100.0 * deltaBusy / deltaTotal.toDouble()).coerceIn(0.0, 100.0)
                }
            }
        }
        if (busy >= 0L && total >= 0L) {
            lastGpuBusy = busy
            lastGpuTotal = total
        }
        return usage to frequency
    }

    private fun parseTemperatures(text: String): Map<String, Double> {
        val result = HashMap<String, Double>()
        text.lineSequence().forEach { line ->
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size >= 2) {
                val key = parts[0]
                val raw = parts[1].toDoubleOrNull() ?: return@forEach
                if (raw > 0.0) {
                    result[key] = if (raw > 1000.0) raw / 1000.0 else raw
                }
            }
        }
        return result
    }

    /** 主界面“环境自检”使用，返回一段可直接展示的文本。 */
    fun diagnose(): String {
        if (!RootShell.acquire()) return "Root 不可用：请在 Magisk/KernelSU 中授权 PowerLogger。"
        val builder = StringBuilder()
        try {
            ensureTimeStatsEnabled()
            val foreground = foregroundNow()
            builder.append("前台应用: ")
                .append(foreground.packageName.ifEmpty { "未知" })
                .append(" / ")
                .append(foreground.activity.ifEmpty { "-" })
                .append('\n')

            val activeLayers = discoverLayers(foreground.packageName, foreground.activity)
            builder.append("\n候选 Layer (${activeLayers.size} 个):\n")
            if (activeLayers.isEmpty()) builder.append("无\n")
            activeLayers.forEachIndexed { index, activeLayer ->
                builder.append(index).append(". ").append(activeLayer).append('\n')
            }

            val liveSample = sample(collectDetails = true)
            builder.append("\n实时 FPS: ")
                .append(liveSample?.fps?.let { String.format("%.1f", it) } ?: "读取失败")
                .append("\nFPS 数据来源: ").append(lastFpsSource).append('\n')

            ensureClusters()
            ensureThermal()
            builder.append("\nCPU 簇: ").append(littleLabel).append(" / ")
                .append(if (bigLabel.isEmpty()) "单簇" else bigLabel).append('\n')
            builder.append("温度节点: CPU=").append(cpuZone ?: "无")
                .append(" GPU=").append(gpuZone ?: "无")
                .append(" BAT=").append(batteryZone ?: "无").append('\n')

            val battery = readBatterySnapshot(context)
            builder.append("\n电量 ").append(battery.level)
                .append("%  ").append(String.format("%.1f", battery.tempC)).append("°C  ")
                .append(battery.voltageMv).append("mV")
        } catch (error: Throwable) {
            Log.w(TAG, "diagnose failed", error)
            builder.append("\n自检失败: ").append(error.message ?: error.javaClass.simpleName)
        } finally {
            RootShell.release()
        }
        return builder.toString()
    }

    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"

    companion object {
        private const val TAG = "PowerLogger-Sampler"
        private const val MAX_LAYER_CANDIDATES = 8
    }
}
