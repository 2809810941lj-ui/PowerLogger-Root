package com.example.powerlogger

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppLogEntry(
    val time: Long,
    val level: String, // "INFO", "WARN", "ERROR", "CRASH"
    val tag: String,
    val message: String
)

/**
 * 全局运行与崩溃日志管理器 + 自启动设置引导工具：
 * 1. 自动注册 Thread.UncaughtExceptionHandler，任何闪退都会将完整调用栈落盘到 app_debug_logs.txt；
 * 2. 支持抓取本应用进程的系统 logcat (main + crash 缓冲区)，方便实时排查 Bug；
 * 3. 提供一键开启 Root 后台白名单与跳转各品牌 ROM 自启动管理页。
 */
object AppLogManager {
    private const val LOG_FILE_NAME = "app_debug_logs.txt"
    private const val MAX_MEMORY_LOGS = 250
    private const val MAX_FILE_BYTES = 256 * 1024L

    private val lock = Any()
    private var initialized = false
    private var appContext: Context? = null
    private var defaultHandler: Thread.UncaughtExceptionHandler? = null

    private val mutableLogs = MutableStateFlow<List<AppLogEntry>>(emptyList())
    val logs: StateFlow<List<AppLogEntry>> = mutableLogs.asStateFlow()

    fun init(context: Context) {
        synchronized(lock) {
            if (initialized) return
            initialized = true
            appContext = context.applicationContext
            loadPersistedLogs(context.applicationContext)
            installUncaughtExceptionHandler(context.applicationContext)
            i("AppInit", "PowerLogger 日志与防崩诊断系统已启动 (Android ${Build.VERSION.RELEASE}, ${Build.MANUFACTURER} ${Build.MODEL})")
        }
    }

    private fun installUncaughtExceptionHandler(context: Context) {
        defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                val pw = PrintWriter(sw)
                throwable.printStackTrace(pw)
                pw.flush()
                val stackTrace = sw.toString()
                val entry = AppLogEntry(
                    time = System.currentTimeMillis(),
                    level = "CRASH",
                    tag = "Thread-${thread.name}",
                    message = "${throwable.javaClass.name}: ${throwable.message}\n$stackTrace"
                )
                appendEntryInternal(context, entry, flushImmediately = true)
            } catch (_: Throwable) {
            } finally {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }

    fun i(tag: String, message: String) {
        Log.i(tag, message)
        record("INFO", tag, message)
    }

    fun w(tag: String, message: String, tr: Throwable? = null) {
        Log.w(tag, message, tr)
        val full = if (tr != null) "$message\n${Log.getStackTraceString(tr)}" else message
        record("WARN", tag, full)
    }

    fun e(tag: String, message: String, tr: Throwable? = null) {
        Log.e(tag, message, tr)
        val full = if (tr != null) "$message\n${Log.getStackTraceString(tr)}" else message
        record("ERROR", tag, full)
    }

    private fun record(level: String, tag: String, message: String) {
        val ctx = appContext ?: return
        val entry = AppLogEntry(
            time = System.currentTimeMillis(),
            level = level,
            tag = tag,
            message = message
        )
        synchronized(lock) {
            appendEntryInternal(ctx, entry, flushImmediately = level == "ERROR" || level == "CRASH")
        }
    }

    private fun appendEntryInternal(context: Context, entry: AppLogEntry, flushImmediately: Boolean) {
        val updated = (mutableLogs.value + entry).takeLast(MAX_MEMORY_LOGS)
        mutableLogs.value = updated
        try {
            val file = logFile(context)
            if (file.exists() && file.length() > MAX_FILE_BYTES) {
                val tailText = file.readText().takeLast((MAX_FILE_BYTES / 2).toInt())
                file.writeText(tailText)
            }
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(entry.time))
            val sanitizedMsg = entry.message.replace("\r\n", "\n")
            val block = "[$stamp] [${entry.level}] [${entry.tag}] $sanitizedMsg\n---\n"
            file.appendText(block)
        } catch (_: Throwable) {
        }
    }

    private fun loadPersistedLogs(context: Context) {
        try {
            val file = logFile(context)
            if (!file.exists()) return
            val raw = file.readText()
            val blocks = raw.split("\n---\n").filter { it.isNotBlank() }
            val parsed = ArrayList<AppLogEntry>()
            val headerRegex = Regex("""^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3})\] \[([A-Z]+)\] \[([^\]]+)\] (.*)$""", RegexOption.DOT_MATCHES_ALL)
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
            for (b in blocks.takeLast(MAX_MEMORY_LOGS)) {
                val m = headerRegex.find(b.trim())
                if (m != null) {
                    val t = try { sdf.parse(m.groupValues[1])?.time ?: 0L } catch (_: Throwable) { 0L }
                    parsed.add(
                        AppLogEntry(
                            time = t,
                            level = m.groupValues[2],
                            tag = m.groupValues[3],
                            message = m.groupValues[4]
                        )
                    )
                }
            }
            mutableLogs.value = parsed
        } catch (_: Throwable) {
        }
    }

    fun clearLogs(context: Context) {
        synchronized(lock) {
            mutableLogs.value = emptyList()
            try {
                logFile(context).delete()
            } catch (_: Throwable) {
            }
        }
        i("LogManager", "日志已手动清空")
    }

    fun exportAllText(context: Context): String {
        val list = mutableLogs.value
        if (list.isEmpty()) return "暂无日志记录"
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
        val sb = StringBuilder()
        sb.appendLine("=== PowerLogger 诊断日志 ===")
        sb.appendLine("设备: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE}, SDK ${Build.VERSION.SDK_INT})")
        sb.appendLine("导出时间: ${sdf.format(Date())}")
        sb.appendLine("==========================")
        for (item in list.asReversed()) {
            sb.appendLine("[${sdf.format(Date(item.time))}] [${item.level}] [${item.tag}]")
            sb.appendLine(item.message)
            sb.appendLine("--------------------------")
        }
        return sb.toString()
    }

    /**
     * 通过 Root 或应用自身权限抓取最近的 Android 系统崩溃与运行 logcat，辅助定位 Bug。
     */
    fun captureSystemLogcat(): String {
        return try {
            val pid = android.os.Process.myPid()
            val rootOut = RootShell.exec(
                "logcat -d -b crash -t 60 2>/dev/null; echo '=== MAIN LOGCAT ==='; logcat -d --pid=$pid -t 80 2>/dev/null",
                6_000L
            )
            if (!rootOut.isNullOrBlank()) {
                i("LogcatCapture", "已抓取系统 Crash & 当前进程 Logcat (${rootOut.lines().size} 行)")
                rootOut
            } else {
                val proc = ProcessBuilder("logcat", "-d", "-t", "80").redirectErrorStream(true).start()
                val text = proc.inputStream.bufferedReader().use { it.readText() }
                proc.destroy()
                text.ifBlank { "未读取到系统 Logcat 输出" }
            }
        } catch (t: Throwable) {
            e("LogcatCapture", "抓取 Logcat 失败", t)
            "抓取失败: ${t.message}"
        }
    }

    fun logFilePath(context: Context): String = logFile(context).absolutePath

    private fun logFile(context: Context): File {
        val dir = context.getExternalFilesDir(null) ?: context.filesDir
        return File(dir, LOG_FILE_NAME)
    }

    /**
     * 通过 Root 自动为当前应用开启后台运行权限并加入省电白名单，同时跳转系统自启动设置页。
     */
    fun applyRootAutoStartOptimization(context: Context): String {
        val pkg = context.packageName
        return try {
            val cmd = buildString {
                append("dumpsys deviceidle whitelist +$pkg 2>/dev/null; ")
                append("cmd appops set $pkg RUN_IN_BACKGROUND allow 2>/dev/null; ")
                append("cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow 2>/dev/null; ")
                append("cmd appops set $pkg SYSTEM_ALERT_WINDOW allow 2>/dev/null; ")
                append("echo DONE")
            }
            val out = RootShell.exec(cmd, 5_000L).orEmpty()
            if (out.contains("DONE")) {
                i("AutoStart", "已通过 Root 自动授予后台运行、省电白名单与悬浮窗 AppOps 权限")
                "已通过 Root 自动加入电池优化白名单并开启后台运行权限"
            } else {
                w("AutoStart", "Root 省电白名单命令未返回预期结果: $out")
                "已尝试执行 Root 后台保活配置"
            }
        } catch (t: Throwable) {
            e("AutoStart", "Root 自动配置后台权限异常", t)
            "Root 保活配置异常：${t.message}"
        }
    }

    /**
     * 跳转到各品牌手机系统的“自启动管理”或应用详情设置页面。
     */
    fun openAutoStartSettings(context: Context): Boolean {
        val pkg = context.packageName
        val candidateIntents = listOf(
            // 小米 / Redmi (MIUI / HyperOS)
            Intent().apply {
                component = ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"
                )
            },
            // OPPO / 一加 / Realme (ColorOS)
            Intent().apply {
                component = ComponentName(
                    "com.coloros.safecenter",
                    "com.coloros.safecenter.permission.startup.StartupAppListActivity"
                )
            },
            Intent().apply {
                component = ComponentName(
                    "com.oplus.safecenter",
                    "com.oplus.safecenter.permission.startup.StartupAppListActivity"
                )
            },
            // vivo / iQOO (OriginOS)
            Intent().apply {
                component = ComponentName(
                    "com.vivo.permissionmanager",
                    "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"
                )
            },
            // 华为 / 荣耀
            Intent().apply {
                component = ComponentName(
                    "com.huawei.systemmanager",
                    "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"
                )
            },
            // 三星
            Intent().apply {
                component = ComponentName(
                    "com.samsung.android.lool",
                    "com.samsung.android.sm.ui.battery.BatteryActivity"
                )
            },
            // 标准忽略电池优化申请或应用详情兜底
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", pkg, null)
            }
        )

        for (intent in candidateIntents) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                i("AutoStart", "成功跳转自启动/后台管理设置: ${intent.component?.shortClassName ?: intent.action}")
                return true
            } catch (_: Throwable) {
            }
        }
        return false
    }
}
