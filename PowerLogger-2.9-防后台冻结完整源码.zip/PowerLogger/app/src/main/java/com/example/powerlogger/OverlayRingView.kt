package com.example.powerlogger

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.ceil

/** 18dp 高、内容自适应宽度的 FPS 胶囊。 */
class OverlayRingView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private val scaledDensity = resources.displayMetrics.scaledDensity
    private val horizontalPadding = 6f * density
    private val capsuleHeight = 18f * density
    private val bounds = RectF()

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        textSize = 10f * scaledDensity
    }

    var fpsValue: Int = 0
        set(value) {
            val normalized = value.coerceIn(0, 480)
            if (field != normalized) {
                field = normalized
                requestLayout()
                invalidate()
            }
        }

    var recording: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    private fun displayText(): String = fpsValue.coerceAtLeast(0).toString()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val textWidth = textPaint.measureText(displayText())
        val desiredWidth = ceil(textWidth + horizontalPadding * 2f).toInt()
            .coerceAtLeast(capsuleHeight.toInt())
        val desiredHeight = ceil(capsuleHeight).toInt()
        setMeasuredDimension(
            resolveSize(desiredWidth, widthMeasureSpec),
            resolveSize(desiredHeight, heightMeasureSpec)
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        bounds.set(0f, 0f, width.toFloat(), height.toFloat())
        if (bounds.width() <= 0f || bounds.height() <= 0f) return

        // 待机色严格使用 #806B6B4A；记录中保留之前要求的红色状态提示。
        backgroundPaint.color = if (recording) 0x80C62828.toInt() else 0x806B6B4A.toInt()
        canvas.drawRoundRect(bounds, height / 2f, height / 2f, backgroundPaint)

        val text = displayText()
        val baseline = height / 2f - (textPaint.ascent() + textPaint.descent()) / 2f
        canvas.drawText(text, width / 2f, baseline, textPaint)
        contentDescription = "FPS $text${if (recording) "，正在记录" else ""}"
    }
}
