package com.example.powerlogger

import android.content.Context
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Buffered CSV writer for the explicitly user-started whole-device recording session. */
class CsvLogger(private val context: Context) {
    private val lock = Any()
    private var writer: BufferedWriter? = null
    private var pendingRows = 0

    var file: File? = null
        private set

    fun start(): File? = synchronized(lock) {
        stopLocked()
        val base = context.getExternalFilesDir(null) ?: context.filesDir
        val directory = File(base, "logs")
        if (!directory.exists() && !directory.mkdirs()) return@synchronized null

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val target = File(directory, "power_$stamp.csv")
        try {
            val out = BufferedWriter(FileWriter(target, false))
            out.write("timestamp_ms,current_ma,voltage_mv,power_mw,charging,source\n")
            out.flush()
            file = target
            writer = out
            pendingRows = 0
            target
        } catch (_: Exception) {
            file = null
            writer = null
            null
        }
    }

    fun append(sample: PowerSample) = synchronized(lock) {
        val out = writer ?: return@synchronized
        try {
            out.write(
                String.format(
                    Locale.US,
                    "%d,%.3f,%d,%.3f,%d,%s\n",
                    sample.timestamp,
                    sample.currentMa,
                    sample.voltageMv,
                    sample.powerMw,
                    if (sample.charging) 1 else 0,
                    sample.source
                )
            )
            pendingRows++
            if (pendingRows >= 10) {
                out.flush()
                pendingRows = 0
            }
        } catch (_: Exception) {
            stopLocked()
        }
    }

    fun flush() = synchronized(lock) {
        try { writer?.flush() } catch (_: Exception) { }
        pendingRows = 0
    }

    fun stop() = synchronized(lock) { stopLocked() }

    private fun stopLocked() {
        try {
            writer?.flush()
            writer?.close()
        } catch (_: Exception) {
        }
        writer = null
        pendingRows = 0
    }
}
