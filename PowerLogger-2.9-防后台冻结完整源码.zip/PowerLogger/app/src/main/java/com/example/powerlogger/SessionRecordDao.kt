package com.example.powerlogger

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * 历史记录表 Room DAO 接口。
 */
@Dao
interface SessionRecordDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: SessionRecordEntity): Long

    @Update
    suspend fun update(record: SessionRecordEntity)

    @Query("SELECT * FROM session_records ORDER BY start_time DESC")
    fun observeAll(): Flow<List<SessionRecordEntity>>

    @Query("SELECT * FROM session_records ORDER BY start_time DESC")
    suspend fun getAll(): List<SessionRecordEntity>

    /** 供已在 Dispatchers.IO 后台线程中的同步聚合函数安全调用，避免 suspend 签名不匹配导致编译错误。 */
    @Query("SELECT * FROM session_records ORDER BY start_time DESC")
    fun getAllSync(): List<SessionRecordEntity>

    @Query("SELECT * FROM session_records WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): SessionRecordEntity?

    @Query("UPDATE session_records SET note = :note, curve_json = :curveJson WHERE id = :id")
    suspend fun updateNoteAndJson(id: Long, note: String, curveJson: String)

    @Query("DELETE FROM session_records WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM session_records")
    suspend fun deleteAll()
}
