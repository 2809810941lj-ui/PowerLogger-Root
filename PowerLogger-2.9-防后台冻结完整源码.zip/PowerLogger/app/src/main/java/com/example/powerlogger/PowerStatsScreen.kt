package com.example.powerlogger

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import java.io.File
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val MutedText = Color(0xFF6E6E73)
private val CardWhite = Color.White
private val DividerColor = Color(0xFFF0F0F3)

@Composable
fun PowerStatsScreen(
    onBack: () -> Unit,
    onOpenSession: (Long) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var refresh by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000L)
            refresh++
        }
    }
    val data = remember(refresh) {
        try {
            loadPowerStats(context)
        } catch (_: Throwable) {
            emptyPowerStats()
        }
    }

    var showStatsHelp by remember { mutableStateOf(false) }
    var showScenesHelp by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, end = 8.dp, top = 6.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                BackGlyph(iconSize = 24.dp, tint = Ink)
            }
            Text(
                text = "Power Stats",
                fontSize = 27.sp,
                fontWeight = FontWeight.Bold,
                color = Ink
            )
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { showHistory = true }) {
                HistoryGlyph(iconSize = 22.dp, tint = Ink)
            }
            IconButton(onClick = { showClear = true }) {
                TrashGlyph(iconSize = 22.dp, tint = Ink)
            }
        }

        Column(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatisticsCard(
                data = data,
                onHelp = { showStatsHelp = true }
            )
            SummaryCard(data = data)
            AppScenesCard(
                sessions = data.sessions,
                onHelp = { showScenesHelp = true },
                onOpenSession = onOpenSession
            )
        }
    }

    if (showStatsHelp) {
        AlertDialog(
            onDismissRequest = { showStatsHelp = false },
            title = { Text("Statistics") },
            text = {
                Text(
                    text = "蓝色曲线是最近 2 小时的电池电量。下面的 Wh 是期间消耗的电量，" +
                        "温度与电压来自系统电池节点，Discharging 表示当前正在放电。",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { showStatsHelp = false }) { Text("知道了") }
            }
        )
    }

    if (showScenesHelp) {
        AlertDialog(
            onDismissRequest = { showScenesHelp = false },
            title = { Text("App scenes") },
            text = {
                Text(
                    text = "后台会自动识别您日常使用的前台应用并累计其功耗、温度与时长（无需开启 FPS 悬浮窗）。" +
                        "AVG 是场景期间的平均功率与电池温度，MAX 是最高温度；点一行可以查看完整曲线。",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { showScenesHelp = false }) { Text("知道了") }
            }
        )
    }

    if (showHistory) {
        val logDirectory = context.getExternalFilesDir(null)?.let { File(it, "logs").absolutePath }
            ?: "外部存储目录不可用"
        AlertDialog(
            onDismissRequest = { showHistory = false },
            title = { Text("记录历史") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("已保存 ${data.sessions.size} 个 App 场景", fontSize = 13.sp)
                    Text("整机 CSV：$logDirectory", fontSize = 11.sp, color = MutedText)
                    Text(
                        text = "场景数据保存在应用私有目录，可在“功耗统计”里逐条查看。",
                        fontSize = 11.sp,
                        color = MutedText
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showHistory = false }) { Text("关闭") }
            }
        )
    }

    if (showClear) {
        AlertDialog(
            onDismissRequest = { showClear = false },
            title = { Text("清空功耗记录？") },
            text = {
                Text(
                    text = "会删除电池历史曲线和全部 App 场景记录，CSV 文件不受影响。此操作不可撤销。",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    // 修复 P1-9：清空文件与数据库前同步通知后台服务清空内存中的活跃会话缓存，防止旧记录被重新写回
                    try {
                        context.startService(
                            Intent(context, PowerMonitorService::class.java)
                                .setAction(PowerMonitorService.ACTION_CLEAR_CACHE)
                        )
                    } catch (_: Throwable) {}
                    SessionStore.clear(context)
                    BatteryHistory.clear(context)
                    scope.launch(Dispatchers.IO) {
                        try { AppDatabase.getInstance(context).sessionRecordDao().deleteAll() } catch (_: Throwable) {}
                    }
                    showClear = false
                    refresh++
                }) {
                    Text("清空", color = Color(0xFFE5484D))
                }
            },
            dismissButton = {
                TextButton(onClick = { showClear = false }) { Text("取消") }
            }
        )
    }
}

@Composable
private fun StatisticsCard(data: PowerStatsData, onHelp: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = CardWhite,
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Statistics",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Ink
                )
                Spacer(Modifier.width(5.dp))
                HelpDot(onClick = onHelp)
                Spacer(Modifier.weight(1f))
                Text(
                    text = "${data.level}%",
                    fontSize = 20.sp,
                    color = MutedText
                )
            }

            Spacer(Modifier.height(10.dp))

            val windowMs = 2L * 60L * 60L * 1000L
            val windowStart = System.currentTimeMillis() - windowMs
            val points = data.points.mapNotNull { point ->
                val fraction = (point.time - windowStart).toFloat() / windowMs.toFloat()
                if (fraction in 0f..1f) fraction to point.level.toFloat() else null
            }.sortedBy { it.first }

            if (points.size >= 2) {
                val lowest = points.minOfOrNull { it.second } ?: 20f
                val yMin = if (lowest < 20f) 0f else 20f
                LineChart(
                    series = listOf(ChartSeries("Battery", AccentBlue, points)),
                    xLabels = listOf("0", "20m", "40m", "1h", "1h20m", "1h40m", "2h"),
                    yLeftMax = 100f,
                    yLeftMin = yMin,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(188.dp)
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(188.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${data.level}%",
                            fontSize = 34.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentBlue
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "正在积累电池曲线，记录几分钟后显示",
                            fontSize = 11.sp,
                            color = MutedText
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatItem(
                    icon = { BatteryGlyph(iconSize = 15.dp) },
                    text = String.format(Locale.US, "%.1fWh", data.whUsed),
                    modifier = Modifier.weight(1f)
                )
                StatItem(
                    icon = { TempGlyph(iconSize = 15.dp) },
                    text = if (data.tempC > 0.0) String.format(Locale.US, "%.1f°C", data.tempC) else "--",
                    modifier = Modifier.weight(1f)
                )
                StatItem(
                    icon = { BoltGlyph(iconSize = 15.dp) },
                    text = if (data.voltageMv > 0) {
                        String.format(Locale.US, "%.3fv", data.voltageMv / 1000.0)
                    } else {
                        "--"
                    },
                    modifier = Modifier.weight(1f)
                )
                StatItem(
                    icon = { PlugGlyph(iconSize = 15.dp) },
                    text = if (data.charging) "Charging" else "Discharging",
                    modifier = Modifier.weight(1.35f)
                )
            }
        }
    }
}

@Composable
private fun StatItem(
    icon: @Composable () -> Unit,
    text: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(Modifier.width(4.dp))
        Text(
            text = text,
            fontSize = 12.sp,
            color = MutedText,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun SummaryCard(data: PowerStatsData) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = CardWhite,
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SummaryCell(
                value = String.format(Locale.US, "%.2fW", data.avgW),
                label = "Average",
                color = AccentBlue,
                modifier = Modifier.weight(1f)
            )
            SummaryCell(
                value = if (data.usedMs > 0L) formatDurationShort(data.usedMs) else "--",
                label = "Used",
                color = AccentBlue,
                modifier = Modifier.weight(1f)
            )
            SummaryCell(
                value = formatExpected(data.expectedMs),
                label = "Expected",
                color = AccentBlue,
                modifier = Modifier.weight(1f)
            )
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(34.dp)
                    .background(DividerColor)
            )
            SummaryCell(
                value = data.standbyPctPerHour?.let {
                    String.format(Locale.US, "%.0f%%+", it)
                } ?: "--",
                label = "Standby drain",
                color = MutedText,
                modifier = Modifier.weight(1.1f)
            )
        }
    }
}

@Composable
private fun SummaryCell(
    value: String,
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            fontSize = 21.sp,
            fontWeight = FontWeight.Bold,
            color = color,
            maxLines = 1
        )
        Spacer(Modifier.height(3.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = MutedText,
            maxLines = 1
        )
    }
}

@Composable
private fun AppScenesCard(
    sessions: List<AppSession>,
    onHelp: () -> Unit,
    onOpenSession: (Long) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = CardWhite,
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "App scenes",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Ink
                )
                Spacer(Modifier.width(5.dp))
                HelpDot(onClick = onHelp)
                Spacer(Modifier.weight(1f))
                ChartGlyph(iconSize = 18.dp, tint = AccentBlue.copy(alpha = 0.35f))
                Spacer(Modifier.width(9.dp))
                PeopleGlyph(iconSize = 18.dp, tint = AccentBlue.copy(alpha = 0.35f))
                Spacer(Modifier.width(9.dp))
                ListGlyph(iconSize = 18.dp, tint = AccentBlue.copy(alpha = 0.35f))
            }

            if (sessions.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(58.dp)
                            .background(Color(0xFFF7F7FA), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "FPS",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentYellow
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "还没有 App 场景",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Ink
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        text = "正在后台自动统计前台应用的功耗与温度，使用任意应用数秒后即会自动显示",
                        fontSize = 11.sp,
                        color = MutedText,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                sessions.take(20).forEachIndexed { index, session ->
                    if (index > 0) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(DividerColor)
                        )
                    }
                    SceneRow(session = session, onClick = { onOpenSession(session.id) })
                }
            }
        }
    }
}

@Composable
private fun SceneRow(session: AppSession, onClick: () -> Unit) {
    val stats = remember(session.id) { session.buildStats() }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(packageName = session.packageName, size = 44.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = session.label,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = Ink,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            Row {
                Text(
                    text = String.format(
                        Locale.US,
                        "AVG: %s, %.0f°C",
                        formatWatts(stats.avgPower),
                        stats.avgBatteryTemp
                    ),
                    fontSize = 12.sp,
                    color = MutedText,
                    maxLines = 1
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = String.format(Locale.US, "MAX: %.0f°C", stats.maxBatteryTemp),
                    fontSize = 12.sp,
                    color = MutedText,
                    maxLines = 1
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        Text(
            text = formatDurationShort(session.durationMs),
            fontSize = 13.sp,
            color = MutedText
        )
    }
}

@Composable
fun AppIcon(packageName: String, size: Dp) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val bitmap = remember(packageName) {
        try {
            context.packageManager.getApplicationIcon(packageName)
                .toBitmap(96, 96)
                .asImageBitmap()
        } catch (_: Throwable) {
            null
        }
    }
    if (bitmap != null) {
        Image(
            bitmap = bitmap,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(size * 0.26f))
        )
    } else {
        Box(
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(size * 0.26f))
                .background(Color(0xFFEDEDF0)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = packageName.take(1).uppercase(),
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = MutedText
            )
        }
    }
}

private fun emptyPowerStats(): PowerStatsData {
    return PowerStatsData(
        points = emptyList(),
        level = 0,
        tempC = 0.0,
        voltageMv = 0,
        charging = false,
        whUsed = 0.0,
        avgW = 0.0,
        usedMs = 0L,
        expectedMs = 0L,
        standbyPctPerHour = null,
        sessions = emptyList()
    )
}
