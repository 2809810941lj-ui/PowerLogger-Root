# 1.8 快速构建说明

本源码已经做了以下提速处理：

- Room 注解处理从 kapt 改为 **KSP**。
- release 关闭 lint（`lint { checkReleaseBuilds = false }`）。
- 开启 Gradle build cache / configure-on-demand。
- 依赖仓库增加了阿里云 Maven 镜像（官方仓库仍保留兜底）。

在 Android Studio 里直接 Build APK 即可；命令行可用：

```bash
./gradlew :app:assembleRelease
```

签名信息见交付目录的 `PowerLogger-1.8-签名信息.txt`。
不要提交 keystore 到公开仓库。
