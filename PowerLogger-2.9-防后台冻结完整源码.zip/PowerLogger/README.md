# PowerLogger 1.7

Android 原生整机功耗与应用帧率记录工具。Kotlin + Jetpack Compose + Material 3，包名 `com.example.powerlogger`。

## 1.7 版本修改

- FPS 悬浮窗改为 18dp 高、宽度 `wrap_content` 的小胶囊；左右内边距 6dp、上下 0dp、圆角 9dp。
- 字体为 10sp、白色粗体、居中，只显示数字；无边框、无阴影、无 elevation。
- 待机背景严格使用 `#806B6B4A`；开始记录后变为半透明红色，停止后恢复待机色。
- 修复新版本 Android 的 SurfaceFlinger 图层名解析：`RequestedLayerState{... parentId=...}` 会先提取内部真实 `layer name#sequence`，再传给 `--latency`。
- FPS 解析单独拆分为纯 Kotlin `FpsFrameParser`，按 `actualPresentTime` 时间戳计算，过滤 0、`Long.MAX_VALUE` 和时间窗口外的数据。
- 候选图层按 SurfaceView / BLAST 优先顺序检查，最多 6 个，减少无关图层读取。
- 对普通 HWUI 应用增加 `gfxinfo framestats` 备用来源，使用 `FrameCompleted` 列名定位时间戳；不将它当作 SurfaceView / 游戏的真实呈现 FPS。
- 游戏分类应用和 SurfaceView 图层不使用 gfxinfo 代替真实呈现数据，避免把 UI 帧率误报为游戏 FPS。
- 增加自检输出：当前前台包名、解析后的候选 Layer、实际 latency 输出、FPS 数据来源。

## FPS 读数说明

FPS 优先来自 `dumpsys SurfaceFlinger --latency` 的 `actualPresentTime`。常规 View / Compose 应用在该接口没有可用近期帧时，才尝试 `dumpsys gfxinfo <package> framestats` 的 `FrameCompleted`。`gfxinfo` 只反映 HWUI 应用帧，不保证覆盖游戏自有 Surface、Unity / Vulkan / OpenGL 等渲染路径。

悬浮窗只显示数字。显示 `0` 表示最近采样窗口内没有取得有效帧时间戳，不代表屏幕刷新率为 0。桌面静止时，Launcher 可能没有持续提交新帧；滚动桌面或打开应用后才会产生新的帧记录。显示器 120Hz 不等于当前应用持续渲染 120 FPS。

若动态画面仍持续显示 0，请在主界面点击“环境自检”。报告中重点查看：

1. `前台` 是否为正在显示的应用包名。
2. `候选 Layer` 是否列出带当前包名的窗口 / SurfaceView / BLAST 层。
3. `dumpsys SurfaceFlinger --latency` 是否返回三列时间戳。
4. `FPS 数据来源` 是否提示无 Layer、无近期呈现帧或 gfxinfo 不可用。

若 ROM 不开放有效的 SurfaceFlinger 时间戳，或应用使用未暴露给系统 dump 的专有渲染路径，Root 权限也不能保证读取到该应用的真实 FPS。本程序不会用屏幕刷新率或陈旧历史帧伪造 FPS。

## Root 与系统权限

- 设备需要 Magisk 或 KernelSU，并在 Root 管理器中向 PowerLogger 授权。
- FPS 悬浮窗需要“显示在其他应用上层”权限。
- Android 13 及以上需要通知权限；服务通过前台服务通知持续运行。
- Root shell 只用于读取前台窗口、SurfaceFlinger 帧时间戳、CPU/GPU/温度与电池节点；不注入目标进程，不读写游戏内存或修改游戏文件。
- 不提供隐藏 Root、隐藏 `su` 进程、隐藏悬浮窗或规避反作弊检测功能。无法保证游戏不会检测 Root、悬浮窗或第三方采样服务。

## 构建

- Android Gradle Plugin：8.1.4
- Gradle：8.1.1
- Kotlin：1.9.24
- JDK：17
- compileSdk / targetSdk：34
- minSdk：26

使用 Android Studio 打开项目根目录 `PowerLogger/`，完成 Gradle Sync 后构建 APK。项目源码未在本环境完成 Android APK 编译，也未进行真机 FPS 验收。

## 项目记录文件

- 整机 CSV：`getExternalFilesDir(null)/logs/power_时间戳.csv`
- 场景记录：`files/sessions/session_时间戳.json`
- 电池历史：`files/battery_history.csv`
