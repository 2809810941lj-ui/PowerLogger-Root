# FPS 读取自检说明（1.7）

## 已修复的代码问题

Android 16/17 的 `dumpsys SurfaceFlinger --list` 可能将图层名封装成 `RequestedLayerState{真实图层名#序号 parentId=...}`。旧代码把整行调试文本直接传给 `dumpsys SurfaceFlinger --latency`，与 SurfaceFlinger 内部 layer name 不匹配，通常只能得到刷新周期行或空的帧时间数据。1.7 会先剥离外层包装，再把 `真实图层名#序号` 传入 latency 命令。

原来的 FPS 解析器也没有排除 `Long.MAX_VALUE` 的未完成 fence 时间戳。1.7 将其与 0 值一并过滤，并且只用 `actualPresentTime` 统计帧率。

## 备用路径

普通 HWUI / Compose 应用在 SurfaceFlinger latency 无近期数据时，才用 `gfxinfo framestats` 的 `FrameCompleted` 字段作为备用；游戏分类应用和包含 SurfaceView 的应用不使用此备用值，避免把 UI 绘制帧误报为游戏真实呈现 FPS。

## 如何判断仍然读不到

打开“环境自检”，查看报告中的前台包名、候选 Layer、latency 三列和 FPS 数据来源：

- 前台包名不对：前台窗口识别失败，后续层匹配自然会失败。
- 候选 Layer 为“无”：ROM 的 `--list` 输出未包含该包名，或图层名格式尚未覆盖。
- 候选 Layer 存在但 latency 只有刷新周期：传入的图层没有可读的近期呈现记录，或 ROM 不再提供 legacy latency。
- latency 有近期三列时间戳但 FPS 为 0：需确认 `actualPresentTime` 是否为 0 / `Long.MAX_VALUE`，或时间戳是否与设备 monotonic clock 同源。

静态桌面不一定持续提交帧。桌面滚动、窗口动画或持续更新内容时再观察；显示屏的 120Hz 刷新率不能替代应用 FPS。
